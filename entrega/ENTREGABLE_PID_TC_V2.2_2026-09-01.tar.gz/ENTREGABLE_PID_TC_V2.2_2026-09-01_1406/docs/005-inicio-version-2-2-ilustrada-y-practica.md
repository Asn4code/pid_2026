# ADR-005: Inicio de la Versión 2.2 (Ilustrada, Algorítmica y con Kits de Práctica)

## Contexto
La versión V2.1 consolidó la excelencia editorial, la fluidez didáctica y la homogeneidad evaluativa 30/70 sin alterar el contenido sustantivo. Para completar la experiencia de aprendizaje del estudiante y facilitar el andamiaje cognitivo, se aprueba el desarrollo de la **Versión 2.2 (V2.2)**.

## Decisión
Se establece la **Versión 2.2** como la iteración oficial del temario orientada a la integración del «Trío Pedagógico» tema a tema:
1. **Enriquecimiento Visual:** Inserción de figuras vectoriales limpias y accesibles (PDF vectorial/TikZ) en cada capítulo, mapeadas a partir de las presentaciones originales (`temas_tecnicas_computacionales_biologia/*.pptx`).
2. **Pseudocódigo Estructurado:** Incorporación de algoritmos canónicos formales con declaración explícita de entradas, salidas, contratos, precondiciones, invariantes y complejidades asintóticas ($O, \Omega, \Theta$).
3. **Kits de Prácticas Reales (`practice_assets/`):** Construcción y verificación de los scripts de inicialización (`create_workspace.sh`), datos sintéticos reproducibles (`datos/`) y verificadores automáticos de entrega (`check_practice_delivery.sh` emitiendo `DELIVERY_OK`).
4. **Desarrollo Secuencial Tema a Tema:** Procesamiento ordenado desde TC-CH01 hasta TC-CH10, garantizando compilación y reproducibilidad al 100% en cada paso.

## Consecuencias
- Se mantiene V2.1 congelada en su snapshot inmutable como referencia histórica.
- El libro unificado `book.tex` y los capítulos individuales en `capitulos/` evolucionan a V2.2.
- Todas las figuras se compilan localmente como PDF vectorial para garantizar portabilidad y cero dependencias rotas.
