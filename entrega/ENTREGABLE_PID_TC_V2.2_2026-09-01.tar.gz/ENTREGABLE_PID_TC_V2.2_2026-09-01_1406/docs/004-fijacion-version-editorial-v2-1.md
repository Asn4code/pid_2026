# ADR-004: Fijación y Cierre de la Producción Editorial V2.1 de Técnicas Computacionales en Biología

## Contexto
Tras completar el ciclo de auditoría inicial (Auditoría 1) y aplicar las directrices metodológicas de `prompt_3.txt`, se ha generado y validado la versión editorial **V2.1** del manual docente de *Técnicas Computacionales en Biología* (`G1000013`). Esta versión unifica los diez capítulos curriculares, homogeneiza las rúbricas de prácticas al estándar 30/70 (ADR-001), adopta la formulación de invariantes reproducibles (ADR-002), sincroniza el mapa curricular transversal (ADR-003) y establece una voz de acompañamiento docente rigurosa, cercana y prudente.

## Decisión
Se fija formalmente el estado actual de los códigos fuente y materiales derivados como la **versión canónica y congelada de producción editorial V2.1**:
1. **Fuentes vigentes congeladas:** `capitulos/TC-CH01` hasta `TC-CH10` (con réplica exacta en `auditoria_1/v2_1/`).
2. **Volumen maestro compilado:** `book.pdf` (203 páginas, 0 errores, enlaces activos y bibliografía de 30 referencias unificadas).
3. **Respaldo histórico inmutable:** `auditoria_1/v2/` como estado base previo y `./artifacts/` como histórico de snapshots.
4. **Informes de gobernanza aprobados:** `auditoria_1/revision_v2_1/00-supuestos.md`, `00-fuentes-historicas.md`, `00-resumen.md` y `tema-01.md` a `tema-10.md`.
5. **Prompt maestro reutilizable:** `auditoria_1/prompt_editorial_reutilizable.md` fijado como estándar de ingeniería editorial para la regeneración de asignaturas homólogas (ej. *Biología Computacional*).

## Consecuencias
- Queda cerrado el ciclo de reescritura editorial del libro de texto principal.
- Cualquier modificación futura sobre el texto deberá gestionarse mediante un nuevo ciclo versionado (V2.2 o V3.0) con justificación en `FIX_LOG.md`.
- El foco del desarrollo docente para esta asignatura pasa a la siguiente fase operativa: generación de kits de datos (`practice_assets`), entornos reproducibles (DevContainers/Docker), diapositivas de aula y memoria de evaluación del PID.
