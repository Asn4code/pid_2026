# ADR-001: Estandarización de Rúbricas Prácticas (30/70) y Contrato Común

## Contexto
La evaluación de los anexos prácticos mostraba heterogeneidad entre temas. Algunos asignaban un peso del 40% a la comprobación técnica automatizada (`DELIVERY_OK`), corriendo el riesgo de sobrepremiar aspectos puramente mecánicos frente a la comprensión conceptual y el razonamiento analítico.

## Decisión
Se establece un marco homogéneo para las rúbricas de prácticas de los temas T01 a T10:
- **30% Entrega Técnica Automatizada (`DELIVERY_OK`):** Verificación de estructura, formato, contratos de entrada/salida y ausencia de errores de ejecución.
- **70% Razonamiento Conceptual, Perturbación y Robustez:**
  - 30% Deducción formal / análisis de mecanismos.
  - 20% Pruebas de perturbación, casos límite y estabilidad de parámetros.
  - 20% Defensa razonada / interpretación biológica y metodológica.

Cada práctica define explícitamente su contrato: pregunta científica, entrada válida, salida esperada, supuestos, herramientas/versiones y criterios de autocontrol.

## Consecuencias
- Criterios de evaluación claros, justos y predecibles para el estudiantado.
- Priorización del aprendizaje significativo sobre la superación ciega de tests mecánicos.
