# ADR-003: Mapa Unificado de Continuidad y Cadena de Inferencia Proporcional

## Contexto
Existían discrepancias menores en los enlaces hacia temas futuros (por ejemplo, referencias a filogenia en lugar de redes neuronales en T10, o transiciones abruptas entre estructuras y algoritmos). Asimismo, era necesario reforzar el principio de que la evidencia computacional no debe sobreinterpretarse.

## Decisión
1. **Mapa de Continuidad:** T01 (Entorno) $\rightarrow$ T02 (Automatización Bash) $\rightarrow$ T03 (Coste y Complejidad) $\rightarrow$ T04 (Estructuras Lineales) $\rightarrow$ T05 (Estructuras Jerárquicas y Grafos) $\rightarrow$ T06 (Búsqueda y Ordenación) $\rightarrow$ T07 (Teoría de la Información) $\rightarrow$ T08 (Modelos Probabilísticos y Markov) $\rightarrow$ T09 (Alineamiento y BLAST) $\rightarrow$ T10 (Redes Neuronales y Aprendizaje Profundo).
2. **Cadena de Inferencia Proporcional:** En todos los temas se enfatiza el límite metodológico: gramática válida $\neq$ estructura nativa; centralidad $\neq$ diana esencial; alineamiento/E-value $\neq$ homología/función demostrada; explicabilidad (SHAP/Grad-CAM) $\neq$ mecanismo causal.

## Consecuencias
- Cohesión estructural perfecta a lo largo de los 10 capítulos del libro.
- Formación científica rigurosa y libre de sobreinterpretaciones apresuradas.
