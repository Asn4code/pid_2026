# Registro "Never Again" de Correcciones y Diagnóstico

| ID | Tema | Síntoma / Problema | Causa Raíz (5 Whys) | Corrección Implementada | Verificación / Test |
|---|---|---|---|---|---|
| FIX-001 | Transversal | Heterogeneidad en rúbricas prácticas | Falta de plantilla de evaluación común en la primera fase de generación | Adopción de rúbrica estándar 30/70 (ADR-001) | Inspección de practice.tex |
| FIX-002 | Transversal | Cifras empíricas volátiles sin fuente | Estimaciones genéricas introducidas sin anclaje en benchmark local | Reformulación cualitativa e invariantes conceptuales (ADR-002) | Revisión de claims y compilar |
| FIX-003 | TC-CH01 | Cifras no trazadas en §1.2.2 y falta de diagnóstico formativo previo | Presencia de porcentajes exactos volátiles y ausencia de activación de conocimientos | Reformulación cualitativa de presencia profesional, inclusión de 4 predicciones formativas, distinción reproducibilidad/replicabilidad y rúbrica 30/70 | Compilación de chapter.tex (25 páginas) y ejecución de verification/chapter_results.sh |
| FIX-004 | TC-CH02 | Listing 1.3 con comillas que inhibían glob y falta de hito de consolidación | Redacción de `rm -rf "$VAR/*"` y salto abrupto a FASTA tras §1.14 | Corrección con `"$VAR"/*` y prueba `printf`, inserción de Hito 1 de dominio, precisión de `set -euo pipefail`, dirección `$` en `sed` y rúbrica 30/70 | Compilación de chapter.tex (27 páginas) con 0 errores |
| FIX-005 | TC-CH03 | Mapeo de capítulos desactualizado y confusión entre cota Big-O y peor caso | Referencias a Needleman-Wunsch en T08 y asunción de que Big-O implica peor caso | Corrección del mapa de continuidad a T04-T10 (ADR-003), explicitación de tamaño multivariable, demostración de punto de cruce ($50n$ vs $n^2$), separación de cota vs caso y rúbrica 30/70 | Compilación de chapter.tex (23 páginas) con 0 errores |
| FIX-006 | TC-CH04 | Explicación imprecisa de complemento a dos y anidamiento ARN presentado como imposibilidad biológica | Modelo de bit de signo erróneo y falta de delimitación entre gramática de pila y pseudonudos | Ponderación formal de $b_{w-1}$ ($-2^{w-1}$), delimitación de gramática formal vs estructura biológica, intuición de pila para backtracking, modelo de coste de memoria, mapa de continuidad (ADR-003) y rúbrica 30/70 con decisión de diseño | Compilación de chapter.tex (21 páginas) con 0 errores |
| FIX-007 | TC-CH05 | Confusión entre frameshift biológico y generación de k-mers solapados; asimilación errónea de BST a filogenia | Uso de paso 1 para ilustrar cambio de marco de lectura y asunción de que un árbol filogenético herda la invariante de búsqueda de un BST | Formalización de marco 0 vs marco 1 con paso 3 frente a k-mers solapados con paso 1, delimitación de BST vs filogenia, precisión en matriz vs lista de adyacencia según densidad, unificación de altura/nodo interno, mapa de continuidad (ADR-003) y rúbrica 30/70 | Compilación de chapter.tex (21 páginas) con 0 errores |
| FIX-008 | TC-CH06 | Cota inferior de ordenación expresada como $O(n\log n)$ en vez de $\Omega(n\log n)$ y referencias erróneas en continuidad | Notación de cota inferior ambigua y mención a Needleman-Wunsch en T07/08 | Formalización de $\Omega(n\log n)$ por árbol de decisión y aproximación de Stirling, precisión en memoria de QuickSort ($O(\log n)$ prom. / $O(n)$ peor), acotación asintótica de Radix Sort ($O(k\cdot n)$), protocolo de benchmark reproducible ($SEED=42$), corrección del mapa de continuidad (ADR-003) y rúbrica 30/70 | Compilación de chapter.tex (17 páginas) con 0 errores |
| FIX-009 | TC-CH07 | Confusión entre estimación plug-in empírica y fuente generadora subyacente | Asunción de que frecuencias empíricas en muestras cortas redefinen la fuente probabilística | Demostración formal de muestras AAAA vs ACGT bajo fuente uniforme ($P=1/4$), conexión explícita de bits con árbol de decisión de TC-CH06, declaración del contrato numérico y delimitación de estimación plug-in $\hat{H}_0$ | Compilación de chapter.tex (31 páginas) con 0 errores |
| FIX-010 | TC-CH08 | Parámetros de Markov confundidos con celdas y delimitación de optimización MAP en Viterbi | Conteo de $|\Sigma|^{k+1}$ como parámetros libres y caracterización de clasificación posicional como error en vez de regla local distinta | Conteo exacto de grados de libertad ($|\Sigma|^k(|\Sigma|-1)$), unificación de indexación de Viterbi ($t=0\dots T-1$), delimitación formal de decodificación MAP frente a posterior decoding (*Forward-Backward*) y rúbrica 30/70 | Compilación de chapter.tex (19 páginas) con 0 errores |
| FIX-011 | TC-CH09 | Distinción entre puntuación bruta, bit score y E-value; acotación de propagación de anotaciones en BLAST | Tratamiento de E-value sin contextualizar espacio de búsqueda y cuantificadores no acotados sobre anotaciones heredadas | Formalización de Bit Score ($S'$) y $E$-value de Karlin-Altschul ($E=m\cdot n\cdot 2^{-S'}$), delimitación de inferencia proporcional (primer hit $\neq$ función biológica comprobada), ficha técnica reproducible de BLAST y rúbrica 30/70 | Compilación de chapter.tex (19 páginas) con 0 errores |
| FIX-012 | TC-CH10 | Falta del bloque de auditoría ética en práctica y delimitación de validación clínica sin data leakage | Bloque 6 ausente en practice.tex y falta de distinción entre validación interna, test congelado y cohorte externa | Justificación de BCE desde Bernoulli, formalización del protocolo clínico en 3 niveles con prevención de data leakage por paciente, reinterpretación de SHAP/saliencia como herramientas diagnósticas (no prueba causal), materialización del Bloque 6 en el anexo práctico y rúbrica 30/70 | Compilación de chapter.tex (19 páginas) con 0 errores |

### Versión 2.2: Ciclo de Enriquecimiento Visual, Algorítmico y Kits de Práctica

- **FIX-013 | TC-CH01 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Ausencia de diagramas gráficos explicativos para el árbol de directorios/permisos y el modelo de procesos en memoria en TC-CH01; falta del kit descargable ejecutable para el laboratorio.
  - **Causa Raíz:** La versión V2.1 se centró en la excelencia textual y editorial, dejando la infraestructura visual y los paquetes de laboratorio para la iteración V2.2.
  - **Corrección:**
    1. Generadas e insertadas las figuras vectoriales `TC01-F01-filesystem.pdf` y `TC01-F02-process-streams.pdf` adaptadas de las presentaciones docentes (`20250909_intro.pptx` y `20250911_fundamentos.pptx`).
    2. Incorporado el pseudocódigo formal `Verificacion_Acceso_Rutas_Permisos` con contratos y complejidad $O(D)$.
    3. Construida la infraestructura `capitulos/TC-CH01/practice_assets/` (`create_workspace.sh`, `check_environment_registration.sh`, `check_delivery.sh` y dataset `mini.fasta`).
  - **Verificación:** `smoke_test` superado al 100% con emisión de `DELIVERY_OK`; `chapter.pdf` (27 págs), `practice_wrapper.pdf` (4 págs) y `book.pdf` (205 págs) compilan con 0 errores.

- **FIX-014 | TC-CH02 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Ausencia de diagrama visual del flujo de tuberías en memoria y falta del algoritmo formal estructurado para el parseo streaming de FASTA multilínea.
  - **Causa Raíz:** Transición a la versión V2.2 que incorpora la tríada pedagógica (Figura + Pseudocódigo + Kit).
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC02-F01-pipelines.pdf` adaptada de las presentaciones docentes (`20250916_shell_scripting.pptx` y `20250918_regex.pptx`).
    2. Incorporado el pseudocódigo formal `Parser_FASTA_Multilinea_Streaming` con complejidad $O(N)$ tiempo y $O(L_{\max})$ espacio.
    3. Construida la infraestructura `capitulos/TC-CH02/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts base y datasets FASTA/FASTQ).
  - **Verificación:** `smoke_test` superado al 100% con emisión de `DELIVERY_OK`; `chapter.pdf` (29 págs), `practice_wrapper.pdf` (4 págs) y `book.pdf` compilan con 0 errores.

- **FIX-015 | TC-CH03 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Falta de visualización gráfica para la jerarquía asintótica y el punto de cruce en $n=50$; ausencia de algoritmos formales estructurados para Voraz y Programación Dinámica.
  - **Causa Raíz:** Transición a V2.2 para dotar al capítulo de complejidad del «Trío Pedagógico» completo.
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC03-F01-asymptotics.pdf` (panel dual: familias $O(1)$ a $O(2^n)$ y punto de cruce exacto $50n$ vs $n^2$).
    2. Incorporados los pseudocódigos formales `Seleccion_Voraz_Fragmentos_Restriccion` ($O(n\log n)$) y `Fibonacci_DP_Iterativo_Optimo` ($O(n)$ tiempo / $O(1)$ espacio).
    3. Construida la infraestructura `capitulos/TC-CH03/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `puntos_cruce.tsv`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (23 págs), `practice_wrapper.pdf` (4 págs) y `book.pdf` compilan con 0 errores.

- **FIX-016 | TC-CH04 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Ausencia de diagramas visuales para comparar la disposición en memoria física de arrays contiguos frente a listas enlazadas y la dinámica de pilas/colas; falta de algoritmos formales en pseudocódigo.
  - **Causa Raíz:** Integración del «Trío Pedagógico» de la versión V2.2.
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC04-F01-memory-structures.pdf` (panel dual: Array $O(1)$ vs Lista Enlazada $O(n)$ en Heap, y Pila LIFO en ARN vs Cola Circular FIFO en buffer).
    2. Incorporados los pseudocódigos formales `Pila_Validacion_Estructura_Secundaria_ARN` ($O(n)$ tiempo/espacio) y `Cola_Circular_Buffer_Lecturas` ($O(1)$ tiempo / $O(K)$ espacio).
    3. Construida la infraestructura `capitulos/TC-CH04/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `arn_secuencias.tsv`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (23 págs), `practice_wrapper.pdf` (4 págs) y `book.pdf` compilan con 0 errores.

- **FIX-017 | TC-CH05 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Ausencia de diagramas esquemáticos para la resolución de colisiones en tablas hash, árboles BST y grafos PPI; falta de algoritmos formales en pseudocódigo para BST y centralidad de grado.
  - **Causa Raíz:** Integración del «Trío Pedagógico» de la versión V2.2.
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC05-F01-hash-trees-graphs.pdf` (panel dual: Tabla Hash con encadenamiento $\alpha=N/M$ y Árbol BST $izq < nodo \le der$ vs Red PPI de TP53/BRCA1).
    2. Incorporados los pseudocódigos formales `BST_Insercion_y_Busqueda` ($O(h)$) y `Calculo_Centralidad_Grado_Red_Proteica` ($O(V+E)$).
    3. Construida la infraestructura `capitulos/TC-CH05/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `red_ppi.tsv`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (21 págs), `practice_wrapper.pdf` (4 págs) y `book.pdf` compilan con 0 errores.

- **FIX-018 | TC-CH06 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Falta de esquema visual para el árbol de decisión de ordenación y la partición in-situ de QuickSort; ausencia de pseudocódigos formales para búsqueda binaria, Hoare y Radix Sort.
  - **Causa Raíz:** Integración del «Trío Pedagógico» de la versión V2.2.
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC06-F01-sorting-algorithms.pdf` (panel dual: Árbol de decisión dicotómico $n=3 \implies \Omega(n\log n)$ por Stirling y traza in-situ de partición de QuickSort con pivote=5).
    2. Incorporados los pseudocódigos formales `Busqueda_Binaria_Iterativa` ($O(\log n)$), `QuickSort_Particion_Hoare` ($O(n\log n)$ prom.) y `Radix_Sort_Secuencias_ADN` ($O(k(n+|\Sigma|))$).
    3. Construida la infraestructura `capitulos/TC-CH06/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `genomica_ordenar.tsv`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (19 págs), `practice_wrapper.pdf` (3 págs) y `book.pdf` compilan con 0 errores.

- **FIX-019 | TC-CH07 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Ausencia de algoritmos formales estructurados para el cómputo de entropía empírica de Shannon y perfiles de ventana deslizante; falta del kit de entrega reproducible `practice_assets/`.
  - **Causa Raíz:** Integración del «Trío Pedagógico» de la versión V2.2.
  - **Corrección:**
    1. Incorporados los pseudocódigos formales `Entropia_Shannon_Secuencia` ($O(L+|\Sigma|)$, con contrato $0\log 0 = 0$) y `Perfil_Entropia_Ventana_Deslizante`.
    2. Construida la infraestructura `capitulos/TC-CH07/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `secuencias_entropia.fasta`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (31 págs), `practice_wrapper.pdf` (7 págs) y `book.pdf` compilan con 0 errores.

- **FIX-020 | TC-CH08 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Falta de esquema gráfico para el modelo de Markov y la curva de log-odds de islas CpG; ausencia de pseudocódigos formales para evaluación de verosimilitud y decodificación de Viterbi.
  - **Causa Raíz:** Integración del «Trío Pedagógico» de la versión V2.2.
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC08-F01-markov-chains.pdf` (panel dual: Grafo de estados y probabilidades de transición $a_{ij}$ y perfil de log-odds $S(x)$ de discriminación de islas CpG).
    2. Incorporados los pseudocódigos formales `Cadena_Markov_Evaluacion_Probabilidad` ($O(T)$) y `HMM_Algoritmo_Viterbi_Decodificacion` ($O(K^2 T)$).
    3. Construida la infraestructura `capitulos/TC-CH08/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `secuencias_markov.fasta`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (21 págs), `practice_wrapper.pdf` (4 págs) y `book.pdf` compilan con 0 errores.

- **FIX-021 | TC-CH09 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Ausencia de diagramas esquemáticos para la matriz de programación dinámica y decisiones de retroceso; falta de algoritmos formales en pseudocódigo para Needleman-Wunsch y Smith-Waterman.
  - **Causa Raíz:** Integración del «Trío Pedagógico» de la versión V2.2.
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC09-F01-alignment-dp.pdf` (panel dual: Matriz DP con opciones diagonal/arriba/izquierda y decisiones de backtracking con reconstrucción del alineamiento).
    2. Incorporados los pseudocódigos formales `Needleman_Wunsch_Alineamiento_Global` ($O(n\cdot m)$) y `Smith_Waterman_Alineamiento_Local` ($O(n\cdot m)$).
    3. Construida la infraestructura `capitulos/TC-CH09/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `pares_alinear.fasta`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (21 págs), `practice_wrapper.pdf` (5 págs) y `book.pdf` compilan con 0 errores.

- **FIX-022 | TC-CH10 | Enriquecimiento Visual y Algorítmico V2.2**
  - **Síntoma:** Ausencia de diagramas esquemáticos para la arquitectura de red neuronal feedforward y el flujo de derivadas en retropropagación; falta de algoritmo formal en pseudocódigo para el ciclo de entrenamiento forward/backward.
  - **Causa Raíz:** Integración del «Trío Pedagógico» de la versión V2.2.
  - **Corrección:**
    1. Generada e insertada la figura vectorial `TC10-F01-neural-network.pdf` (panel dual: Arquitectura MLP $2 \to 2 \to 1$ para enhancers y flujo de retropropagación con derivadas locales).
    2. Incorporado el pseudocódigo formal `Red_Neuronal_Forward_Backward_2x2x1` ($O(1)$ por iteración, regla de la cadena y actualización por gradiente).
    3. Construida la infraestructura `capitulos/TC-CH10/practice_assets/` (`create_workspace.sh`, `check_practice_delivery.sh`, scripts y dataset `enhancers_epigenomica.tsv`).
  - **Verificación:** `smoke_test` superado al 100% con `DELIVERY_OK`; `chapter.pdf` (15 págs), `practice_wrapper.pdf` (4 págs) y `book.pdf` compilan con 0 errores.
