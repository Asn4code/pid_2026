# ADR-002: Directriz Editorial para Métricas Empíricas e Invariantes Conceptuales

## Contexto
Diversos epígrafes contenían porcentajes, tiempos de cómputo exactos o umbrales técnicos que carecían de trazabilidad local a un experimento fechado y entorno específico (ej. dominancia de Linux, comparaciones de tiempos en segundos, umbrales de algoritmos). Dichas cifras envejecen rápidamente y pueden transmitir certidumbre infundada.

## Decisión
1. Para datos empíricos sin fuente local fechada, se formula la justificación con **máximo rigor cualitativo e invariante conceptual** (resaltando el principio arquitectónico o el orden de magnitud relevante).
2. Cuando se mantengan cifras cuantitativas (ej. E-value, tamaños $k$-mer, umbrales), se acompañan siempre de su alcance, parámetros del modelo y advertencia sobre su condicionalidad.

## Consecuencias
- El material docente gana robustez y vigencia a largo plazo.
- Se entrena al alumnado en la lectura crítica de parámetros y resultados computacionales.
