# ADR-006: Fijación y Congelación de la Versión Editorial 2.2 (Ilustrada, Algorítmica y con Kits de Práctica)

- **Fecha:** 2026-09-01
- **Estado:** Aceptada / Implementada
- **Autores:** Equipo de Innovación Docente & Antigravity Pair Programmer
- **Versión de Producción:** 2.2.0 (Ilustrada, Algorítmica y Práctica)

---

## 1. Contexto

Tras la estabilización matemática, verificación formal y armonización editorial de la Versión 2.1 (`ADR-004`), el Plan de Innovación Docente requería un salto cualitativo hacia la excelencia pedagógica mediante el despliegue del «Trío Pedagógico» en cada uno de los 10 temas de la asignatura *Técnicas Computacionales en Biología*:
1. Diagramas conceptuales vectoriales de alta resolución adaptados de las transparencias docentes originales (`figures/TCXX-*.pdf`).
2. Algoritmos formales estructurados en pseudocódigo estándar con contratos de entrada/salida y análisis asintótico ($O(T), O(S)$).
3. Entornos de laboratorio de prácticas reproducibles y autocontenidos (`practice_assets/`) con validación automatizada mediante `check_practice_delivery.sh` (emitiendo `DELIVERY_OK`).

---

## 2. Decisiones de Diseño e Implementación

1. **Enriquecimiento Gráfico Vectorial Completo (10/10 Temas):**
   - Se diseñaron e insertaron figuras vectoriales de alta precisión en cada capítulo (árbol de directorios POSIX, tuberías streaming en FASTA, curvas asintóticas y de complejidad de algoritmos, modelos de memoria contigua vs enlazada, árboles BST y tablas hash, particionamiento de Hoare y ordenación Radix, perfiles de entropía de Shannon, cadenas de Markov y log-odds CpG, matrices de programación dinámica Needleman-Wunsch / Smith-Waterman, y perceptrones multicapa con backpropagation para epigenómica).
2. **Pseudocódigos Algorítmicos Rigurosos:**
   - Cada tema incorpora listados estructurados en `lstlisting` con precondiciones, invariantes, paso a paso y complejidad formal, eliminando ambigüedades en la implementación.
3. **Kits de Práctica Autónomos e Inmutables:**
   - Cada tema cuenta en `practice_assets/` con `create_workspace.sh`, datasets de prueba sintéticos y reproducibles ($SEED=42$), plantillas de respuesta `notas/respuestas.tsv` y el script de autocorrección `check_practice_delivery.sh`.
4. **Unificación y Compilación Limpia del Libro:**
   - La bibliografía completa (30 fuentes científicas y manuales) ha sido consolidada y desduplicada en `references.bib`.
   - `book.pdf` compila en 215 páginas sin errores ni advertencias de figuras faltantes.

---

## 3. Consecuencias y Verificación

- **Inmutabilidad:** La versión 2.2 queda formalmente congelada en el snapshot `./artifacts/2026-09-01_1325/`.
- **Integridad Técnica:** Los 10 capítulos compilan de forma individual (`chapter.pdf`, `practice.pdf`) y en conjunto (`book.pdf`). Los 10 paquetes de entrega superan el 100% de los smoke tests con calificación de 3.0/3.0 (`DELIVERY_OK`).
- **Estado de la Línea 5 del PID:** La redacción de la memoria final del PID queda pendiente para el momento en que se decida su redacción final.
