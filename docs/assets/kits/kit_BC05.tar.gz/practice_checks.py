#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH05: Secuencia, estructura y funcion de proteinas."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_centroid,
    calculate_rmsd,
    contact_map_count,
    euclidean_distance,
    parse_pdb_atom_line,
)


def practice_anchor() -> None:
    # 1. Parse standard PDB ATOM line
    pdb_line = "ATOM      1  CA  MET A   1       0.000   0.000   0.000  1.00 20.00           C"
    parsed = parse_pdb_atom_line(pdb_line)
    
    # 2. Triplet coordinates
    coords_a = [(0.0, 0.0, 0.0), (3.0, 4.0, 0.0), (3.0, 4.0, 12.0)]
    cx, cy, cz = calculate_centroid(coords_a)
    
    # 3. Contacts at 8.0 Angstroms
    cont = contact_map_count(coords_a, cutoff=8.0)
    
    # 4. RMSD with rigid translation by 1.0 A in X
    coords_b = [(1.0, 0.0, 0.0), (4.0, 4.0, 0.0), (4.0, 4.0, 12.0)]
    r = calculate_rmsd(coords_a, coords_b)
    
    print(f"PDB_RES:{parsed['RESNAME']} CA_POS:{parsed['X']:.1f},{parsed['Y']:.1f},{parsed['Z']:.1f} CENTROID:{cx:.6f},{cy:.6f},{cz:.6f} CONTACTS:{cont['CONTACTS']}/{cont['TOTAL_PAIRS']} DENSITY:{cont['DENSITY']:.6f} RMSD_A:{r:.6f}")


def practice_perturbation() -> None:
    coords = [(0.0, 0.0, 0.0), (3.0, 4.0, 0.0), (3.0, 4.0, 12.0)]
    cont = contact_map_count(coords, cutoff=15.0)
    print(f"PERTURBED_CONTACTS CUTOFF:15.0 CONTACTS:{cont['CONTACTS']}/{cont['TOTAL_PAIRS']} DENSITY:{cont['DENSITY']:.6f}")


def practice_domain_guard(line: str = "ATOM 1 CA") -> None:
    try:
        parse_pdb_atom_line(line)
        print(f"GUARD_PDB:{line} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_PDB:{line} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH05 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--line", type=str, default="ATOM 1 CA")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.line)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
