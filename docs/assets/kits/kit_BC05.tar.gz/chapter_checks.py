#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH05: Secuencia, estructura y funcion de proteinas.

Implementa parsing columnar de registros ATOM en formato PDB, distancias euclideas,
centroide molecular, matrices de contacto y calculo de RMSD estructural.
"""

from __future__ import annotations

import argparse
import math
import sys


def parse_pdb_atom_line(line: str) -> dict[str, str | int | float]:
    if not line.startswith("ATOM  ") and not line.startswith("HETATM"):
        raise ValueError(f"Linea PDB no es un registro ATOM/HETATM valido: {line[:6]}")
    if len(line) < 54:
        raise ValueError(f"Linea PDB incompleta ({len(line)} caracteres, minimo 54): {line}")
    
    try:
        atom_serial = int(line[6:11].strip())
        atom_name = line[12:16].strip()
        res_name = line[17:20].strip()
        chain_id = line[21].strip() if len(line) > 21 else "A"
        res_seq = int(line[22:26].strip())
        x = float(line[30:38].strip())
        y = float(line[38:46].strip())
        z = float(line[46:54].strip())
        occ = float(line[54:60].strip()) if len(line) >= 60 and line[54:60].strip() else 1.0
        b_fac = float(line[60:66].strip()) if len(line) >= 66 and line[60:66].strip() else 0.0
    except (ValueError, IndexError) as e:
        raise ValueError(f"Error parseando campos numericos de linea PDB: {line} -> {e}")
    
    return {
        "RECORD": line[:6].strip(),
        "SERIAL": atom_serial,
        "NAME": atom_name,
        "RESNAME": res_name,
        "CHAIN": chain_id,
        "RESSEQ": res_seq,
        "X": x,
        "Y": y,
        "Z": z,
        "OCC": occ,
        "BFAC": b_fac,
    }


def euclidean_distance(p1: tuple[float, float, float], p2: tuple[float, float, float]) -> float:
    dx = p1[0] - p2[0]
    dy = p1[1] - p2[1]
    dz = p1[2] - p2[2]
    return math.sqrt(dx * dx + dy * dy + dz * dz)


def calculate_centroid(coords: list[tuple[float, float, float]]) -> tuple[float, float, float]:
    if not coords:
        raise ValueError("Lista de coordenadas vacia")
    n = len(coords)
    cx = sum(p[0] for p in coords) / n
    cy = sum(p[1] for p in coords) / n
    cz = sum(p[2] for p in coords) / n
    return (cx, cy, cz)


def calculate_rmsd(coords_a: list[tuple[float, float, float]], coords_b: list[tuple[float, float, float]]) -> float:
    if len(coords_a) != len(coords_b):
        raise ValueError("Las dos conformaciones deben tener el mismo numero de atomos")
    n = len(coords_a)
    if n == 0:
        return 0.0
    sq_sum = sum((p1[0]-p2[0])**2 + (p1[1]-p2[1])**2 + (p1[2]-p2[2])**2 for p1, p2 in zip(coords_a, coords_b))
    return math.sqrt(sq_sum / n)


def contact_map_count(coords: list[tuple[float, float, float]], cutoff: float = 8.0) -> dict[str, int | float]:
    n = len(coords)
    contacts = 0
    total_pairs = (n * (n - 1)) // 2
    for i in range(n):
        for j in range(i + 1, n):
            d = euclidean_distance(coords[i], coords[j])
            if d <= cutoff:
                contacts += 1
    density = (contacts / total_pairs) if total_pairs > 0 else 0.0
    return {"N_ATOMS": n, "CONTACTS": contacts, "TOTAL_PAIRS": total_pairs, "DENSITY": density}


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH05 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # pdb_parse
    p_pdb = subparsers.add_parser("parse_atom")
    p_pdb.add_argument("line", type=str)

    # distance
    p_dist = subparsers.add_parser("distance")
    p_dist.add_argument("p1", nargs=3, type=float)
    p_dist.add_argument("p2", nargs=3, type=float)

    # centroid
    p_cen = subparsers.add_parser("centroid")
    p_cen.add_argument("coords", nargs="+", help="x,y,z tuples, e.g. 1.0,2.0,3.0 4.0,5.0,6.0")

    # rmsd
    p_rmsd = subparsers.add_parser("rmsd")
    p_rmsd.add_argument("--set_a", nargs="+", required=True)
    p_rmsd.add_argument("--set_b", nargs="+", required=True)

    # contacts
    p_cont = subparsers.add_parser("contacts")
    p_cont.add_argument("--cutoff", type=float, default=8.0)
    p_cont.add_argument("coords", nargs="+")

    args = parser.parse_args()

    if args.subcommand == "parse_atom":
        res = parse_pdb_atom_line(args.line)
        print(f"SERIAL:{res['SERIAL']} NAME:{res['NAME']} RES:{res['RESNAME']} CHAIN:{res['CHAIN']} RESSEQ:{res['RESSEQ']} X:{res['X']:.3f} Y:{res['Y']:.3f} Z:{res['Z']:.3f} BFAC:{res['BFAC']:.2f}")
    elif args.subcommand == "distance":
        d = euclidean_distance(tuple(args.p1), tuple(args.p2))
        print(f"P1:{tuple(args.p1)} P2:{tuple(args.p2)} DIST_ANGSTROM:{d:.6f}")
    elif args.subcommand == "centroid":
        pts = [tuple(map(float, c.split(","))) for c in args.coords]
        cx, cy, cz = calculate_centroid(pts)
        print(f"N_POINTS:{len(pts)} CENTROID:{cx:.6f},{cy:.6f},{cz:.6f}")
    elif args.subcommand == "rmsd":
        pts_a = [tuple(map(float, c.split(","))) for c in args.set_a]
        pts_b = [tuple(map(float, c.split(","))) for c in args.set_b]
        r = calculate_rmsd(pts_a, pts_b)
        print(f"N_ATOMS:{len(pts_a)} RMSD_ANGSTROM:{r:.6f}")
    elif args.subcommand == "contacts":
        pts = [tuple(map(float, c.split(","))) for c in args.coords]
        res = contact_map_count(pts, args.cutoff)
        print(f"ATOMS:{res['N_ATOMS']} CUTOFF:{args.cutoff:.1f} CONTACTS:{res['CONTACTS']}/{res['TOTAL_PAIRS']} DENSITY:{res['DENSITY']:.6f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
