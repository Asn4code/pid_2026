#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC08_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC08 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/secuencias_markov.fasta" "${DEST_DIR}/datos/secuencias_markov.fasta"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
secuencia_id	log_odds_score	clasificacion_modelo	justificacion_probabilistica
secuencia_isla_cpg	+45.2	Isla_CpG_Positiva	Frecuencia de dinucleotidos CG muy superior al fondo genomico (log-odds > 0).
secuencia_fondo_genomico	-38.6	Fondo_Genomico	Ausencia de dinucleotidos CpG; favorece el modelo nulo negativo (log-odds < 0).
EOTSV

# Scripts funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/log_odds_markov.sh"
#!/usr/bin/env bash
set -euo pipefail
# Evalua log-odds de dinucleotidos en FASTA
INPUT="${1:-datos/secuencias_markov.fasta}"

awk '
/^>/ {
    if (seq != "") { evaluar(hdr, seq); }
    hdr = $0; seq = ""; next
}
{ seq = seq $0 }
END { if (seq != "") { evaluar(hdr, seq); } }

function evaluar(h, s) {
    len = length(s);
    score = 0;
    for (i=1; i<len; i++) {
        di = substr(s, i, 2);
        if (di == "CG") score += 2.5;
        else if (di == "AT" || di == "TA") score -= 1.2;
        else score += 0.1;
    }
    printf "%s	Longitud: %d	Log-Odds: %.2f\n", h, len, score;
}
' "${INPUT}"
EOS
chmod +x "${DEST_DIR}/scripts/log_odds_markov.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/viterbi_simple.sh"
#!/usr/bin/env bash
set -euo pipefail
# Simula el algoritmo de Viterbi
echo "[+] Decodificacion de Viterbi ejecutada: Camino de estados maximo-verosimil encontrado en O(K^2 L)."
EOS
chmod +x "${DEST_DIR}/scripts/viterbi_simple.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
