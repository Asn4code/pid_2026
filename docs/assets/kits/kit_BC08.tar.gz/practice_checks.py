#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH08: Mapeo de lecturas y flujos NGS."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    build_kmer_index,
    mapq_to_error_prob,
    parse_cigar,
    seed_and_extend_map,
)


def practice_anchor() -> None:
    genome = "CATGGTCATTGGTTCC"
    query = "TGGTCA"
    
    # 1. Indexing
    idx = build_kmer_index(genome, k=3, one_based=True)
    cat_hits = ",".join(str(p) for p in idx.get("CAT", []))
    tgg_hits = ",".join(str(p) for p in idx.get("TGG", []))
    
    # 2. Seed-and-extend mapping
    hits = seed_and_extend_map(query, genome, k=3, max_mismatches=1, one_based=True)
    best = hits[0]
    
    # 3. CIGAR parse
    cigar_lens = parse_cigar("10M2I38M")
    
    # 4. MAPQ
    p_60 = mapq_to_error_prob(60.0)
    
    print(
        f"GENOME_LEN:{len(genome)} UNIQUE_KMERS:{len(idx)} CAT_POS:{cat_hits} TGG_POS:{tgg_hits} "
        f"QUERY:{query} POS:{best['POS']} CIGAR:{best['CIGAR']} "
        f"CIGAR_QUERY_LEN:{cigar_lens['QUERY_LEN']} CIGAR_REF_LEN:{cigar_lens['REF_LEN']} "
        f"MAPQ:60.0 ERR_PROB:{p_60:.6f}"
    )


def practice_perturbation() -> None:
    genome = "CATGGTCATTGGTTCC"
    query = "TGGTCT"
    hits = seed_and_extend_map(query, genome, k=3, max_mismatches=1, one_based=True)
    best = hits[0]
    print(f"PERTURBED_QUERY:{query} STATUS:MAPPED POS:{best['POS']} MISMATCHES:{best['MISMATCHES']} TARGET:{best['TARGET_SEQ']}")


def practice_domain_guard(query: str = "TG", k: int = 3) -> None:
    genome = "CATGGTCATTGGTTCC"
    try:
        seed_and_extend_map(query, genome, k=k)
        print(f"GUARD_QUERY:{query} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_QUERY:{query} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH08 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--query", type=str, default="TG")
    p_guard.add_argument("--k", type=int, default=3)

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.query, args.k)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
