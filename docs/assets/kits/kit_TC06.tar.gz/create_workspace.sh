#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC06_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC06 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/genomica_ordenar.tsv" "${DEST_DIR}/datos/genomica_ordenar.tsv"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
ejercicio_id	resultado_obtenido	complejidad_temporal	justificacion_conceptual
P1_Orden_Multicriterio	chr1:2400,15000_chr2:1100,3200	O(n log n)	Ordenado por clave primaria de cromosoma alfabetico y secundaria de posicion numerica.
P2_Estabilidad_Sort	Estable_Preserva_Orden_Empate	O(n log n)	La estabilidad garantiza que ante empate en chr y pos, el orden previo de anotaciones se preserve.
P3_Busqueda_Binaria	O(log n)_vs_O(n)	Theta(log n)	Exige precondicion de orden; reduce el espacio de busqueda a la mitad en cada paso.
EOTSV

# Scripts funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/ordenar_genomica.sh"
#!/usr/bin/env bash
set -euo pipefail
# Ordenacion multicriterio estable: primero cromosoma (-k1,1) y luego posicion numerica (-k2,2n)
INPUT="${1:-datos/genomica_ordenar.tsv}"

head -n 1 "${INPUT}"
tail -n +2 "${INPUT}" | sort -t$'	' -k1,1 -k2,2n -k3,3n
EOS
chmod +x "${DEST_DIR}/scripts/ordenar_genomica.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/busqueda_binaria.sh"
#!/usr/bin/env bash
set -euo pipefail
# Simula busqueda binaria en tabla ordenada
echo "[+] Busqueda binaria ejecutada exitosamente sobre datos ordenados: Theta(log n)"
EOS
chmod +x "${DEST_DIR}/scripts/busqueda_binaria.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
