#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH04: Expresion genica, transcriptomica y redes de regulacion."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_tpm,
    gc3_content,
    transcribe,
    translate_rna,
)


def practice_anchor() -> None:
    dna = "ATGGCCATTGTAATGTAA"
    rna = transcribe(dna)
    prot = translate_rna(rna, frame=0)
    gc3 = gc3_content(dna)
    tpm = calculate_tpm([100.0, 200.0, 50.0], [1000.0, 2000.0, 500.0])
    tpm_str = ";".join(f"{v:.6f}" for v in tpm)
    print(f"ANCHOR_DNA:{dna} RNA:{rna} PROTEIN:{prot} GC3:{gc3:.2f} TPM:{tpm_str}")


def practice_perturbation() -> None:
    tpm = calculate_tpm([200.0, 200.0, 50.0], [1000.0, 2000.0, 500.0])
    tpm_str = ";".join(f"{v:.6f}" for v in tpm)
    print(f"PERTURBED_TPM:{tpm_str}")


def practice_domain_guard(dna: str = "ATGGZX") -> None:
    try:
        transcribe(dna)
        print(f"GUARD_DNA:{dna} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_DNA:{dna} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH04 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--dna", type=str, default="ATGGZX")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.dna)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
