#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC03_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC03 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/puntos_cruce.tsv" "${DEST_DIR}/datos/puntos_cruce.tsv"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
ejercicio_id	resultado_numerico	complejidad_asintotica	justificacion_conceptual
P1_Punto_Cruce	50	Theta(n) vs Theta(n^2)	Para n=50 ambos algoritmos ejecutan 2500 operaciones; para n>50 el lineal domina.
P2_Fibonacci_Naive	O(2^n)	Exponencial	El arbol de llamadas recursivas se bifurca duplicando el trabajo en cada nivel.
P3_Fibonacci_Memo	O(n)	Lineal	Almacenar subproblemas ya resueltos evita recalcular estados repetidos.
EOTSV

# Scripts funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/fibonacci.sh"
#!/usr/bin/env bash
set -euo pipefail
N="${1:-10}"

fib_memo() {
    local n=$1
    local a=0
    local b=1
    for (( i=0; i<n; i++ )); do
        local temp=$(( a + b ))
        a=$b
        b=$temp
    done
    echo "$a"
}

fib_memo "$N"
EOS
chmod +x "${DEST_DIR}/scripts/fibonacci.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/medir_tiempos.sh"
#!/usr/bin/env bash
set -euo pipefail
# Comprueba tiempo de ejecucion
for n in 5 10 15 20; do
    SCRIPT_DIR=$(dirname "$0")
    res=$(bash "${SCRIPT_DIR}/fibonacci.sh" "$n")
    echo "N=$n -> Fib=$res"
done
EOS
chmod +x "${DEST_DIR}/scripts/medir_tiempos.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
