#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH06: Tecnologias de secuenciacion y diseno experimental."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_coverage,
    gc_bias_metric,
    lander_waterman_stats,
    required_reads,
)


def practice_anchor() -> None:
    c = calculate_coverage(num_reads=100, read_length=150, genome_size=3000)
    lw = lander_waterman_stats(coverage=c)
    req = required_reads(target_coverage=30.0, read_length=150, genome_size=3000)
    bias = gc_bias_metric(observed_gc_percent=60.0, expected_gc_percent=50.0)
    print(f"COVERAGE_X:{c:.6f} GAP_FRACTION:{lw['GAP_FRACTION']:.6f} COVERED_FRACTION:{lw['COVERED_FRACTION']:.6f} REQ_READS_30X:{req} GC_BIAS:{bias:.6f}")


def practice_perturbation() -> None:
    lw = lander_waterman_stats(coverage=10.0)
    print(f"PERTURBED_10X GAP_FRACTION:{lw['GAP_FRACTION']:.6f} COVERED_FRACTION:{lw['COVERED_FRACTION']:.6f}")


def practice_domain_guard(genome_size: int = -100) -> None:
    try:
        calculate_coverage(num_reads=100, read_length=150, genome_size=genome_size)
        print(f"GUARD_GENOME:{genome_size} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_GENOME:{genome_size} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH06 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--genome_size", type=int, default=-100)

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.genome_size)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
