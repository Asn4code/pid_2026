#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH06: Tecnologias de secuenciacion y diseno experimental.

Implementa metricas cuantitativas de secuenciacion: calculo de cobertura genomica (Lander-Waterman),
estimacion de brechas de Poisson, dimensionamiento de lecturas requeridas y analisis de sesgo GC.
"""

from __future__ import annotations

import argparse
import math
import sys


def calculate_coverage(num_reads: int, read_length: int, genome_size: int) -> float:
    if num_reads <= 0 or read_length <= 0 or genome_size <= 0:
        raise ValueError("Parametros de secuenciacion deben ser enteros estrictamente positivos")
    return (num_reads * read_length) / genome_size


def lander_waterman_stats(coverage: float) -> dict[str, float]:
    if coverage < 0:
        raise ValueError("La cobertura no puede ser negativa")
    gap_fraction = math.exp(-coverage)
    covered_fraction = 1.0 - gap_fraction
    return {
        "COVERAGE": coverage,
        "GAP_FRACTION": gap_fraction,
        "COVERED_FRACTION": covered_fraction,
    }


def required_reads(target_coverage: float, read_length: int, genome_size: int) -> int:
    if target_coverage <= 0 or read_length <= 0 or genome_size <= 0:
        raise ValueError("Parametros deben ser estrictamente positivos")
    total_bases_needed = target_coverage * genome_size
    return math.ceil(total_bases_needed / read_length)


def gc_bias_metric(observed_gc_percent: float, expected_gc_percent: float) -> float:
    if expected_gc_percent <= 0 or expected_gc_percent > 100:
        raise ValueError("Porcentaje GC esperado debe estar en (0, 100]")
    if observed_gc_percent < 0 or observed_gc_percent > 100:
        raise ValueError("Porcentaje GC observado debe estar en [0, 100]")
    return observed_gc_percent / expected_gc_percent


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH06 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # coverage
    p_cov = subparsers.add_parser("coverage")
    p_cov.add_argument("--reads", type=int, required=True)
    p_cov.add_argument("--length", type=int, required=True)
    p_cov.add_argument("--genome", type=int, required=True)

    # poisson / lander-waterman
    p_lw = subparsers.add_parser("poisson_gaps")
    p_lw.add_argument("--coverage", type=float, required=True)

    # required reads
    p_req = subparsers.add_parser("required_reads")
    p_req.add_argument("--target_cov", type=float, required=True)
    p_req.add_argument("--length", type=int, required=True)
    p_req.add_argument("--genome", type=int, required=True)

    # gc bias
    p_gc = subparsers.add_parser("gc_bias")
    p_gc.add_argument("--obs", type=float, required=True)
    p_gc.add_argument("--exp", type=float, required=True)

    args = parser.parse_args()

    if args.subcommand == "coverage":
        c = calculate_coverage(args.reads, args.length, args.genome)
        print(f"READS:{args.reads} LENGTH:{args.length} GENOME:{args.genome} COVERAGE_X:{c:.6f}")
    elif args.subcommand == "poisson_gaps":
        res = lander_waterman_stats(args.coverage)
        print(f"COVERAGE_X:{res['COVERAGE']:.2f} GAP_FRACTION:{res['GAP_FRACTION']:.6f} COVERED_FRACTION:{res['COVERED_FRACTION']:.6f}")
    elif args.subcommand == "required_reads":
        n = required_reads(args.target_cov, args.length, args.genome)
        print(f"TARGET_COV:{args.target_cov:.1f}X LENGTH:{args.length} GENOME:{args.genome} REQUIRED_READS:{n}")
    elif args.subcommand == "gc_bias":
        ratio = gc_bias_metric(args.obs, args.exp)
        print(f"OBS_GC:{args.obs:.2f} EXP_GC:{args.exp:.2f} BIAS_RATIO:{ratio:.6f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
