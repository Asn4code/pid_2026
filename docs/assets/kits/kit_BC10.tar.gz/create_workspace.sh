#!/usr/bin/env bash
# create_workspace.sh - Inicializa el entorno de trabajo para la Practica BC10
set -e

DIR_ENTREGA="${1:-MiEntrega_BC10}"
mkdir -p "$DIR_ENTREGA/notas"
mkdir -p "$DIR_ENTREGA/src"

cp practice_checks.py "$DIR_ENTREGA/src/"
if [ -f chapter_checks.py ]; then cp chapter_checks.py "$DIR_ENTREGA/src/"; fi

cat << 'EOF' > "$DIR_ENTREGA/notas/respuestas.tsv"
# Plantilla de Respuestas - Practica BC10
# Modulo: Regulación Génica, Clonación y Plásmidos
METRIC\tVALOR\tDEFENSA_BREVE
DELIVERY_STATUS\tPENDIENTE\tInicializacion de entorno
EOF

echo "Espacio de trabajo creado en: $DIR_ENTREGA"
