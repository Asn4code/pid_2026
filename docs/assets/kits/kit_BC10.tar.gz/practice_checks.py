#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH10: Regulacion, clonacion y vectores recombinantes."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_gc_percent,
    calculate_primer_tm,
    find_restriction_sites,
    operon_lac_state,
)


def practice_anchor() -> None:
    seq = "GGAATTCATGGTGAGCAAGGGCGAG"
    
    # 1. Primer Tm calculation
    gc = calculate_gc_percent(seq)
    tm = calculate_primer_tm(seq)
    
    # 2. Operon Lac fully induced (Glucose-, Lactose+)
    state, expr = operon_lac_state(glucose=False, lactose=True)
    
    # 3. Restriction site finding
    sites = find_restriction_sites(seq)
    ecori_pos = ",".join(str(p) for p in sites.get("EcoRI", []))
    
    print(
        f"PRIMER:{seq} LEN:{len(seq)} GC_PCT:{gc:.2f} TM_C:{tm:.2f} "
        f"LAC_STATE:{state} EXPR_RATIO:{expr:.1f} ECORI_POS:{ecori_pos}"
    )


def practice_perturbation() -> None:
    state, expr = operon_lac_state(glucose=True, lactose=True)
    print(f"PERTURBED_LAC STATE:{state} EXPR_RATIO:{expr:.1f}")


def practice_domain_guard(seq: str = "ATG") -> None:
    try:
        calculate_primer_tm(seq)
        print(f"GUARD_SEQ:{seq} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_SEQ:{seq} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH10 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--seq", type=str, default="ATG")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.seq)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
