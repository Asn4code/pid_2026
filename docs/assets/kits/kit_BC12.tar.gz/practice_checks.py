#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH12: Prediccion estructural clasica."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_clashscore,
    calculate_d0,
    calculate_sequence_identity,
    calculate_tm_score,
    metropolis_acceptance_probability,
)


def practice_anchor() -> None:
    s1 = "ACDEFGHIKLMNPQRSTVWY"
    s2 = "ACDEFGHIKLMNPQRSTVWA"
    
    # 1. Sequence identity
    ident = calculate_sequence_identity(s1, s2)
    
    # 2. Metropolis criterion
    prob = metropolis_acceptance_probability(300.0, 300.0)
    
    # 3. TM-score
    tm = calculate_tm_score([0.0, 0.0, 0.0, 0.0], 4)
    
    # 4. Clashscore
    cs = calculate_clashscore(2, 1000)
    
    print(
        f"IDENTITY_PCT:{ident:.2f} METROPOLIS_PROB:{prob:.6f} "
        f"TM_SCORE:{tm:.6f} CLASHSCORE:{cs:.6f}"
    )


def practice_perturbation() -> None:
    prob = metropolis_acceptance_probability(600.0, 300.0)
    print(f"PERTURBED_METROPOLIS PROB:{prob:.6f}")


def practice_domain_guard(temp: float = 0.0) -> None:
    try:
        metropolis_acceptance_probability(100.0, temp)
        print(f"GUARD_TEMP:{temp} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_TEMP:{temp} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH12 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--temp", type=float, default=0.0)

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.temp)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
