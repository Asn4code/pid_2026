#!/usr/bin/env bash
# create_workspace.sh - Inicializa el entorno de trabajo para la Practica BC07
set -e

DIR_ENTREGA="${1:-MiEntrega_BC07}"
mkdir -p "$DIR_ENTREGA/notas"
mkdir -p "$DIR_ENTREGA/src"

cp practice_checks.py "$DIR_ENTREGA/src/"
if [ -f chapter_checks.py ]; then cp chapter_checks.py "$DIR_ENTREGA/src/"; fi

cat << 'EOF' > "$DIR_ENTREGA/notas/respuestas.tsv"
# Plantilla de Respuestas - Practica BC07
# Modulo: Formatos FASTQ y Control de Calidad
METRIC\tVALOR\tDEFENSA_BREVE
DELIVERY_STATUS\tPENDIENTE\tInicializacion de entorno
EOF

echo "Espacio de trabajo creado en: $DIR_ENTREGA"
