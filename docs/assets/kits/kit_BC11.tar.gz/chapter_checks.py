#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH11: Datos estructurales y evidencia experimental.

Implementa parsing estricto de registros ATOM PDB, calculo de distancias 3D,
calculo de RMSD entre modelos, conversion de factores B de Debye-Waller a fluctuacion RMSF,
y validacion estereoquimica.
"""

from __future__ import annotations

import argparse
import math
import sys


def parse_pdb_atom(line: str) -> dict[str, object]:
    if not line.startswith("ATOM  ") and not line.startswith("HETATM"):
        raise ValueError("La linea debe comenzar con ATOM o HETATM")
    if len(line) < 66:
        raise ValueError("La linea PDB de ancho fijo debe tener al menos 66 caracteres")

    atom_id = int(line[6:11].strip())
    atom_name = line[12:16].strip()
    res_name = line[17:20].strip()
    chain = line[21].strip()
    res_id = int(line[22:26].strip())
    x = float(line[30:38].strip())
    y = float(line[38:46].strip())
    z = float(line[46:54].strip())
    occupancy = float(line[54:60].strip())
    b_factor = float(line[60:66].strip())

    return {
        "atom_id": atom_id,
        "atom_name": atom_name,
        "res_name": res_name,
        "chain": chain,
        "res_id": res_id,
        "x": x,
        "y": y,
        "z": z,
        "occupancy": occupancy,
        "b_factor": b_factor,
    }


def euclidean_distance_3d(c1: tuple[float, float, float], c2: tuple[float, float, float]) -> float:
    return math.sqrt((c1[0] - c2[0]) ** 2 + (c1[1] - c2[1]) ** 2 + (c1[2] - c2[2]) ** 2)


def calculate_rmsd(coords_a: list[tuple[float, float, float]], coords_b: list[tuple[float, float, float]]) -> float:
    if len(coords_a) != len(coords_b) or len(coords_a) == 0:
        raise ValueError("Ambos conjuntos deben tener el mismo numero no nulo de atomos")
    sq_sum = sum((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2 for a, b in zip(coords_a, coords_b))
    return math.sqrt(sq_sum / len(coords_a))


def b_factor_to_rmsf(b_factor: float) -> tuple[float, float]:
    if b_factor < 0:
        raise ValueError("El factor B no puede ser negativo")
    # B = 8 * pi^2 * <u^2> => <u^2> = B / (8 * pi^2)
    u_sq = b_factor / (8.0 * (math.pi ** 2))
    rmsf = math.sqrt(u_sq)
    return u_sq, rmsf


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH11 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # pdb_parse
    p_parse = subparsers.add_parser("parse_pdb")
    p_parse.add_argument(
        "--line",
        type=str,
        default="ATOM      1  CA  ALA A   1      10.000  20.000  30.000  1.00  15.50           C",
    )

    # dist
    p_dist = subparsers.add_parser("distance")
    p_dist.add_argument("--x1", type=float, default=10.0)
    p_dist.add_argument("--y1", type=float, default=20.0)
    p_dist.add_argument("--z1", type=float, default=30.0)
    p_dist.add_argument("--x2", type=float, default=13.0)
    p_dist.add_argument("--y2", type=float, default=24.0)
    p_dist.add_argument("--z2", type=float, default=30.0)

    # rmsd
    p_rmsd = subparsers.add_parser("rmsd")
    p_rmsd.add_argument("--coords_a", type=str, default="0,0,0;3,4,0")
    p_rmsd.add_argument("--coords_b", type=str, default="0,0,0;3,4,0")

    # b_factor
    p_b = subparsers.add_parser("bfactor")
    p_b.add_argument("--b", type=float, default=78.956835)

    args = parser.parse_args()

    if args.subcommand == "parse_pdb":
        res = parse_pdb_atom(args.line)
        print(
            f"ATOM_ID:{res['atom_id']} NAME:{res['atom_name']} RES:{res['res_name']} "
            f"CHAIN:{res['chain']} RES_ID:{res['res_id']} "
            f"X:{res['x']:.3f} Y:{res['y']:.3f} Z:{res['z']:.3f} "
            f"OCC:{res['occupancy']:.2f} B_FACTOR:{res['b_factor']:.2f}"
        )
    elif args.subcommand == "distance":
        d = euclidean_distance_3d((args.x1, args.y1, args.z1), (args.x2, args.y2, args.z2))
        print(f"DIST_A:{d:.6f}")
    elif args.subcommand == "rmsd":
        ca = [tuple(map(float, p.split(","))) for p in args.coords_a.split(";")]
        cb = [tuple(map(float, p.split(","))) for p in args.coords_b.split(";")]
        r = calculate_rmsd(ca, cb)
        print(f"RMSD_A:{r:.6f}")
    elif args.subcommand == "bfactor":
        u_sq, rmsf = b_factor_to_rmsf(args.b)
        print(f"B_FACTOR:{args.b:.6f} U_SQ:{u_sq:.6f} RMSF_A:{rmsf:.6f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
