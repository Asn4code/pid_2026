#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH11: Datos estructurales y evidencia experimental."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    b_factor_to_rmsf,
    calculate_rmsd,
    euclidean_distance_3d,
    parse_pdb_atom,
)


def practice_anchor() -> None:
    line = "ATOM      1  CA  ALA A   1      10.000  20.000  30.000  1.00  15.50           C"
    
    # 1. PDB parse
    res = parse_pdb_atom(line)
    
    # 2. Distance calculation
    d = euclidean_distance_3d((10.0, 20.0, 30.0), (13.0, 24.0, 30.0))
    
    # 3. RMSD identical
    coords = [(0.0, 0.0, 0.0), (3.0, 4.0, 0.0)]
    rmsd = calculate_rmsd(coords, coords)
    
    # 4. B-factor conversion
    u_sq, rmsf = b_factor_to_rmsf(78.956835)
    
    print(
        f"ATOM_ID:{res['atom_id']} NAME:{res['atom_name']} RES:{res['res_name']} "
        f"CHAIN:{res['chain']} RES_ID:{res['res_id']} "
        f"X:{res['x']:.3f} Y:{res['y']:.3f} Z:{res['z']:.3f} "
        f"OCC:{res['occupancy']:.2f} B_FACTOR:{res['b_factor']:.2f} "
        f"DIST_A:{d:.6f} RMSD_A:{rmsd:.6f} B_RMSF_A:{rmsf:.6f}"
    )


def practice_perturbation() -> None:
    ca = [(0.0, 0.0, 0.0), (0.0, 3.0, 0.0)]
    cb = [(0.0, 0.0, 0.0), (4.0, 0.0, 0.0)]
    rmsd = calculate_rmsd(ca, cb)
    print(f"PERTURBED_RMSD RMSD_A:{rmsd:.6f}")


def practice_domain_guard(line: str = "ATOM 1 CA") -> None:
    try:
        parse_pdb_atom(line)
        print(f"GUARD_LINE:{line} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_LINE:{line} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH11 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--line", type=str, default="ATOM 1 CA")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.line)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
