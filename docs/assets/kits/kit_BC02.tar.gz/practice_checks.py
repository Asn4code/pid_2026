#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH02: Biomoleculas como objetos computables."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    amino_acid_composition,
    hydropathy_profile,
    mean_hydropathy,
    protein_molecular_weight,
    validate_protein,
)


def practice_anchor() -> None:
    seq = "MKVLM"
    mw = protein_molecular_weight(seq)
    hydro = mean_hydropathy(seq)
    comp = amino_acid_composition(seq)
    comp_str = " ".join(f"{k}:{v}" for k, v in sorted(comp.items()))
    print(f"ANCHOR_PEPTIDE:{seq} LENGTH:{len(seq)} MW_DA:{mw:.3f} MEAN_HYDROPATHY:{hydro:.6f} COMPOSITION:{comp_str}")


def practice_perturbation(window: int = 3) -> None:
    seq = "MKVLM"
    prof = hydropathy_profile(seq, window=window)
    summary = ";".join(f"{p['start']}-{p['end']}:{p['sub']}:{p['score']:.2f}" for p in prof)
    print(f"PERTURBED_PEPTIDE:{seq} WINDOW:{window} PROFILE:{summary}")


def practice_domain_guard(seq: str = "MKVZX") -> None:
    try:
        validate_protein(seq)
        print(f"GUARD_PEPTIDE:{seq} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_PEPTIDE:{seq} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH02 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")

    p_pert = subparsers.add_parser("perturbation")
    p_pert.add_argument("--window", type=int, default=3)

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--seq", type=str, default="MKVZX")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation(args.window)
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.seq)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
