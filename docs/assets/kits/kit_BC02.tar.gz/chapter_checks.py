#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH02: Biomoleculas como objetos computables.

Implementa calculo de peso molecular de peptidos, perfil de hidropatia de Kyte-Doolittle,
composicion de aminoacidos, y verificacion de objetos computacionales.
"""

from __future__ import annotations

import argparse
import sys


AA_WEIGHTS: dict[str, float] = {
    "A": 71.08,
    "R": 156.19,
    "N": 114.10,
    "D": 115.09,
    "C": 103.14,
    "E": 129.12,
    "Q": 128.13,
    "G": 57.05,
    "H": 137.14,
    "I": 113.16,
    "L": 113.16,
    "K": 128.17,
    "M": 131.20,
    "F": 147.18,
    "P": 97.12,
    "S": 87.08,
    "T": 101.11,
    "W": 186.21,
    "Y": 163.18,
    "V": 99.13,
}

WATER_MW = 18.015

KYTE_DOOLITTLE: dict[str, float] = {
    "A": 1.8,
    "R": -4.5,
    "N": -3.5,
    "D": -3.5,
    "C": 2.5,
    "E": -3.5,
    "Q": -3.5,
    "G": -0.4,
    "H": -3.2,
    "I": 4.5,
    "L": 3.8,
    "K": -3.9,
    "M": 1.9,
    "F": 2.8,
    "P": -1.6,
    "S": -0.8,
    "T": -0.7,
    "W": -0.9,
    "Y": -1.3,
    "V": 4.2,
}


def validate_protein(seq: str) -> bool:
    valid_aas = set(AA_WEIGHTS.keys())
    upper_seq = seq.upper()
    invalid = set(upper_seq) - valid_aas
    if invalid:
        raise ValueError(f"Residuos invalidos detectados: {sorted(invalid)}")
    return True


def protein_molecular_weight(seq: str) -> float:
    upper_seq = seq.upper()
    if not upper_seq:
        return 0.0
    validate_protein(upper_seq)
    res_sum = sum(AA_WEIGHTS[aa] for aa in upper_seq)
    return res_sum + WATER_MW


def mean_hydropathy(seq: str) -> float:
    upper_seq = seq.upper()
    if not upper_seq:
        return 0.0
    validate_protein(upper_seq)
    return sum(KYTE_DOOLITTLE[aa] for aa in upper_seq) / len(upper_seq)


def hydropathy_profile(seq: str, window: int = 3) -> list[dict[str, float | int | str]]:
    upper_seq = seq.upper()
    validate_protein(upper_seq)
    n = len(upper_seq)
    if window > n:
        raise ValueError(f"Ventana ({window}) mayor que longitud de secuencia ({n})")
    results = []
    for i in range(n - window + 1):
        sub = upper_seq[i : i + window]
        score = sum(KYTE_DOOLITTLE[aa] for aa in sub) / window
        results.append({"start": i, "end": i + window, "sub": sub, "score": score})
    return results


def amino_acid_composition(seq: str) -> dict[str, int]:
    upper_seq = seq.upper()
    validate_protein(upper_seq)
    counts = {aa: upper_seq.count(aa) for aa in sorted(set(upper_seq))}
    return counts


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH02 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # mw
    p_mw = subparsers.add_parser("mw")
    p_mw.add_argument("seq", type=str)

    # hydropathy
    p_hydro = subparsers.add_parser("hydropathy")
    p_hydro.add_argument("seq", type=str)

    # hydro_profile
    p_prof = subparsers.add_parser("hydro_profile")
    p_prof.add_argument("seq", type=str)
    p_prof.add_argument("--window", type=int, default=3)

    # composition
    p_comp = subparsers.add_parser("composition")
    p_comp.add_argument("seq", type=str)

    # validate
    p_val = subparsers.add_parser("validate")
    p_val.add_argument("seq", type=str)

    args = parser.parse_args()

    if args.subcommand == "mw":
        val = protein_molecular_weight(args.seq)
        print(f"PEPTIDE:{args.seq.upper()} LENGTH:{len(args.seq)} MW_DA:{val:.3f}")
    elif args.subcommand == "hydropathy":
        val = mean_hydropathy(args.seq)
        print(f"PEPTIDE:{args.seq.upper()} MEAN_HYDROPATHY:{val:.6f}")
    elif args.subcommand == "hydro_profile":
        prof = hydropathy_profile(args.seq, args.window)
        summary = ";".join(f"{p['start']}-{p['end']}:{p['sub']}:{p['score']:.2f}" for p in prof)
        print(f"PEPTIDE:{args.seq.upper()} WINDOW:{args.window} PROFILE:{summary}")
    elif args.subcommand == "composition":
        comp = amino_acid_composition(args.seq)
        items = " ".join(f"{k}:{v}" for k, v in sorted(comp.items()))
        print(f"PEPTIDE:{args.seq.upper()} COMPOSITION:{items}")
    elif args.subcommand == "validate":
        try:
            validate_protein(args.seq)
            print(f"PEPTIDE:{args.seq.upper()} VALID:True")
        except ValueError as e:
            print(f"PEPTIDE:{args.seq.upper()} VALID:False ERROR:{e}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
