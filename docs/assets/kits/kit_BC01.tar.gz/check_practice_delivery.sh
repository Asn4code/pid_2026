#!/usr/bin/env bash
# check_practice_delivery.sh - Autocontrol de entrega para Practica BC01
set -e

DIR_ENTREGA="${1:-MiEntrega_BC01}"
if [ ! -d "$DIR_ENTREGA" ]; then
    echo "ERROR: No existe el directorio de entrega: $DIR_ENTREGA"
    exit 1
fi

echo "Verificando ejecucion de oraculos de la Practica BC01..."
python3 "$DIR_ENTREGA/src/practice_checks.py" > /dev/null 2>&1 || {
    echo "ERROR: Fallo en la ejecucion de practice_checks.py"
    exit 1
}

echo "[DELIVERY_OK] Practica BC01 verificada con exito (3.0 / 3.0 pts)"
