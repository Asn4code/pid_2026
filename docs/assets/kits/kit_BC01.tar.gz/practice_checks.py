#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH01."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    gc_content,
    reverse_complement,
    sliding_window_gc,
    validate_dna,
)


def practice_anchor() -> None:
    seq = "ATGCATGCGTCG"
    gc = gc_content(seq)
    rc = reverse_complement(seq)
    print(f"ANCHOR_SEQ:{seq} LENGTH:{len(seq)} GC_PERCENT:{gc:.6f} REV_COMP:{rc}")


def practice_window_perturbation(window: int = 6, step: int = 3) -> None:
    seq = "ATGCATGCGTCG"
    windows = sliding_window_gc(seq, window_size=window, step=step)
    summary = ";".join(f"{w['start']}-{w['end']}:{w['window']}:{w['gc_percent']:.1f}%" for w in windows)
    print(f"PERTURBED_SEQ:{seq} WINDOW:{window} STEP:{step} WINDOWS:{summary}")


def practice_domain_guard(seq: str = "ATGCZ") -> None:
    try:
        validate_dna(seq)
        print(f"GUARD_SEQ:{seq} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_SEQ:{seq} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH01 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    
    p_pert = subparsers.add_parser("perturbation")
    p_pert.add_argument("--window", type=int, default=6)
    p_pert.add_argument("--step", type=int, default=3)

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--seq", type=str, default="ATGCZ")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_window_perturbation(args.window, args.step)
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.seq)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
