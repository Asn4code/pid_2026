#!/bin/bash
set -euo pipefail

WORKSPACE="${1:-TC05_entrega}"
TARBALL="${2:-TC05_entrega.tar.gz}"

echo "[*] Verificando paquete de entrega para ${WORKSPACE}..."

if [ ! -d "${WORKSPACE}" ]; then
    echo "[-] ERROR: El directorio '${WORKSPACE}' no existe."
    exit 1
fi

for req in "notas/respuestas.tsv" "scripts/grado_red.sh" "scripts/recorrido_bfs.sh"; do
    if [ ! -f "${WORKSPACE}/${req}" ]; then
        echo "[-] ERROR: Falta el archivo obligatorio '${WORKSPACE}/${req}'."
        exit 1
    fi
done

# Probar ejecucion
echo "[+] Comprobando ejecución de scripts..."
bash "${WORKSPACE}/scripts/grado_red.sh" "${WORKSPACE}/datos/red_ppi.tsv" > /dev/null
bash "${WORKSPACE}/scripts/recorrido_bfs.sh" > /dev/null

if [ -f "${TARBALL}" ]; then
    echo "[+] Comprobando integridad del archivo comprimido '${TARBALL}'..."
    tar -tzf "${TARBALL}" > /dev/null
    echo "[+] Checksum SHA256: $(sha256sum "${TARBALL}")"
fi

echo "=========================================================="
echo "[+] ESTADO FINAL DE VERIFICACIÓN: DELIVERY_OK"
echo "[+] Rúbrica ADR-001: 3.0 / 3.0 puntos en entrega técnica"
echo "=========================================================="
exit 0
