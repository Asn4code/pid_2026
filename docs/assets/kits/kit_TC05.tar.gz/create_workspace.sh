#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC05_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC05 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/red_ppi.tsv" "${DEST_DIR}/datos/red_ppi.tsv"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
ejercicio_id	resultado_numerico	complejidad_algoritmica	justificacion_conceptual
P1_Grado_Hub_TP53	3	O(V + E)	TP53 tiene grado 3 en la red, actuando como hub central de interaccion.
P2_Nodo_Puente_BRCA1	2	Intermediacion_Alta	BRCA1 conecta el modulo TP53 con el modulo de reparacion RAD51/BARD1.
P3_BST_vs_Filogenia	Invariante_Orden	BST_Clave_vs_Filogenia_Ancestria	El BST ordena por clave alfabetica/numerica; la filogenia modela distancia evolutiva sin invariante izq<der.
EOTSV

# Scripts funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/grado_red.sh"
#!/usr/bin/env bash
set -euo pipefail
# Calcula el grado de cada proteina en la red
INPUT="${1:-datos/red_ppi.tsv}"

awk -F'	' 'NR>1 {
    deg[$1]++;
    deg[$2]++;
}
END {
    for (p in deg) {
        printf "%s	Grado: %d\n", p, deg[p];
    }
}' "${INPUT}" | sort -k2,2nr
EOS
chmod +x "${DEST_DIR}/scripts/grado_red.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/recorrido_bfs.sh"
#!/usr/bin/env bash
set -euo pipefail
# Simula un recorrido en anchura desde TP53
echo "[+] Recorrido BFS desde TP53:"
echo "Nivel 0: TP53"
echo "Nivel 1: MDM2, ATM, BRCA1"
echo "Nivel 2: RAD51, BARD1"
EOS
chmod +x "${DEST_DIR}/scripts/recorrido_bfs.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
