#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH13: Prediccion estructural con IA y evaluacion de confianza."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_mean_plddt,
    check_triangle_inequality,
    classify_plddt,
    evaluate_interdomain_pae,
)


def practice_anchor() -> None:
    # 1. pLDDT classification
    band = classify_plddt(92.5)
    
    # 2. Mean pLDDT
    m_plddt = calculate_mean_plddt([95.0, 92.0, 88.0, 45.0])
    
    # 3. Interdomain PAE
    pae_mat = [[2.5, 3.0], [3.0, 2.8]]
    mean_pae, pae_status = evaluate_interdomain_pae(pae_mat)
    
    # 4. Triangle inequality
    tri_valid = check_triangle_inequality(3.0, 4.0, 5.0)
    
    print(
        f"PLDDT_BAND:{band} MEAN_PLDDT:{m_plddt:.6f} "
        f"MEAN_PAE_A:{mean_pae:.6f} PAE_STATUS:{pae_status} "
        f"TRIANGLE_VALID:{tri_valid}"
    )


def practice_perturbation() -> None:
    band_idp = classify_plddt(42.0)
    pae_mat_flex = [[18.0, 22.0], [20.0, 24.0]]
    mean_pae, status = evaluate_interdomain_pae(pae_mat_flex)
    print(f"PERTURBED_IDP_BAND:{band_idp} PERTURBED_PAE_A:{mean_pae:.6f} PAE_STATUS:{status}")


def practice_domain_guard(score: float = 105.0) -> None:
    try:
        classify_plddt(score)
        print(f"GUARD_SCORE:{score} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_SCORE:{score} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH13 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--score", type=float, default=105.0)

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.score)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
