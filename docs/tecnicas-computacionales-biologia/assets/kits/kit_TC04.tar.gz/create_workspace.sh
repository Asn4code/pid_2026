#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC04_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC04 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/arn_secuencias.tsv" "${DEST_DIR}/datos/arn_secuencias.tsv"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
ejercicio_id	resultado_obtenido	complejidad_espacial	justificacion_conceptual
P1_Validacion_ARN_Pila	Valido:3_Invalido:2	O(n)	La pila almacena parentesis de apertura; cualquier desbalance o cierre sin apertura invalida la estructura.
P2_Cola_Circular_Buffer	Buffer_FIFO_Correcto	O(K)	Los punteros head y tail avanzan modulo K permitiendo reutilizar celdas sin reasignar memoria.
P3_Comparativa_Array_Lista	Array_O1_Acceso	O(n) vs O(1)	El array ofrece acceso indexado O(1) pero requiere O(n) para redimensionar; la lista permite insercion O(1).
EOTSV

# Scripts funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/validar_arn.sh"
#!/usr/bin/env bash
set -euo pipefail
# Validador de dot-bracket usando una pila en Bash
INPUT="${1:-datos/arn_secuencias.tsv}"

awk -F'	' 'NR>1 {
    seq = $2;
    len = length(seq);
    depth = 0;
    valid = 1;
    for (i=1; i<=len; i++) {
        c = substr(seq, i, 1);
        if (c == "(") depth++;
        else if (c == ")") {
            depth--;
            if (depth < 0) { valid = 0; break; }
        }
    }
    if (depth != 0) valid = 0;
    printf "%s	%s	%s\n", $1, seq, (valid ? "VALIDO" : "INVALIDO");
}' "${INPUT}"
EOS
chmod +x "${DEST_DIR}/scripts/validar_arn.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/cola_buffer.sh"
#!/usr/bin/env bash
set -euo pipefail
# Simula un buffer circular de tamaño 4
echo "[+] Buffer circular inicializado (K=4)"
echo "ENQUEUE: Read_1 -> [Read_1, -, -, -]"
echo "ENQUEUE: Read_2 -> [Read_1, Read_2, -, -]"
echo "DEQUEUE: Read_1 extraido"
echo "ENQUEUE: Read_3 -> [-, Read_2, Read_3, -]"
EOS
chmod +x "${DEST_DIR}/scripts/cola_buffer.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
