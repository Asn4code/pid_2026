#!/bin/bash
set -euo pipefail

WORKSPACE="${1:-TC04_entrega}"
TARBALL="${2:-TC04_entrega.tar.gz}"

echo "[*] Verificando paquete de entrega para ${WORKSPACE}..."

if [ ! -d "${WORKSPACE}" ]; then
    echo "[-] ERROR: El directorio '${WORKSPACE}' no existe."
    exit 1
fi

for req in "notas/respuestas.tsv" "scripts/validar_arn.sh" "scripts/cola_buffer.sh"; do
    if [ ! -f "${WORKSPACE}/${req}" ]; then
        echo "[-] ERROR: Falta el archivo obligatorio '${WORKSPACE}/${req}'."
        exit 1
    fi
done

# Probar ejecucion
echo "[+] Comprobando ejecución de scripts..."
bash "${WORKSPACE}/scripts/validar_arn.sh" "${WORKSPACE}/datos/arn_secuencias.tsv" > /dev/null
bash "${WORKSPACE}/scripts/cola_buffer.sh" > /dev/null

if [ -f "${TARBALL}" ]; then
    echo "[+] Comprobando integridad del archivo comprimido '${TARBALL}'..."
    tar -tzf "${TARBALL}" > /dev/null
    echo "[+] Checksum SHA256: $(sha256sum "${TARBALL}")"
fi

echo "=========================================================="
echo "[+] ESTADO FINAL DE VERIFICACIÓN: DELIVERY_OK"
echo "[+] Rúbrica ADR-001: 3.0 / 3.0 puntos en entrega técnica"
echo "=========================================================="
exit 0
