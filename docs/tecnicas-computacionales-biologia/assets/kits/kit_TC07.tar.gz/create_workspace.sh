#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC07_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC07 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/secuencias_entropia.fasta" "${DEST_DIR}/datos/secuencias_entropia.fasta"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
secuencia_id	longitud_nt	entropia_shannon_bits	interpretacion_incertidumbre
secuencia_homogenea	50	0.0000	Incertidumbre nula; fuente completamente predecible (H=0).
secuencia_heterogenea	50	2.0000	Maxima entropia para alfabeto cuaternario (log2(4) = 2 bits).
secuencia_isla_cpg	50	1.0000	Entropia binaria de 1 bit repartida exclusivamente entre C y G.
EOTSV

# Scripts funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/calcular_entropia.sh"
#!/usr/bin/env bash
set -euo pipefail
# Calcula entropia de Shannon de cada registro FASTA
INPUT="${1:-datos/secuencias_entropia.fasta}"

awk '
/^>/ {
    if (seq != "") { calcular_H(hdr, seq); }
    hdr = $0; seq = ""; next
}
{ seq = seq $0 }
END { if (seq != "") { calcular_H(hdr, seq); } }

function calcular_H(h, s) {
    len = length(s);
    if (len == 0) return;
    delete count;
    for (i=1; i<=len; i++) {
        c = toupper(substr(s, i, 1));
        count[c]++;
    }
    H = 0;
    for (c in count) {
        p = count[c] / len;
        if (p > 0) {
            # log2(p) = log(p)/log(2)
            H += - p * (log(p) / log(2));
        }
    }
    printf "%s	Longitud: %d	Entropia: %.4f bits\n", h, len, H;
}
' "${INPUT}"
EOS
chmod +x "${DEST_DIR}/scripts/calcular_entropia.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
