#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC01_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC01 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

# Copiar dataset inicial
cp "${SCRIPT_DIR}/datos/mini.fasta" "${DEST_DIR}/datos/secuencias.fasta"

# Crear plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
pregunta_id	respuesta_obtenida	justificacion_tecnica
P1	Ruta_Relativa_Dependiente_De_PWD	La ruta relativa datos/secuencias.fasta solo resuelve si el directorio de trabajo coincide.
P2	Lectura_Sin_Ejecucion	El permiso de lectura (r) permite inspeccionar bytes pero no cargar el archivo como proceso binario.
P3	Estado_Cero_No_Garantiza_Ciencia	El estado de salida 0 solo indica que el proceso termino sin atrapar errores fatales de sistema.
P4	Variables_No_Exportadas_Locales	Una variable local de shell no se copia al entorno del proceso hijo si no se exporta con export.
EOTSV

echo "[+] Espacio de trabajo '${DEST_DIR}' creado correctamente con datos y plantillas."
