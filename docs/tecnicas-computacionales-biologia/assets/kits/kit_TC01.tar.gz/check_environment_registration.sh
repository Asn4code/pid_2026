#!/bin/bash
set -euo pipefail

ENV_FILE="${1:-notas/entorno.tsv}"

if [ ! -f "${ENV_FILE}" ]; then
    echo "[-] ERROR: No se encuentra el archivo de registro de entorno '${ENV_FILE}'."
    exit 1
fi

# Verificar cabecera
HEADER=$(head -n 1 "${ENV_FILE}")
if ! echo "${HEADER}" | grep -q "parametro"; then
    echo "[-] ERROR: Cabecera inválida en '${ENV_FILE}'. Se esperaba columna 'parametro'."
    exit 1
fi

COUNT=$(wc -l < "${ENV_FILE}")
if [ "${COUNT}" -lt 4 ]; then
    echo "[-] ERROR: El registro de entorno debe contener al menos 4 líneas (cabecera + datos)."
    exit 1
fi

echo "[+] Registro de entorno '${ENV_FILE}' validado correctamente (${COUNT} líneas)."
exit 0
