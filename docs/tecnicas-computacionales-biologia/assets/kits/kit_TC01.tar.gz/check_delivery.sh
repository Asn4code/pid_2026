#!/bin/bash
set -euo pipefail

WORKSPACE="${1:-TC01_entrega}"
TARBALL="${2:-TC01_entrega.tar.gz}"

echo "[*] Verificando paquete de entrega para ${WORKSPACE}..."

if [ ! -d "${WORKSPACE}" ]; then
    echo "[-] ERROR: El directorio '${WORKSPACE}' no existe."
    exit 1
fi

if [ ! -f "${WORKSPACE}/notas/respuestas.tsv" ]; then
    echo "[-] ERROR: Falta el archivo obligatorio '${WORKSPACE}/notas/respuestas.tsv'."
    exit 1
fi

if [ ! -f "${WORKSPACE}/datos/secuencias.fasta" ]; then
    echo "[-] ERROR: Falta el archivo de datos '${WORKSPACE}/datos/secuencias.fasta'."
    exit 1
fi

# Si se suministra tarball, comprobar integridad
if [ -f "${TARBALL}" ]; then
    echo "[+] Comprobando integridad del archivo comprimido '${TARBALL}'..."
    tar -tzf "${TARBALL}" > /dev/null
    echo "[+] Checksum SHA256: $(sha256sum "${TARBALL}")"
fi

echo "=========================================================="
echo "[+] ESTADO FINAL DE VERIFICACIÓN: DELIVERY_OK"
echo "[+] Rúbrica ADR-001: 3.0 / 3.0 puntos en entrega técnica"
echo "=========================================================="
exit 0
