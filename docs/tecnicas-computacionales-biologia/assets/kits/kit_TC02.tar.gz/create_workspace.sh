#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC02_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC02 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/mini.fasta" "${DEST_DIR}/datos/secuencias.fasta"
cp "${SCRIPT_DIR}/datos/mini.fastq" "${DEST_DIR}/datos/lecturas.fastq"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
ejercicio_id	resultado_numerico	metodo_utilizado	justificacion_conceptual
P1_Conteo_Secuencias	3	grep -c '^>'	Cuenta exclusivamente lineas que inician con el delimitador canónico FASTA.
P2_Filtrado_Calidad	2	awk length y grep -v 'N'	Descarta lecturas con bases indeterminadas y longitud menor al umbral.
P3_Calculo_GC_Medio	58.33	awk con match de [GCgc]	Calcula el ratio de pares GC frente a longitud total de secuencia.
EOTSV

# Scripts de plantilla funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/programa1.sh"
#!/usr/bin/env bash
set -euo pipefail
# Cuenta secuencias FASTA de forma robusta
INPUT="${1:-datos/secuencias.fasta}"
grep -c '^>' "${INPUT}"
EOS
chmod +x "${DEST_DIR}/scripts/programa1.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/programa2.sh"
#!/usr/bin/env bash
set -euo pipefail
# Transcribe ADN a ARN sustituyendo T por U
INPUT="${1:-datos/secuencias.fasta}"
grep -v '^>' "${INPUT}" | sed 's/[Tt]/U/g'
EOS
chmod +x "${DEST_DIR}/scripts/programa2.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/programa3.sh"
#!/usr/bin/env bash
set -euo pipefail
# Calcula longitud y porcentaje GC por registro
INPUT="${1:-datos/secuencias.fasta}"
awk '
/^>/ { if (seq != "") { print_stats(hdr, seq); } hdr = $0; seq = ""; next }
{ seq = seq $0 }
END { if (seq != "") { print_stats(hdr, seq); } }
function print_stats(h, s) {
    len = length(s);
    gc = 0;
    for (i=1; i<=len; i++) {
        c = toupper(substr(s, i, 1));
        if (c == "G" || c == "C") gc++;
    }
    pct = (len > 0) ? (gc / len) * 100 : 0;
    printf "%s	Longitud: %d	GC: %.2f%%\n", h, len, pct;
}
' "${INPUT}"
EOS
chmod +x "${DEST_DIR}/scripts/programa3.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
