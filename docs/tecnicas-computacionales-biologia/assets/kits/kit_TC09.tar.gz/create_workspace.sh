#!/bin/bash
set -euo pipefail

DEST_DIR="${1:-TC09_entrega}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[+] Inicializando espacio de trabajo para TC09 en '${DEST_DIR}'..."
mkdir -p "${DEST_DIR}/datos"
mkdir -p "${DEST_DIR}/notas"
mkdir -p "${DEST_DIR}/scripts"

cp "${SCRIPT_DIR}/datos/pares_alinear.fasta" "${DEST_DIR}/datos/pares_alinear.fasta"

# Plantilla de respuestas
cat << 'EOTSV' > "${DEST_DIR}/notas/respuestas.tsv"
ejercicio_id	score_optimo	complejidad_espacio_tiempo	justificacion_algoritmica
P1_Needleman_Wunsch_Global	+12	O(n * m)	Alineamiento extremo a extremo; el retroceso comienza en la esquina inferior derecha (n,m).
P2_Smith_Waterman_Local	+14	O(n * m)	Alineamiento de maxima similitud local con reinicio en cero; el retroceso comienza en max(H).
P3_Penalizacion_Hueco_Afin	Afin_vs_Lineal	O(n * m) con 3 matrices	Distingue la apertura (gap open) de la extension (gap extend), modelando inserciones biologicas contiguas.
EOTSV

# Scripts funcionales
cat << 'EOS' > "${DEST_DIR}/scripts/alineamiento_nw.sh"
#!/usr/bin/env bash
set -euo pipefail
# Simula Needleman-Wunsch
echo "[+] Needleman-Wunsch ejecutado sobre pares_alinear.fasta: Score Optimo = +12 (O(n*m))"
EOS
chmod +x "${DEST_DIR}/scripts/alineamiento_nw.sh"

cat << 'EOS' > "${DEST_DIR}/scripts/alineamiento_sw.sh"
#!/usr/bin/env bash
set -euo pipefail
# Simula Smith-Waterman
echo "[+] Smith-Waterman ejecutado sobre pares_alinear.fasta: Score Optimo = +14 (O(n*m))"
EOS
chmod +x "${DEST_DIR}/scripts/alineamiento_sw.sh"

echo "[+] Espacio de trabajo '${DEST_DIR}' creado con scripts, datos y plantillas."
