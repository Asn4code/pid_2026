#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH06."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Comparativa de las tres generaciones de secuenciación desde Sanger capilar hasta Illumina y moléculas individuales PacBio o Nanoporo.",
    "F02": "Modelo de Poisson de Lander-Waterman que muestra la caída exponencial de bases no cubiertas con el incremento de cobertura de secuenciación.",
    "F03": "Perfil de sesgo en cobertura por contenido GC con atenuación en regiones ricas en AT o GC extremas."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC06-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC06-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC06-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH06 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC06-F01: Comparativa de 3 generaciones NGS."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    cards = [
        ("1ª Gen: Sanger", "Terminación ddNTPs\nLongitud: $800\\text{ pb}$\nPrecisión: $99.99\\%$\nRendimiento bajo", 1.8, 2.2, BLUE),
        ("2ª Gen: Illumina", "Secuenciación por síntesis\nPuentes / Celdas de flujo\n$150\\text{--}300\\text{ pb}$ paired-end\nUltra-alto rendimiento", 5.0, 2.2, GREEN),
        ("3ª Gen: PacBio / ONT", "Molécula individual\nHiFi ($>15\\text{ kb}, 99.9\\%$)\nNanoporo ($>50\\text{ kb}$)\nLectura de variantes complejas", 8.2, 2.2, ORANGE)
    ]
    for title, desc, cx, cy, col in cards:
        cbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(cbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8.5)

    save(fig, "F01")

def f02():
    """BC06-F02: Modelo de Poisson de Lander-Waterman."""
    fig, ax = plt.subplots(figsize=(6.8, 3.8), dpi=300)
    C = np.linspace(0, 10, 200)
    P_zero = np.exp(-C)
    coverage_fraction = 1.0 - P_zero

    ax.plot(C, P_zero * 100, label="Bases no cubiertas $P(0) = e^{-C}$ (\\%)", color=RED, lw=2.2)
    ax.plot(C, coverage_fraction * 100, label="Fracción cubierta $1 - e^{-C}$ (\\%)", color=GREEN, lw=2.2)

    ax.axvline(3.0, color=GRAY, ls=":", lw=1.2)
    ax.text(3.1, 50, "$C=3.0X \\to P(0)=4.98\\%$", color=GRAY, fontsize=8.5)

    ax.set_xlabel("Profundidad de Cobertura Media ($C$)", fontsize=9.5)
    ax.set_ylabel("Porcentaje del Genoma (\\%)", fontsize=9.5)
    ax.set_title("Estadística de Cobertura de Lander-Waterman", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 105)
    ax.legend(frameon=True, facecolor=LIGHT, edgecolor="none", fontsize=8.5)
    ax.grid(True, linestyle=":", alpha=0.6)

    save(fig, "F02")

def f03():
    """BC06-F03: Sesgo GC en cobertura NGS."""
    fig, ax = plt.subplots(figsize=(6.8, 3.8), dpi=300)
    gc = np.linspace(10, 90, 200)
    # Bell shaped curve peaking around 45-50% GC
    cov_rel = np.exp(-((gc - 48)**2) / 350)

    ax.plot(gc, cov_rel, color=BLUE, lw=2.5, label="Cobertura Relativa Normalizada")
    ax.axvspan(35, 60, color="#EAF2EC", alpha=0.8, label="Ventana Óptima de Cobertura ($35\\text{--}60\\%$)")

    ax.set_xlabel("Contenido GC del Fragmento (\\%)", fontsize=9.5)
    ax.set_ylabel("Cobertura Normalizada Relativa", fontsize=9.5)
    ax.set_title("Sesgo de Amplificación por Contenido GC en NGS", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_xlim(10, 90)
    ax.set_ylim(0, 1.15)
    ax.legend(frameon=True, facecolor="white", edgecolor="none", fontsize=8.5)
    ax.grid(True, linestyle=":", alpha=0.6)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
