#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH10."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Lógica molecular del operón Lac en sus cuatro estados metabólicos según la disponibilidad combinada de glucosa y lactosa.",
    "F02": "Mapa vectorial y anatomía modular de un plásmido de expresión procariota con promotor T7, etiqueta His6 y marcador de selección.",
    "F03": "Comparativa de ensamblaje molecular entre digestión clásica, reacción isotérmica de Gibson y clonación Golden Gate con enzimas tipo IIS."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC10-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC10-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC10-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH10 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC10-F01: Lógica molecular del operón Lac."""
    fig, ax = plt.subplots(figsize=(8.5, 4.0), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.2, "Lógica Combinatoria del Operón Lac (E. coli)", ha="center", color=BLUE, fontweight="bold", fontsize=11)

    states = [
        ("+Glucosa / -Lactosa", "CAP Inactivo\nLacI Unido a Operador\nTranscripción Basal Nula (1X)", 1.4, 2.2, GRAY),
        ("+Glucosa / +Lactosa", "CAP Inactivo\nLacI Inducido (Libre)\nTranscripción Baja (10X)", 3.8, 2.2, ORANGE),
        ("-Glucosa / -Lactosa", "CAP-cAMP Activo Unido\nLacI Unido (Bloqueo)\nTranscripción Nula (1X)", 6.2, 2.2, RED),
        ("-Glucosa / +Lactosa", "CAP-cAMP Activo Unido\nLacI Inducido (Libre)\nINDUCCIÓN MÁXIMA (1000X)", 8.6, 2.2, GREEN)
    ]
    for title, desc, cx, cy, col in states:
        sbox = FancyBboxPatch((cx-1.1, cy-1.4), 2.2, 2.8, boxstyle="round,pad=0.1", fc="white", ec=col, lw=2)
        ax.add_patch(sbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=8.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8)

    save(fig, "F01")

def f02():
    """BC10-F02: Anatomía de un plásmido de expresión."""
    fig, ax = plt.subplots(figsize=(5.5, 4.5), dpi=300)
    ax.set_xlim(-3.5, 3.5)
    ax.set_ylim(-3.5, 3.5)
    ax.axis("off")

    # Plasmid ring
    circle = Circle((0, 0), 2.2, fc="white", ec=BLUE, lw=3)
    ax.add_patch(circle)
    inner = Circle((0, 0), 1.6, fc="#F4F7F9", ec="none")
    ax.add_patch(inner)

    ax.text(0, 0.2, "Vector de Expresión\n(pET-28a)", ha="center", va="center", color=BLUE, fontweight="bold", fontsize=10)
    ax.text(0, -0.4, "$\\approx 5.3\\text{ kb}$", ha="center", color=GRAY, fontsize=8.5)

    # Features
    features = [
        (0, 2.2, "Promotor T7 / lacO\n(Inducible IPTG)", GREEN),
        (2.2, 0.5, "His6-tag / MCS\n(Inserto)", ORANGE),
        (1.5, -1.8, "Terminador T7", GRAY),
        (-1.8, -1.5, "Resistencia KanR/AmpR\n(Marcador Selección)", RED),
        (-2.2, 0.8, "Origen ori (pBR322)\n(Replicación)", BLUE)
    ]
    for fx, fy, ftext, fcol in features:
        p = Circle((fx*0.88, fy*0.88), 0.18, fc=fcol, ec="white", lw=1)
        ax.add_patch(p)
        ax.text(fx*1.3, fy*1.3, ftext, ha="center", va="center", color=fcol, fontweight="bold", fontsize=7.5)

    save(fig, "F02")

def f03():
    """BC10-F03: Métodos de ensamblaje molecular."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.1, "Comparativa de Métodos de Ensamblaje Molecular", ha="center", color=BLUE, fontweight="bold", fontsize=11)

    methods = [
        ("1. Restricción / Ligación", "Enzimas clásicas tipo II\nCortes cohesivos o romos\nLimitado por cicatrices\ny dianas internas", 1.8, 2.0, ORANGE),
        ("2. Ensamblaje de Gibson", "Reacción isotérmica a $50^\\circ\\text{C}$:\n1. Exonucleasa $5' \\to 3'$\n2. Hibridación solapante ($20\\text{--}40\\text{ pb}$)\n3. Polimerasa + Ligasa Taq", 5.0, 2.0, GREEN),
        ("3. Golden Gate (Tipo IIS)", "Enzimas tipo IIS (BsaI)\nCorte fuera de diana\nEnsamblaje modular sin cicatriz\nUnión de múltiples fragmentos", 8.2, 2.0, BLUE)
    ]
    for title, desc, cx, cy, col in methods:
        mbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(mbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
