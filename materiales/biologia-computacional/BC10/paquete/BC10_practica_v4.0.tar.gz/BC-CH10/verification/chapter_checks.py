#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH10: Regulacion, clonacion y vectores recombinantes.

Implementa calculo termodinamico de Tm de primers, analisis de estados del operon Lac,
deteccion de dianas de restriccion y comprobacion de solapamientos de ensamblaje Gibson.
"""

from __future__ import annotations

import argparse
import sys


def calculate_gc_percent(seq: str) -> float:
    seq = seq.upper()
    if not seq:
        raise ValueError("Secuencia no puede estar vacia")
    gc = sum(1 for c in seq if c in ("G", "C"))
    return (gc / len(seq)) * 100.0


def calculate_primer_tm(seq: str) -> float:
    seq = seq.upper()
    n = len(seq)
    if n < 10:
        raise ValueError("El primer debe tener al menos 10 nucleotidos")
    gc = calculate_gc_percent(seq)
    # Formula estandar de desnaturalizacion con correccion salina: Tm = 81.5 + 0.41*(%GC) - 675/N
    tm = 81.5 + (0.41 * gc) - (675.0 / n)
    return tm


def operon_lac_state(glucose: bool, lactose: bool) -> tuple[str, float]:
    if glucose and not lactose:
        return ("CAP_INACTIVO_LACI_UNIDO", 1.0)
    elif glucose and lactose:
        return ("CAP_INACTIVO_LACI_LIBRE", 10.0)
    elif not glucose and not lactose:
        return ("CAP_ACTIVO_LACI_UNIDO", 1.0)
    else:  # not glucose and lactose
        return ("CAP_ACTIVO_LACI_LIBRE", 1000.0)


def find_restriction_sites(seq: str) -> dict[str, list[int]]:
    seq = seq.upper()
    enzymes = {
        "EcoRI": "GAATTC",
        "BamHI": "GGATCC",
        "HindIII": "AAGCTT",
        "NdeI": "CATATG",
        "XhoI": "CTCGAG",
    }
    hits: dict[str, list[int]] = {}
    for name, motif in enzymes.items():
        pos_list: list[int] = []
        start = 0
        while True:
            idx = seq.find(motif, start)
            if idx == -1:
                break
            pos_list.append(idx + 1)  # 1-based
            start = idx + 1
        if pos_list:
            hits[name] = pos_list
    return hits


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH10 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # tm
    p_tm = subparsers.add_parser("primer_tm")
    p_tm.add_argument("--seq", type=str, default="GGAATTCATGGTGAGCAAGGGCGAG")

    # lac
    p_lac = subparsers.add_parser("lac_operon")
    p_lac.add_argument("--glucose", action="store_true")
    p_lac.add_argument("--lactose", action="store_true")

    # digest
    p_res = subparsers.add_parser("restriction")
    p_res.add_argument("--seq", type=str, default="GGAATTCATGGTGAGCAAGGGCGAG")

    args = parser.parse_args()

    if args.subcommand == "primer_tm":
        try:
            gc = calculate_gc_percent(args.seq)
            tm = calculate_primer_tm(args.seq)
            print(f"PRIMER:{args.seq} LEN:{len(args.seq)} GC_PCT:{gc:.2f} TM_C:{tm:.2f}")
        except ValueError as e:
            # la guarda de longitud minima informa por la salida estandar
            print(f"PRIMER:{args.seq} VALID:False ERROR:{e}")
    elif args.subcommand == "lac_operon":
        state, expr = operon_lac_state(args.glucose, args.lactose)
        print(f"GLUCOSE:{args.glucose} LACTOSE:{args.lactose} STATE:{state} EXPR_RATIO:{expr:.1f}")
    elif args.subcommand == "restriction":
        sites = find_restriction_sites(args.seq)
        sites_str = ";".join(f"{k}:{','.join(str(p) for p in v)}" for k, v in sorted(sites.items()))
        print(f"SEQ_LEN:{len(args.seq)} SITES:{sites_str}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
