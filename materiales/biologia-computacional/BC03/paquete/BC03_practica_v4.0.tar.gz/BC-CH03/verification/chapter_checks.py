#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH03: Genomas, epigenetica y variantes.

Implementa clasificacion de mutaciones en transiciones/transversiones, ratio Ti/Tv,
consecuencias funcionales de variantes codificantes (sinonimas, missense, nonsense),
parsing de formato VCF y analisis de islas CpG.
"""

from __future__ import annotations

import argparse
import sys


GENETIC_CODE: dict[str, str] = {
    "TTT": "F", "TTC": "F", "TTA": "L", "TTG": "L",
    "TCT": "S", "TCC": "S", "TCA": "S", "TCG": "S",
    "TAT": "Y", "TAC": "Y", "TAA": "*", "TAG": "*",
    "TGT": "C", "TGC": "C", "TGA": "*", "TGG": "W",
    "CTT": "L", "CTC": "L", "CTA": "L", "CTG": "L",
    "CCT": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAT": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGT": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "ATT": "I", "ATC": "I", "ATA": "I", "ATG": "M",
    "ACT": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAT": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGT": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GTT": "V", "GTC": "V", "GTA": "V", "GTG": "V",
    "GCT": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAT": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGT": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

PURINES = {"A", "G"}
PYRIMIDINES = {"C", "T"}


def classify_snv(ref: str, alt: str) -> str:
    r = ref.upper()
    a = alt.upper()
    if r not in (PURINES | PYRIMIDINES) or a not in (PURINES | PYRIMIDINES):
        raise ValueError(f"Bases no validas: ref={ref}, alt={alt}")
    if r == a:
        raise ValueError("REF y ALT son identicos; no es una variante")
    if (r in PURINES and a in PURINES) or (r in PYRIMIDINES and a in PYRIMIDINES):
        return "TRANSITION"
    return "TRANSVERSION"


def calculate_titv(variants: list[tuple[str, str]]) -> dict[str, float | int]:
    ti = 0
    tv = 0
    for ref, alt in variants:
        cls = classify_snv(ref, alt)
        if cls == "TRANSITION":
            ti += 1
        else:
            tv += 1
    ratio = (ti / tv) if tv > 0 else float("inf")
    return {"TI": ti, "TV": tv, "RATIO": ratio}


def classify_mutation(ref_codon: str, alt_codon: str) -> dict[str, str]:
    rc = ref_codon.upper().replace("U", "T")
    ac = alt_codon.upper().replace("U", "T")
    if len(rc) != 3 or len(ac) != 3:
        raise ValueError(f"Codones deben tener longitud 3: {ref_codon}, {alt_codon}")
    ref_aa = GENETIC_CODE.get(rc, "?")
    alt_aa = GENETIC_CODE.get(ac, "?")
    if ref_aa == "?" or alt_aa == "?":
        raise ValueError(f"Codon invalido detectado: {ref_codon} o {alt_codon}")
    if ref_aa == alt_aa:
        effect = "SYNONYMOUS"
    elif alt_aa == "*" and ref_aa != "*":
        effect = "NONSENSE"
    elif ref_aa == "*" and alt_aa != "*":
        effect = "STOP_LOST"
    else:
        effect = "MISSENSE"
    return {"REF_CODON": rc, "ALT_CODON": ac, "REF_AA": ref_aa, "ALT_AA": alt_aa, "EFFECT": effect}


def parse_vcf_record(line: str) -> dict[str, str]:
    fields = line.strip().split("\t")
    if len(fields) < 8:
        fields = line.strip().split()
    if len(fields) < 8:
        raise ValueError(f"Linea VCF incompleta ({len(fields)} campos): {line}")
    chrom, pos, var_id, ref, alt, qual, flt, info = fields[:8]
    snv_type = classify_snv(ref, alt) if (len(ref) == 1 and len(alt) == 1) else "INDEL"
    return {
        "CHROM": chrom,
        "POS": pos,
        "ID": var_id,
        "REF": ref,
        "ALT": alt,
        "QUAL": qual,
        "FILTER": flt,
        "SNV_TYPE": snv_type,
    }


def cpg_island_metrics(seq: str) -> dict[str, float | int]:
    upper_seq = seq.upper()
    n = len(upper_seq)
    if n == 0:
        return {"LENGTH": 0, "GC_PERCENT": 0.0, "OBS_EXP": 0.0}
    c_count = upper_seq.count("C")
    g_count = upper_seq.count("G")
    gc_pct = ((c_count + g_count) / n) * 100.0
    cpg_obs = upper_seq.count("CG")
    cpg_exp = (c_count * g_count) / n
    obs_exp = (cpg_obs / cpg_exp) if cpg_exp > 0 else 0.0
    return {"LENGTH": n, "GC_PERCENT": gc_pct, "OBS_CPG": cpg_obs, "OBS_EXP": obs_exp}


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH03 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # classify_snv
    p_snv = subparsers.add_parser("snv")
    p_snv.add_argument("ref", type=str)
    p_snv.add_argument("alt", type=str)

    # titv
    p_titv = subparsers.add_parser("titv")
    p_titv.add_argument("variants", nargs="+", help="Pairs of REF:ALT, e.g., A:G C:T A:C")

    # mutation
    p_mut = subparsers.add_parser("mutation")
    p_mut.add_argument("ref_codon", type=str)
    p_mut.add_argument("alt_codon", type=str)

    # vcf
    p_vcf = subparsers.add_parser("vcf")
    p_vcf.add_argument("line", type=str)

    # cpg
    p_cpg = subparsers.add_parser("cpg")
    p_cpg.add_argument("seq", type=str)

    args = parser.parse_args()

    if args.subcommand == "snv":
        res = classify_snv(args.ref, args.alt)
        print(f"REF:{args.ref.upper()} ALT:{args.alt.upper()} CLASS:{res}")
    elif args.subcommand == "titv":
        pairs = []
        for pair in args.variants:
            r, a = pair.split(":")
            pairs.append((r, a))
        res = calculate_titv(pairs)
        print(f"TI:{res['TI']} TV:{res['TV']} RATIO:{res['RATIO']:.6f}")
    elif args.subcommand == "mutation":
        try:
            res = classify_mutation(args.ref_codon, args.alt_codon)
        except ValueError as e:
            # la guarda de dominio es parte de lo que el capitulo ensena: se
            # informa del rechazo en la salida estandar, sin abortar
            print(f"REF:{args.ref_codon.upper()} ALT:{args.alt_codon.upper()} VALID:False ERROR:{e}")
        else:
            print(f"REF:{res['REF_CODON']}({res['REF_AA']}) ALT:{res['ALT_CODON']}({res['ALT_AA']}) EFFECT:{res['EFFECT']}")
    elif args.subcommand == "vcf":
        res = parse_vcf_record(args.line)
        print(f"CHROM:{res['CHROM']} POS:{res['POS']} ID:{res['ID']} REF:{res['REF']} ALT:{res['ALT']} TYPE:{res['SNV_TYPE']} FILTER:{res['FILTER']}")
    elif args.subcommand == "cpg":
        res = cpg_island_metrics(args.seq)
        print(f"SEQ:{args.seq.upper()} LENGTH:{res['LENGTH']} GC_PERCENT:{res['GC_PERCENT']:.2f} OBS_CPG:{res['OBS_CPG']} OBS_EXP:{res['OBS_EXP']:.6f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
