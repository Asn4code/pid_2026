#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH03."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Estructura del nucleosoma que muestra 146 pares de bases de ADN enrollados 1.65 vueltas alrededor del octámero de histonas y marcas epigenéticas.",
    "F02": "Distribución bimodal de islas CpG con enriquecimiento Obs frente a Exp mayor a 0.6 en promotores activos frente al genoma global hipermetilado.",
    "F03": "Espacio de mutaciones puntuales que distingue transiciones entre bases del mismo anillo químico de transversiones y formato VCF versión 4.2."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC03-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC03-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC03-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH03 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC03-F01: Estructura del nucleosoma y código de histonas."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Histone Octamer Core
    core = FancyBboxPatch((2.5, 1.2), 3.4, 2.4, boxstyle="round,pad=0.2", fc="#EAE4D8", ec=ORANGE, lw=2.5)
    ax.add_patch(core)
    ax.text(4.2, 2.7, "Octámero de Histonas\n$(H2A, H2B, H3, H4)_2$", ha="center", color=ORANGE, fontweight="bold", fontsize=10)
    ax.text(4.2, 1.7, "Carga básica positiva\n(Lisinas y Argininas)", ha="center", color=GRAY, fontsize=8.5)

    # DNA wrap
    dna_outer = FancyBboxPatch((2.1, 0.8), 4.2, 3.2, boxstyle="round,pad=0.15", fc="none", ec=BLUE, lw=3.5, ls="-")
    ax.add_patch(dna_outer)
    ax.text(4.2, 0.35, "ADN bicatenario: $146\\text{ pb}$ ($1.65$ vueltas superhelicoidales levógiras)", ha="center", color=BLUE, fontweight="bold", fontsize=9)

    # Histone tails and marks
    # Active mark H3K4me3 / H3K27ac
    t1 = FancyArrowPatch((5.9, 3.0), (8.2, 3.5), arrowstyle="->", color=GREEN, lw=2)
    ax.add_patch(t1)
    ax.text(8.3, 3.5, "H3K4me3 / H3K27ac\n(Cromatina Abierta / Eucromatina)", ha="left", va="center", color=GREEN, fontweight="bold", fontsize=8.5)

    # Repressive mark H3K9me3 / H3K27me3
    t2 = FancyArrowPatch((5.9, 1.8), (8.2, 1.3), arrowstyle="->", color=RED, lw=2)
    ax.add_patch(t2)
    ax.text(8.3, 1.3, "H3K9me3 / H3K27me3\n(Heterocromatina Represiva)", ha="left", va="center", color=RED, fontweight="bold", fontsize=8.5)

    # Linker histone H1
    h1 = Circle((1.7, 2.4), 0.5, fc=LIGHT, ec=GRAY, lw=1.8)
    ax.add_patch(h1)
    ax.text(1.7, 2.4, "H1\nLinker", ha="center", va="center", color=GRAY, fontsize=8, fontweight="bold")

    save(fig, "F01")

def f02():
    """BC03-F02: Distribución bimodal de islas CpG."""
    fig, ax = plt.subplots(figsize=(7.0, 3.8), dpi=300)
    x = np.linspace(0, 1.4, 200)

    # Bimodal distribution: bulk genome (depleted, unmethylated/deaminated) vs CpG Islands (promoters)
    bulk = 2.8 * np.exp(-((x - 0.22)**2) / 0.015)
    cpg_islands = 1.2 * np.exp(-((x - 0.85)**2) / 0.035)
    y = bulk + cpg_islands

    ax.plot(x, y, color=BLUE, lw=2.2)
    ax.fill_between(x, y, color=LIGHT, alpha=0.8)

    # Threshold line
    ax.axvline(0.6, color=RED, ls="--", lw=1.8, label="Umbral Gardiner-Frommer ($Obs/Exp \\geq 0.6$)")
    ax.fill_between(x[x >= 0.6], y[x >= 0.6], color="#D5E8D4", alpha=0.6, label="Islas CpG en Promotores")

    ax.text(0.22, 2.2, "Genoma Global\n(Metilado / Deaminado\n$Obs/Exp \\approx 0.2$)", ha="center", color=GRAY, fontsize=8.5)
    ax.text(0.95, 1.1, "Islas CpG Promotoras\n(Hipometiladas\n$Obs/Exp > 0.6$)", ha="center", color=GREEN, fontweight="bold", fontsize=8.5)

    ax.set_xlabel("Ratio CpG Observado / Esperado ($\\text{Obs}/\\text{Exp}$)", fontsize=9.5)
    ax.set_ylabel("Densidad de Frecuencia Genómica", fontsize=9.5)
    ax.set_title("Distribución Bimodal del Ratio CpG en el Genoma Humano", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_xlim(0, 1.4)
    ax.set_ylim(0, 3.2)
    ax.legend(frameon=True, facecolor="white", edgecolor="none", fontsize=8.5, loc="upper right")
    ax.grid(True, linestyle=":", alpha=0.6)

    save(fig, "F02")

def f03():
    """BC03-F03: Espacio de mutaciones Ti/Tv y formato VCFv4.2."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Purines box
    purb = FancyBboxPatch((0.8, 2.0), 3.0, 2.0, boxstyle="round,pad=0.15", fc="white", ec=BLUE, lw=2)
    ax.add_patch(purb)
    ax.text(2.3, 3.7, "Purinas (Doble Anillo)", ha="center", color=BLUE, fontweight="bold", fontsize=9.5)
    ax.text(1.4, 2.7, "A", fontsize=16, fontweight="bold", color=BLUE, ha="center")
    ax.text(3.2, 2.7, "G", fontsize=16, fontweight="bold", color=BLUE, ha="center")
    # Transition arrow A <-> G
    ax.add_patch(FancyArrowPatch((1.7, 2.7), (2.9, 2.7), arrowstyle="<->", color=BLUE, lw=2.5))
    ax.text(2.3, 2.9, "Ti (1)", ha="center", color=BLUE, fontsize=8, fontweight="bold")

    # Pyrimidines box
    pyrb = FancyBboxPatch((5.8, 2.0), 3.0, 2.0, boxstyle="round,pad=0.15", fc="white", ec=ORANGE, lw=2)
    ax.add_patch(pyrb)
    ax.text(7.3, 3.7, "Pirimidinas (Anillo Simple)", ha="center", color=ORANGE, fontweight="bold", fontsize=9.5)
    ax.text(6.4, 2.7, "C", fontsize=16, fontweight="bold", color=ORANGE, ha="center")
    ax.text(8.2, 2.7, "T", fontsize=16, fontweight="bold", color=ORANGE, ha="center")
    # Transition arrow C <-> T
    ax.add_patch(FancyArrowPatch((6.7, 2.7), (7.9, 2.7), arrowstyle="<->", color=ORANGE, lw=2.5))
    ax.text(7.3, 2.9, "Ti (2)", ha="center", color=ORANGE, fontsize=8, fontweight="bold")

    # Transversions crossing between boxes
    ax.add_patch(FancyArrowPatch((3.8, 2.7), (5.8, 2.7), arrowstyle="<->", color=RED, lw=2, ls="--"))
    ax.text(4.8, 2.9, "Tv (Transversiones: 8 tipos)", ha="center", color=RED, fontsize=8, fontweight="bold")

    # VCF format mini box below
    vbox = FancyBboxPatch((0.5, 0.2), 9.0, 1.2, boxstyle="round,pad=0.1", fc=LIGHT, ec=GRAY, lw=1.2)
    ax.add_patch(vbox)
    ax.text(5.0, 1.05, "Anatomía de Registro VCFv4.2 (1-based)", ha="center", color=BLUE, fontweight="bold", fontsize=9)
    vcf_line = "CHROM:chr11   POS:5227002   ID:rs334   REF:T   ALT:A   QUAL:99.0   FILTER:PASS   INFO:AF=0.08"
    ax.text(5.0, 0.55, vcf_line, ha="center", va="center", fontfamily="monospace", fontsize=8, color=GRAY)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
