#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH03: Genomas, epigenetica y variantes."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_titv,
    classify_mutation,
    cpg_island_metrics,
    parse_vcf_record,
)


def practice_anchor() -> None:
    # 1. Parse VCF line for sickle cell anemia (HBB rs334)
    vcf_line = "chr11\t5227002\trs334\tT\tA\t100.0\tPASS\tGENE=HBB;DISEASE=SICKLE_CELL"
    vcf_res = parse_vcf_record(vcf_line)
    
    # 2. Codon effect (GAG -> GTG, Glu6Val)
    mut_res = classify_mutation("GAG", "GTG")
    
    # 3. Base Ti/Tv batch (4 Ti, 2 Tv)
    batch = [("A", "G"), ("G", "A"), ("C", "T"), ("T", "C"), ("A", "C"), ("T", "G")]
    titv_res = calculate_titv(batch)
    
    print(f"VCF_ID:{vcf_res['ID']} POS:{vcf_res['POS']} TYPE:{vcf_res['SNV_TYPE']} EFFECT:{mut_res['EFFECT']} REF_AA:{mut_res['REF_AA']} ALT_AA:{mut_res['ALT_AA']} TI:{titv_res['TI']} TV:{titv_res['TV']} TITV_RATIO:{titv_res['RATIO']:.6f}")


def practice_perturbation() -> None:
    # Perturbed batch: add extra transversion (G:C) -> 4 Ti, 3 Tv
    batch = [("A", "G"), ("G", "A"), ("C", "T"), ("T", "C"), ("A", "C"), ("T", "G"), ("G", "C")]
    titv_res = calculate_titv(batch)
    print(f"PERTURBED_TITV TI:{titv_res['TI']} TV:{titv_res['TV']} RATIO:{titv_res['RATIO']:.6f}")


def practice_domain_guard(ref_codon: str = "GAX", alt_codon: str = "GTG") -> None:
    try:
        classify_mutation(ref_codon, alt_codon)
        print(f"GUARD_MUTATION:{ref_codon}->{alt_codon} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_MUTATION:{ref_codon}->{alt_codon} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH03 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--ref", type=str, default="GAX")
    p_guard.add_argument("--alt", type=str, default="GTG")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.ref, args.alt)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
