#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH08."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Comparativa entre programación dinámica exacta y el paradigma heurístico de semillas y extensión seed-and-extend.",
    "F02": "Estructura del FM-index que muestra la transformada de Burrows-Wheeler y la búsqueda hacia atrás por LF-mapping.",
    "F03": "Operaciones de la cadena CIGAR en formato SAM que ilustran el consumo de coordenadas en secuencia y genoma."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC08-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC08-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC08-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH08 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC08-F01: Dinámica vs Seed-and-Extend."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Panel 1: Exact Smith-Waterman
    b1 = FancyBboxPatch((0.6, 0.4), 4.0, 3.7, boxstyle="round,pad=0.15", fc="white", ec=RED, lw=2)
    ax.add_patch(b1)
    ax.text(2.6, 3.7, "Programación Dinámica Exacta\n(Smith-Waterman)", ha="center", color=RED, fontweight="bold", fontsize=10)
    ax.text(2.6, 2.7, "Matriz Completa $M \\times N$\nComplejidad: $O(M \\cdot N)$\nÓptimo riguroso\nInviable para $10^8$ lecturas", ha="center", va="center", color=GRAY, fontsize=9)
    ax.text(2.6, 1.0, "Tiempo humano: Años", ha="center", color=RED, fontweight="bold", fontsize=9.5)

    # Panel 2: Seed-and-Extend
    b2 = FancyBboxPatch((5.4, 0.4), 4.0, 3.7, boxstyle="round,pad=0.15", fc="white", ec=GREEN, lw=2)
    ax.add_patch(b2)
    ax.text(7.4, 3.7, "Heurística Seed-and-Extend\n(BWA, Bowtie2, BLAST)", ha="center", color=GREEN, fontweight="bold", fontsize=10)
    ax.text(7.4, 2.7, "1. Búsqueda exacta de semillas ($k$-meros)\n2. Filtrado de candidatos topológicos\n3. Extensión con alineamiento local", ha="center", va="center", color=GRAY, fontsize=9)
    ax.text(7.4, 1.0, "Tiempo humano: Minutos", ha="center", color=GREEN, fontweight="bold", fontsize=9.5)

    save(fig, "F01")

def f02():
    """BC08-F02: BWT y FM-index con LF-mapping."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.1, "Índice de Burrows-Wheeler (FM-index) y LF-Mapping", ha="center", color=BLUE, fontweight="bold", fontsize=11)

    steps = [
        ("1. Matriz BWT", "Rotaciones cíclicas de $T\\$$:\nOrdenadas lexicográficamente\nColumna $L$ agrupa caracteres", 1.8, 2.0, BLUE),
        ("2. Tablas $C$ y $\\text{Occ}$", "$C[c]$: Posición inicial de base\n$\\text{Occ}(c, k)$: Conteo acumulado\nde apariciones hasta $k$", 5.0, 2.0, ORANGE),
        ("3. Búsqueda Hacia Atrás", "Patrón leído de $3' \\to 5'$\nActualización en $O(1)$:\n$[k, l] \\to [C[c]+\\text{Occ}(k-1), \\dots]$", 8.2, 2.0, GREEN)
    ]
    for title, desc, cx, cy, col in steps:
        sbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(sbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8.5)

    ax.add_patch(FancyArrowPatch((3.3, 2.0), (3.5, 2.0), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))
    ax.add_patch(FancyArrowPatch((6.5, 2.0), (6.7, 2.0), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))

    save(fig, "F02")

def f03():
    """BC08-F03: Operaciones CIGAR en SAM."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.1, "Consumo de Coordenadas por Operadores CIGAR en Formato SAM", ha="center", color=BLUE, fontweight="bold", fontsize=11)

    ops = [
        ("M", "Alineamiento / Coincidencia\n(Match / Mismatch)", "Consume Query: Sí\nConsume Ref: Sí", GREEN, 1.2),
        ("I", "Inserción en la lectura\n(No en referencia)", "Consume Query: Sí\nConsume Ref: No", ORANGE, 3.1),
        ("D", "Deleción en la lectura\n(Salto en referencia)", "Consume Query: No\nConsume Ref: Sí", RED, 5.0),
        ("N", "Salto intrónico\n(Splicing en RNA-seq)", "Consume Query: No\nConsume Ref: Sí", BLUE, 6.9),
        ("S", "Recorte blando\n(Soft clipping)", "Consume Query: Sí\nConsume Ref: No", GRAY, 8.8)
    ]
    for op, desc, cons, col, cx in ops:
        obox = FancyBboxPatch((cx-0.85, 0.4), 1.7, 3.2, boxstyle="round,pad=0.1", fc="white", ec=col, lw=2)
        ax.add_patch(obox)
        ax.text(cx, 3.1, op, ha="center", color=col, fontweight="bold", fontsize=16)
        ax.text(cx, 2.1, desc, ha="center", color=GRAY, fontsize=7.5)
        ax.text(cx, 0.9, cons, ha="center", color=col, fontweight="bold", fontsize=7.5)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
