#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH08: Mapeo de lecturas y flujos NGS.

Implementa indexado genomico basado en k-mers (Hash-based mapping), estrategia Seed-and-Extend,
parsing de descriptores CIGAR y calculo de calidad de mapeo MAPQ.
"""

from __future__ import annotations

import argparse
import math
import re
import sys


def build_kmer_index(genome: str, k: int = 3, one_based: bool = True) -> dict[str, list[int]]:
    if k <= 0:
        raise ValueError("El tamano de k-mer debe ser estrictamente positivo")
    if len(genome) < k:
        raise ValueError(f"El genoma ({len(genome)} pb) es mas corto que k ({k})")

    index: dict[str, list[int]] = {}
    for i in range(len(genome) - k + 1):
        kmer = genome[i : i + k].upper()
        pos = i + 1 if one_based else i
        if kmer not in index:
            index[kmer] = []
        index[kmer].append(pos)
    return index


def seed_and_extend_map(
    query: str, genome: str, k: int = 3, max_mismatches: int = 1, one_based: bool = True
) -> list[dict[str, int | str]]:
    if len(query) < k:
        raise ValueError(f"La lectura query ({len(query)} pb) es mas corta que k ({k})")
    
    idx = build_kmer_index(genome, k=k, one_based=False)
    query = query.upper()
    genome = genome.upper()
    q_len = len(query)
    g_len = len(genome)

    # Buscar semillas usando el primer k-mer de la query
    seed = query[:k]
    seed_hits = idx.get(seed, [])
    
    results: list[dict[str, int | str]] = []
    for hit in seed_hits:
        start_g = hit
        end_g = start_g + q_len
        if end_g > g_len:
            continue
        
        target_sub = genome[start_g:end_g]
        mismatches = sum(1 for a, b in zip(query, target_sub) if a != b)
        if mismatches <= max_mismatches:
            pos_out = start_g + 1 if one_based else start_g
            cigar = f"{q_len}M" if mismatches == 0 else f"{q_len}M({mismatches}X)"
            results.append({
                "POS": pos_out,
                "MISMATCHES": mismatches,
                "CIGAR": cigar,
                "TARGET_SEQ": target_sub,
            })
    return results


def parse_cigar(cigar_str: str) -> dict[str, int]:
    pattern = re.compile(r"(\d+)([MIDNSHP=X])")
    matches = pattern.findall(cigar_str)
    if not matches:
        raise ValueError(f"Cadena CIGAR no valida: {cigar_str}")
    
    query_len = 0
    ref_len = 0
    
    for count_str, op in matches:
        count = int(count_str)
        if op in ("M", "=", "X"):
            query_len += count
            ref_len += count
        elif op in ("I", "S"):
            query_len += count
        elif op in ("D", "N"):
            ref_len += count
        elif op in ("H", "P"):
            pass

    return {
        "QUERY_LEN": query_len,
        "REF_LEN": ref_len,
    }


def mapq_to_error_prob(mapq: float) -> float:
    return 10.0 ** (-mapq / 10.0)


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH08 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # index
    p_idx = subparsers.add_parser("index_kmers")
    p_idx.add_argument("--genome", type=str, default="CATGGTCATTGGTTCC")
    p_idx.add_argument("--k", type=int, default=3)

    # map
    p_map = subparsers.add_parser("map_read")
    p_map.add_argument("--query", type=str, default="TGGTCA")
    p_map.add_argument("--genome", type=str, default="CATGGTCATTGGTTCC")
    p_map.add_argument("--k", type=int, default=3)
    p_map.add_argument("--max_mismatches", type=int, default=1)

    # cigar
    p_cigar = subparsers.add_parser("cigar")
    p_cigar.add_argument("cigar_str", type=str)

    # mapq
    p_mapq = subparsers.add_parser("mapq")
    p_mapq.add_argument("score", type=float)

    args = parser.parse_args()

    if args.subcommand == "index_kmers":
        try:
            res = build_kmer_index(args.genome, args.k, one_based=True)
            tgg_hits = ",".join(str(p) for p in res.get("TGG", []))
            cat_hits = ",".join(str(p) for p in res.get("CAT", []))
            print(f"GENOME_LEN:{len(args.genome)} K:{args.k} UNIQUE_KMERS:{len(res)} CAT_POS:{cat_hits} TGG_POS:{tgg_hits}")
        except ValueError as e:
            # la guarda de dominio informa por la salida estandar, sin abortar
            print(f"GENOME:{args.genome} K:{args.k} VALID:False ERROR:{e}")
    elif args.subcommand == "map_read":
        hits = seed_and_extend_map(args.query, args.genome, args.k, args.max_mismatches, one_based=True)
        if hits:
            best = hits[0]
            print(f"QUERY:{args.query} STATUS:MAPPED POS:{best['POS']} MISMATCHES:{best['MISMATCHES']} CIGAR:{best['CIGAR']} TARGET:{best['TARGET_SEQ']}")
        else:
            print(f"QUERY:{args.query} STATUS:UNMAPPED")
    elif args.subcommand == "cigar":
        lens = parse_cigar(args.cigar_str)
        print(f"CIGAR:{args.cigar_str} QUERY_LEN:{lens['QUERY_LEN']} REF_LEN:{lens['REF_LEN']}")
    elif args.subcommand == "mapq":
        p = mapq_to_error_prob(args.score)
        print(f"MAPQ:{args.score:.1f} ERR_PROB:{p:.6f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
