#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH12: Prediccion estructural clasica.

Implementa calculo de identidad de secuencia en zonas de homologia, evaluacion del
criterio de aceptacion de Metropolis en Monte Carlo (Rosetta), calculo analitico de TM-score,
y evaluacion de Clashscore de MolProbity.
"""

from __future__ import annotations

import argparse
import math
import sys


def calculate_sequence_identity(seq1: str, seq2: str) -> float:
    if len(seq1) != len(seq2) or len(seq1) == 0:
        raise ValueError("Las secuencias alineadas deben tener la misma longitud no nula")
    matches = sum(1 for a, b in zip(seq1, seq2) if a == b and a != "-")
    valid_len = sum(1 for a, b in zip(seq1, seq2) if a != "-" or b != "-")
    if valid_len == 0:
        raise ValueError("No hay posiciones validas alineadas")
    return (matches / valid_len) * 100.0


def metropolis_acceptance_probability(delta_e: float, temperature: float = 300.0) -> float:
    if temperature <= 0:
        raise ValueError("El parametro de muestreo debe ser estrictamente positivo")
    if delta_e <= 0:
        return 1.0
    return math.exp(-delta_e / temperature)


def calculate_d0(l_target: int) -> float:
    if l_target <= 15:
        return 0.5
    return 1.24 * ((l_target - 15) ** (1.0 / 3.0)) - 1.8


def calculate_tm_score(distances: list[float], l_target: int) -> float:
    if l_target <= 0 or len(distances) == 0:
        raise ValueError("Longitud y distancias deben ser positivas")
    d0 = calculate_d0(l_target)
    score_sum = sum(1.0 / (1.0 + (d / d0) ** 2) for d in distances)
    return score_sum / l_target


def calculate_clashscore(num_clashes: int, num_atoms: int) -> float:
    if num_atoms <= 0:
        raise ValueError("El numero de atomos debe ser estrictamente positivo")
    if num_clashes < 0:
        raise ValueError("El numero de choques no puede ser negativo")
    return (num_clashes / num_atoms) * 1000.0


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH12 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # identity
    p_id = subparsers.add_parser("identity")
    p_id.add_argument("--seq1", type=str, default="ACDEFGHIKLMNPQRSTVWY")
    p_id.add_argument("--seq2", type=str, default="ACDEFGHIKLMNPQRSTVWA")

    # metropolis
    p_met = subparsers.add_parser("metropolis")
    p_met.add_argument("--delta_e", type=float, default=300.0)
    p_met.add_argument("--temp", type=float, default=300.0)

    # tm_score
    p_tm = subparsers.add_parser("tm_score")
    p_tm.add_argument("--dists", type=str, default="0.0,0.0,0.0,0.0")
    p_tm.add_argument("--l_target", type=int, default=4)

    # clashscore
    p_clash = subparsers.add_parser("clashscore")
    p_clash.add_argument("--clashes", type=int, default=2)
    p_clash.add_argument("--atoms", type=int, default=1000)

    args = parser.parse_args()

    if args.subcommand == "identity":
        ident = calculate_sequence_identity(args.seq1, args.seq2)
        print(f"SEQ1_LEN:{len(args.seq1)} SEQ2_LEN:{len(args.seq2)} IDENTITY_PCT:{ident:.2f}")
    elif args.subcommand == "metropolis":
        try:
            prob = metropolis_acceptance_probability(args.delta_e, args.temp)
            print(f"DELTA_E:{args.delta_e:.2f} TEMP:{args.temp:.2f} ACCEPT_PROB:{prob:.6f}")
        except ValueError as e:
            # la guarda del parametro de muestreo informa por la salida estandar
            print(f"DELTA_E:{args.delta_e:.2f} TEMP:{args.temp:.2f} VALID:False ERROR:{e}")
    elif args.subcommand == "tm_score":
        d_list = [float(x) for x in args.dists.split(",")]
        tm = calculate_tm_score(d_list, args.l_target)
        d0 = calculate_d0(args.l_target)
        print(f"L_TARGET:{args.l_target} D0:{d0:.6f} TM_SCORE:{tm:.6f}")
    elif args.subcommand == "clashscore":
        cs = calculate_clashscore(args.clashes, args.atoms)
        print(f"CLASHES:{args.clashes} ATOMS:{args.atoms} CLASHSCORE:{cs:.6f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
