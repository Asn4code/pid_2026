#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH12."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Curva de umbrales de identidad de secuencia de Rost que define la zona segura, penumbra y medianoche para modelado por homología.",
    "F02": "Diagrama de flujo del pipeline de cuatro etapas del modelado comparativo de estructuras con MODELLER.",
    "F03": "Muestreo conformacional de Monte Carlo Metropolis con ensamblaje de fragmentos ab initio en Rosetta."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC12-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC12-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC12-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH12 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC12-F01: Curva de Rost y zonas de identidad."""
    fig, ax = plt.subplots(figsize=(7.5, 3.8), dpi=300)
    L = np.linspace(20, 400, 200)
    # Rost curve formula: p(L) = 24.8 + 520 * L^(-0.5) approx
    p_rost = 24.8 + 520.0 * (L ** -0.5)

    ax.fill_between(L, p_rost, 100, color="#EAF2EC", alpha=0.9, label="Zona Segura (Safe Zone: Homología Fiable)")
    ax.fill_between(L, 20, p_rost, color="#FFF9E6", alpha=0.9, label="Zona de Penumbra (Twilight Zone: $20\\text{--}30\\%$)")
    ax.fill_between(L, 0, 20, color="#FBEAEB", alpha=0.9, label="Zona de Medianoche (Midnight Zone: $<20\\%$)")

    ax.plot(L, p_rost, color=GREEN, lw=2.2, label="Curva Empírica de Rost")

    ax.set_xlabel("Longitud de Alineamiento de Residuos ($L$)", fontsize=9.5)
    ax.set_ylabel("Porcentaje de Identidad de Secuencia (\\%)", fontsize=9.5)
    ax.set_title("Zonas de Fiabilidad en Modelado por Homología (Curva de Rost)", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_xlim(20, 400)
    ax.set_ylim(0, 100)
    ax.legend(frameon=True, facecolor="white", edgecolor="none", fontsize=8, loc="upper right")
    ax.grid(True, linestyle=":", alpha=0.5)

    save(fig, "F01")

def f02():
    """BC12-F02: Pipeline de modelado comparativo."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    stages = [
        ("1. Búsqueda Plantilla", "BLAST / HHpred\nIdentificación de PDBs\ncon homología evolutiva", 1.4, 2.2, BLUE),
        ("2. Alineamiento", "Alineamiento Diana-Plantilla\nCorrección de gaps\nConservación de motivos", 3.8, 2.2, ORANGE),
        ("3. Restricciones 3D", "MODELLER (Šali)\nFunciones de probabilidad\nde distancias y diedros", 6.2, 2.2, GREEN),
        ("4. Refinamiento", "Modelado de bucles\nRotámeros de cadenas\nValidación (MolProbity)", 8.6, 2.2, RED)
    ]
    for title, desc, cx, cy, col in stages:
        sbox = FancyBboxPatch((cx-1.1, cy-1.4), 2.2, 2.8, boxstyle="round,pad=0.1", fc="white", ec=col, lw=2)
        ax.add_patch(sbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=8.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8)

    ax.add_patch(FancyArrowPatch((2.55, 2.2), (2.65, 2.2), arrowstyle="->", color=GRAY, lw=2, mutation_scale=12))
    ax.add_patch(FancyArrowPatch((4.95, 2.2), (5.05, 2.2), arrowstyle="->", color=GRAY, lw=2, mutation_scale=12))
    ax.add_patch(FancyArrowPatch((7.35, 2.2), (7.45, 2.2), arrowstyle="->", color=GRAY, lw=2, mutation_scale=12))

    save(fig, "F02")

def f03():
    """BC12-F03: Muestreo Monte Carlo Metropolis en Rosetta."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.1, "Muestreo Monte Carlo Metropolis para Ensamblaje Ab Initio (Rosetta)", ha="center", color=BLUE, fontweight="bold", fontsize=10.5)

    steps = [
        ("1. Inserción Fragmento", "Sustitución estocástica de\nángulos $(\\phi, \\psi)$ de 3 ó 9\nresiduos de la librería PDB", 1.8, 2.0, BLUE),
        ("2. Evaluación Energética", "Cálculo de energía $\\Delta E = E_{\\text{nuevo}} - E_{\\text{actual}}$\nFunción de puntuación física\n(REF2015: Lennard-Jones, H-bonds)", 5.0, 2.0, ORANGE),
        ("3. Criterio Metropolis", "Si $\\Delta E \\leq 0 \\to$ Acepta siempre\nSi $\\Delta E > 0 \\to$ Acepta con $P = e^{-\\Delta E / k_B T}$\n(Escape de mínimos locales)", 8.2, 2.0, GREEN)
    ]
    for title, desc, cx, cy, col in steps:
        sbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(sbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
