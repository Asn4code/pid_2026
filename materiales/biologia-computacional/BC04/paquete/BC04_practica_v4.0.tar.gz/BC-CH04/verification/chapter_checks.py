#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH04: Expresion genica, transcriptomica y redes de regulacion.

Implementa transcripcion ADN->ARN, traduccion en 6 marcos de lectura, busqueda de ORFs,
sesgo de codones / GC3, y normalizacion de expresion TPM (Transcripts Per Million).
"""

from __future__ import annotations

import argparse
import sys


RNA_CODON_TABLE: dict[str, str] = {
    "UUU": "F", "UUC": "F", "UUA": "L", "UUG": "L",
    "UCU": "S", "UCC": "S", "UCA": "S", "UCG": "S",
    "UAU": "Y", "UAC": "Y", "UAA": "*", "UAG": "*",
    "UGU": "C", "UGC": "C", "UGA": "*", "UGG": "W",
    "CUU": "L", "CUC": "L", "CUA": "L", "CUG": "L",
    "CCU": "P", "CCC": "P", "CCA": "P", "CCG": "P",
    "CAU": "H", "CAC": "H", "CAA": "Q", "CAG": "Q",
    "CGU": "R", "CGC": "R", "CGA": "R", "CGG": "R",
    "AUU": "I", "AUC": "I", "AUA": "I", "AUG": "M",
    "ACU": "T", "ACC": "T", "ACA": "T", "ACG": "T",
    "AAU": "N", "AAC": "N", "AAA": "K", "AAG": "K",
    "AGU": "S", "AGC": "S", "AGA": "R", "AGG": "R",
    "GUU": "V", "GUC": "V", "GUA": "V", "GUG": "V",
    "GCU": "A", "GCC": "A", "GCA": "A", "GCG": "A",
    "GAU": "D", "GAC": "D", "GAA": "E", "GAG": "E",
    "GGU": "G", "GGC": "G", "GGA": "G", "GGG": "G",
}

DNA_COMPLEMENT = str.maketrans("ACGTacgt", "TGCAtgca")


def transcribe(dna: str) -> str:
    upper = dna.upper()
    invalid = set(upper) - set("ACGT")
    if invalid:
        raise ValueError(f"Caracteres invalidos en ADN para transcripcion: {sorted(invalid)}")
    return upper.replace("T", "U")


def reverse_complement(dna: str) -> str:
    return dna.translate(DNA_COMPLEMENT)[::-1]


def translate_rna(rna: str, frame: int = 0) -> str:
    upper = rna.upper().replace("T", "U")
    invalid = set(upper) - set("ACGU")
    if invalid:
        raise ValueError(f"Caracteres invalidos en ARN para traduccion: {sorted(invalid)}")
    if frame not in (0, 1, 2):
        raise ValueError(f"Marco invalido: {frame}. Debe ser 0, 1 o 2")
    
    pep = []
    for i in range(frame, len(upper) - 2, 3):
        codon = upper[i:i+3]
        aa = RNA_CODON_TABLE.get(codon, "?")
        pep.append(aa)
        if aa == "*":
            break
    return "".join(pep)


def find_orfs_in_strand(dna_seq: str, strand: str = "+") -> list[dict[str, str | int]]:
    seq = dna_seq.upper()
    rna = seq.replace("T", "U")
    n = len(seq)
    orfs = []
    
    for frame in range(3):
        frame_label = f"{strand}{frame + 1}"
        i = frame
        while i < n - 2:
            codon = rna[i:i+3]
            if codon == "AUG":
                start_pos = i
                pep = ["M"]
                j = i + 3
                found_stop = False
                while j < n - 2:
                    c = rna[j:j+3]
                    aa = RNA_CODON_TABLE.get(c, "?")
                    if aa == "*":
                        found_stop = True
                        end_pos = j + 3
                        orf_dna = seq[start_pos:end_pos]
                        orfs.append({
                            "STRAND": strand,
                            "FRAME": frame_label,
                            "START": start_pos + 1,
                            "END": end_pos,
                            "LENGTH_NT": len(orf_dna),
                            "LENGTH_AA": len(pep),
                            "PROTEIN": "".join(pep),
                        })
                        i = j
                        break
                    else:
                        pep.append(aa)
                    j += 3
                if not found_stop:
                    break
            i += 3
    return orfs


def find_six_frame_orfs(dna_seq: str) -> list[dict[str, str | int]]:
    fwd = find_orfs_in_strand(dna_seq, "+")
    rev = find_orfs_in_strand(reverse_complement(dna_seq), "-")
    return fwd + rev


def gc3_content(coding_dna: str) -> float:
    seq = coding_dna.upper()
    if len(seq) % 3 != 0:
        raise ValueError(f"Secuencia codificante debe ser multiplo de 3, longitud={len(seq)}")
    third_bases = [seq[i] for i in range(2, len(seq), 3)]
    if not third_bases:
        return 0.0
    gc_count = sum(1 for b in third_bases if b in ("G", "C"))
    return (gc_count / len(third_bases)) * 100.0


def calculate_tpm(counts: list[float], lengths: list[float]) -> list[float]:
    if len(counts) != len(lengths):
        raise ValueError("Counts y Lengths deben tener la misma longitud")
    
    # 1. RPK = Count / (Length / 1000)
    rpk = [c / (l / 1000.0) for c, l in zip(counts, lengths)]
    total_rpk = sum(rpk)
    if total_rpk == 0:
        return [0.0] * len(counts)
    
    # 2. Scaling factor = total_rpk / 1e6
    scaling_factor = total_rpk / 1e6
    
    # 3. TPM = RPK / scaling_factor
    return [r / scaling_factor for r in rpk]


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH04 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # transcribe
    p_tr = subparsers.add_parser("transcribe")
    p_tr.add_argument("dna", type=str)

    # translate
    p_tl = subparsers.add_parser("translate")
    p_tl.add_argument("rna", type=str)
    p_tl.add_argument("--frame", type=int, default=0)

    # orf
    p_orf = subparsers.add_parser("orfs")
    p_orf.add_argument("dna", type=str)

    # gc3
    p_gc3 = subparsers.add_parser("gc3")
    p_gc3.add_argument("dna", type=str)

    # tpm
    p_tpm = subparsers.add_parser("tpm")
    p_tpm.add_argument("--counts", nargs="+", type=float, required=True)
    p_tpm.add_argument("--lengths", nargs="+", type=float, required=True)

    args = parser.parse_args()

    if args.subcommand == "transcribe":
        try:
            res = transcribe(args.dna)
        except ValueError as e:
            # la guarda de dominio informa por la salida estandar, sin abortar
            print(f"DNA:{args.dna.upper()} VALID:False ERROR:{e}")
        else:
            print(f"DNA:{args.dna.upper()} RNA:{res}")
    elif args.subcommand == "translate":
        res = translate_rna(args.rna, args.frame)
        print(f"RNA:{args.rna.upper()} FRAME:{args.frame} PROTEIN:{res}")
    elif args.subcommand == "orfs":
        res = find_six_frame_orfs(args.dna)
        print(f"DNA:{args.dna.upper()} ORF_COUNT:{len(res)}")
        for idx, o in enumerate(res, 1):
            print(f"ORF_{idx}: FRAME:{o['FRAME']} START:{o['START']} END:{o['END']} LENGTH_AA:{o['LENGTH_AA']} PROTEIN:{o['PROTEIN']}")
    elif args.subcommand == "gc3":
        res = gc3_content(args.dna)
        print(f"DNA:{args.dna.upper()} GC3_PERCENT:{res:.2f}")
    elif args.subcommand == "tpm":
        res = calculate_tpm(args.counts, args.lengths)
        res_str = ";".join(f"{v:.6f}" for v in res)
        print(f"TPM_VALUES:{res_str}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
