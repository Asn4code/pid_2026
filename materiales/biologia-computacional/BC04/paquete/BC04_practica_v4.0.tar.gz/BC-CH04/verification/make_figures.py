#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH04."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Ciclo de la ARN Polimerasa II que muestra el ensamblaje del complejo de preiniciación en el promotor y la fosforilación del dominio CTD para elongación.",
    "F02": "Bioquímica del splicing en dos transesterificaciones sucesivas con ataque nucleofílico del 2 primo OH de la adenina del punto de ramificación.",
    "F03": "Normalización de expresión génica que compara conteos crudos con RPKM y la propiedad invariante de suma de un millón en TPM entre muestras."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC04-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC04-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC04-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH04 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC04-F01: Ciclo de ARN Pol II y PIC."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # 3 Steps
    steps = [
        ("1. Complejo de Preiniciación (PIC)", "TBP + TFIID + TFIIH\nReclutan ARN Pol II\nen el promotor (TATA)", 1.8, 2.2, BLUE),
        ("2. Escape y Fosforilación CTD", "TFIIH quinasa fosforila\nSer5 en cola CTD\nEscape del promotor", 5.0, 2.2, ORANGE),
        ("3. Elongación Procesiva y Maduración", "P-TEFb fosforila Ser2\nReclutamiento de factores de\nCapping, Splicing y Poli(A)", 8.2, 2.2, GREEN)
    ]
    for title, desc, cx, cy, col in steps:
        sbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(sbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8.5)

    # Connecting arrows
    ax.add_patch(FancyArrowPatch((3.3, 2.2), (3.5, 2.2), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))
    ax.add_patch(FancyArrowPatch((6.5, 2.2), (6.7, 2.2), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))

    save(fig, "F01")

def f02():
    """BC04-F02: Mecanismo de transesterificación del splicing."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Step 1: Branch point attack
    ax.text(5.0, 4.1, "Bioquímica del Splicing: Dos Transesterificaciones Isocalóricas", ha="center", color=BLUE, fontweight="bold", fontsize=10.5)

    # Exon 1, Intron, Exon 2
    e1 = FancyBboxPatch((0.5, 2.2), 1.8, 1.2, boxstyle="round,pad=0.1", fc="#D5E8D4", ec=GREEN, lw=2)
    ax.add_patch(e1)
    ax.text(1.4, 2.8, "Exón 1 (5')", ha="center", color=GREEN, fontweight="bold", fontsize=9)
    ax.text(1.4, 2.4, "$3'\\text{-OH libre}$", ha="center", color=GRAY, fontsize=8)

    # Intron loop with branch A
    ax.plot([2.4, 4.5, 5.5, 7.5], [2.8, 3.6, 3.6, 2.8], color=ORANGE, lw=2.5)
    ax.text(5.0, 3.8, "Intrón (Lazo / Lariat)", ha="center", color=ORANGE, fontweight="bold", fontsize=9)
    # Branch point A
    a_circ = Circle((5.0, 3.2), 0.35, fc="white", ec=RED, lw=2)
    ax.add_patch(a_circ)
    ax.text(5.0, 3.2, "A", color=RED, fontweight="bold", ha="center", va="center", fontsize=9)
    ax.text(5.0, 2.65, "$2'\\text{-OH}$ nucleofílico\n(Punto ramificación)", ha="center", color=RED, fontsize=7.5)

    # Exon 2
    e2 = FancyBboxPatch((7.6, 2.2), 1.8, 1.2, boxstyle="round,pad=0.1", fc="#D5E8D4", ec=GREEN, lw=2)
    ax.add_patch(e2)
    ax.text(8.5, 2.8, "Exón 2 (3')", ha="center", color=GREEN, fontweight="bold", fontsize=9)

    # Attack arrow from 2'-OH to 5' splice site (GU)
    ax.add_patch(FancyArrowPatch((4.7, 3.2), (2.4, 2.9), connectionstyle="arc3,rad=-0.3",
                                  arrowstyle="->", color=RED, lw=2, ls="--"))
    ax.text(3.5, 2.2, "1ª Transesterificación: Ataque a sitio $5'\\text{ (GU)}$", ha="center", color=RED, fontsize=8)

    # Final result below
    ax.text(5.0, 0.9, "2ª Transesterificación: El $3'\\text{-OH}$ del Exón 1 ataca el sitio $3'\\text{ (AG)} \\to$ Unión Exón 1--Exón 2",
            ha="center", color=GREEN, fontweight="bold", fontsize=8.5)

    save(fig, "F02")

def f03():
    """BC04-F03: Normalización de expresión génica TPM vs RPKM."""
    fig, ax = plt.subplots(figsize=(7.5, 3.8), dpi=300)
    genes = ["Gen A (2 kb)", "Gen B (4 kb)", "Gen C (1 kb)"]
    raw_counts = [20, 80, 50]
    tpm_sample1 = [100000, 200000, 700000] # sum = 1,000,000

    x = np.arange(len(genes))
    width = 0.35

    ax.bar(x - width/2, raw_counts, width, label="Lecturas Crudas (Reads)", color=GRAY, alpha=0.8)
    ax.bar(x + width/2, [t/10000 for t in tpm_sample1], width, label="TPM ($/10^4$ escalado)", color=BLUE)

    ax.set_xticks(x)
    ax.set_xticklabels(genes, fontsize=9.5)
    ax.set_ylabel("Valor de Abundancia / Conteo", fontsize=9.5)
    ax.set_title("Normalización de Expresión: Corrección por Longitud y Profundidad (TPM)", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.legend(frameon=True, facecolor="white", edgecolor="none", fontsize=8.5)
    ax.grid(True, linestyle=":", alpha=0.6, axis="y")

    # Invariance text
    ax.text(1.0, 75, "Propiedad Invariante de TPM:\n$\\sum_i \\text{TPM}_i = 10^6$ constante entre muestras",
            ha="center", color=GREEN, fontweight="bold", fontsize=8.5,
            bbox=dict(boxstyle="round,pad=0.3", fc="#EAF2EC", ec=GREEN, lw=1.2))

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
