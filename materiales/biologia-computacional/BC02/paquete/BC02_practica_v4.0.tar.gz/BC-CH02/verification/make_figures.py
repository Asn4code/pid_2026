#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH02."""

from __future__ import annotations

import argparse
import datetime as dt
import math
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Geometría del plano peptídico que muestra el enlace carbono-nitrógeno rígido con carácter parcial de doble enlace y los ángulos de rotación phi y psi.",
    "F02": "Curvas de saturación alostérica que contrastan el modelo hiperbólico no cooperativo con la sigmoide de Hill cooperativa positiva y estados T y R.",
    "F03": "Patrones de puentes de hidrógeno en hélice alfa entre el carbonilo de la posición i y el amino de i más 4 frente a láminas beta antiparalelas."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC02-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC02-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC02-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH02 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC02-F01: Plano peptídico y diedros phi/psi."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Shaded peptide plane
    plane = FancyBboxPatch((2.2, 1.0), 5.6, 2.5, boxstyle="round,pad=0.1", fc="#E3EBF3", ec=BLUE, lw=2, ls="--")
    ax.add_patch(plane)
    ax.text(5.0, 3.2, "Plano Peptídico Rígido (Carácter 40% doble enlace, $\\omega \\approx 180^\\circ$ trans)", ha="center", va="center", color=BLUE, fontweight="bold", fontsize=9.5)

    # Atoms
    atoms = [
        ("$C_\\alpha^{(i)}$", 1.5, 2.2, ORANGE),
        ("C", 3.2, 2.2, GRAY),
        ("O", 3.2, 1.2, RED),
        ("N", 6.8, 2.2, BLUE),
        ("H", 6.8, 1.2, GRAY),
        ("$C_\\alpha^{(i+1)}$", 8.5, 2.2, ORANGE)
    ]
    for text, cx, cy, col in atoms:
        c = Circle((cx, cy), 0.35, fc="white", ec=col, lw=2)
        ax.add_patch(c)
        ax.text(cx, cy, text, ha="center", va="center", color=col, fontweight="bold", fontsize=10)

    # Bonds
    ax.plot([1.85, 2.85], [2.2, 2.2], color=GRAY, lw=2) # Calpha - C (psi)
    ax.plot([3.2, 3.2], [1.85, 1.55], color=RED, lw=3)   # C=O
    ax.plot([3.55, 6.45], [2.2, 2.2], color=BLUE, lw=3.5) # C-N peptide bond
    ax.plot([6.8, 6.8], [1.85, 1.55], color=GRAY, lw=2)  # N-H
    ax.plot([7.15, 8.15], [2.2, 2.2], color=GRAY, lw=2) # N - Calpha (phi)

    # Rotation indicators
    ax.text(2.35, 2.6, "$\\psi$ (rotación)", ha="center", color=ORANGE, fontsize=8.5, fontweight="bold")
    ax.text(7.65, 2.6, "$\\phi$ (rotación)", ha="center", color=BLUE, fontsize=8.5, fontweight="bold")
    ax.text(5.0, 2.45, "Enlace Peptídico ($1.32\\text{ \\AA}$)", ha="center", color=BLUE, fontsize=8.5)

    save(fig, "F01")

def f02():
    """BC02-F02: Curvas de unión alostérica y cooperatividad de Hill."""
    fig, ax = plt.subplots(figsize=(6.8, 3.8), dpi=300)
    L = np.linspace(0, 10, 200)
    Kd = 2.0

    # Non-cooperative (n=1)
    Y_n1 = L / (Kd + L)
    # Cooperative Hill (n=2.8, hemoglobin)
    Y_hill = (L**2.8) / (Kd**2.8 + L**2.8)
    # Negative cooperativity (n=0.6)
    Y_neg = (L**0.6) / (Kd**0.6 + L**0.6)

    ax.plot(L, Y_n1, label="No cooperativo ($n_H = 1.0$, Mioglobina)", color=BLUE, lw=2.2, ls="--")
    ax.plot(L, Y_hill, label="Cooperativo positivo ($n_H = 2.8$, Hemoglobina)", color=ORANGE, lw=2.5)
    ax.plot(L, Y_neg, label="Cooperativo negativo ($n_H = 0.6$)", color=GRAY, lw=1.5, ls=":")

    ax.axhline(0.5, color="#CCCCCC", ls="--", lw=1)
    ax.axvline(Kd, color="#CCCCCC", ls="--", lw=1)
    ax.text(Kd+0.15, 0.05, "$K_{0.5} = 2.0$", color=GRAY, fontsize=8.5)

    ax.set_xlabel("Concentración de ligando $[L]$ (unidades arbitrarias)", fontsize=9.5)
    ax.set_ylabel("Fracción de saturación $\\theta$", fontsize=9.5)
    ax.set_title("Transición Alostérica y Fracción de Saturación de Hill", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_ylim(0, 1.05)
    ax.set_xlim(0, 10)
    ax.legend(frameon=True, facecolor=LIGHT, edgecolor="none", fontsize=8.5)
    ax.grid(True, linestyle=":", alpha=0.6)

    save(fig, "F02")

def f03():
    """BC02-F03: Puentes de hidrógeno en hélice alfa y lámina beta."""
    fig, ax = plt.subplots(figsize=(8.5, 3.4), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4)
    ax.axis("off")

    # Alpha helix block
    abox = FancyBboxPatch((0.5, 0.3), 4.2, 3.4, boxstyle="round,pad=0.15", fc="white", ec=BLUE, lw=1.8)
    ax.add_patch(abox)
    ax.text(2.6, 3.35, "Hélice $\\alpha$ (Puentes $i \\to i+4$)", ha="center", color=BLUE, fontweight="bold", fontsize=10)
    ax.text(2.6, 2.7, "$3.6$ residuos por vuelta\nPaso de rosca: $5.4\\text{ \\AA}$\n$(\\phi \\approx -57^\\circ, \\psi \\approx -47^\\circ)$",
            ha="center", va="center", color=GRAY, fontsize=8.5)
    # Mini diagram of hydrogen bonding
    ax.text(1.2, 1.4, "$C=O_{(i)}$", ha="center", color=RED, fontweight="bold", fontsize=9)
    ax.text(4.0, 1.4, "$N-H_{(i+4)}$", ha="center", color=BLUE, fontweight="bold", fontsize=9)
    a_hb = FancyArrowPatch((1.8, 1.4), (3.2, 1.4), arrowstyle="<->", color=GREEN, lw=2, ls="--")
    ax.add_patch(a_hb)
    ax.text(2.6, 1.65, "Puente H ($2.8\\text{--}3.0\\text{ \\AA}$)", ha="center", color=GREEN, fontsize=8)

    # Beta sheet block
    bbox = FancyBboxPatch((5.3, 0.3), 4.2, 3.4, boxstyle="round,pad=0.15", fc="white", ec=ORANGE, lw=1.8)
    ax.add_patch(bbox)
    ax.text(7.4, 3.35, "Lámina $\\beta$ Antiparalela", ha="center", color=ORANGE, fontweight="bold", fontsize=10)
    ax.text(7.4, 2.7, "Cadenas extendidas ($3.5\\text{ \\AA}$/aa)\nPuentes H intercatenarios lineales\n$(\\phi \\approx -139^\\circ, \\psi \\approx +135^\\circ)$",
            ha="center", va="center", color=GRAY, fontsize=8.5)
    ax.text(6.0, 1.4, "Hebra 1 ($N \\to C$)", ha="center", color=BLUE, fontsize=8.5, fontweight="bold")
    ax.text(8.8, 1.4, "Hebra 2 ($C \\to N$)", ha="center", color=ORANGE, fontsize=8.5, fontweight="bold")
    b_hb = FancyArrowPatch((6.8, 1.4), (8.0, 1.4), arrowstyle="<->", color=GREEN, lw=2, ls="--")
    ax.add_patch(b_hb)
    ax.text(7.4, 1.65, "Puente H lineal", ha="center", color=GREEN, fontsize=8)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
