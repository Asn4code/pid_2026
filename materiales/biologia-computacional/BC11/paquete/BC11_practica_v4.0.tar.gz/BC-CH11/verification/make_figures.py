#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH11."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Comparativa de las tres técnicas experimentales principales de determinación de estructuras 3D: Rayos X, RMN y Cryo-EM.",
    "F02": "Diagrama de Ramachandran que muestra las regiones conformacionales favorecidas para hélices alfa y láminas beta en el plano de ángulos diedros.",
    "F03": "Relación entre el factor térmico B de Debye-Waller y la fluctuación cuadrática media atómica RMSF."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC11-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC11-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC11-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH11 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC11-F01: Métodos de resolución estructural 3D."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    methods = [
        ("Cristalografía Rayos X", "• Requiere monocristal 3D\n• Alta resolución (<2.0 Å)\n• Mapa 2Fo-Fc y fases\n• Estado estático cristalino", 1.8, 2.2, BLUE),
        ("RMN en Disolución", "• Proteína en solución acuosa\n• Dinámica y ensamblajes\n• Restricciones NOE espaciales\n• Límite de tamaño (<40 kDa)", 5.0, 2.2, ORANGE),
        ("Crio-Microscopía Cryo-EM", "• Vitrificación rápida (-180°C)\n• Partícula única (Single Particle)\n• Grandes complejos (>100 kDa)\n• Sin necesidad de cristales", 8.2, 2.2, GREEN)
    ]
    for title, desc, cx, cy, col in methods:
        mbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(mbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8.5)

    save(fig, "F01")

def f02():
    """BC11-F02: Diagrama de Ramachandran."""
    fig, ax = plt.subplots(figsize=(5.5, 4.5), dpi=300)
    ax.set_xlim(-180, 180)
    ax.set_ylim(-180, 180)

    # Favored regions
    # Beta sheet region (top left)
    rect_beta = Rectangle((-160, 90), 100, 70, fc="#D5E8D4", ec=GREEN, lw=1.5, alpha=0.7)
    ax.add_patch(rect_beta)
    ax.text(-110, 125, "Lámina $\\beta$\n(Antiparalela / Paralela)", ha="center", va="center", color=GREEN, fontweight="bold", fontsize=8)

    # Alpha helix region (bottom left)
    rect_alpha = Rectangle((-120, -70), 70, 50, fc="#DAE8FC", ec=BLUE, lw=1.5, alpha=0.7)
    ax.add_patch(rect_alpha)
    ax.text(-85, -45, "Hélice $\\alpha$\n(Diestra)", ha="center", va="center", color=BLUE, fontweight="bold", fontsize=8)

    # Left-handed alpha helix (top right)
    rect_alpha_l = Rectangle((40, 30), 40, 40, fc="#FFF2CC", ec=ORANGE, lw=1.2, alpha=0.7)
    ax.add_patch(rect_alpha_l)
    ax.text(60, 50, "$\\alpha_L$\n(Gly)", ha="center", va="center", color=ORANGE, fontsize=7.5)

    ax.axhline(0, color=GRAY, ls=":", lw=1)
    ax.axvline(0, color=GRAY, ls=":", lw=1)

    ax.set_xlabel("Ángulo Diedro $\\phi$ ($^\\circ$)", fontsize=9.5)
    ax.set_ylabel("Ángulo Diedro $\\psi$ ($^\\circ$)", fontsize=9.5)
    ax.set_title("Diagrama de Ramachandran: Conformaciones Favorecidas", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.grid(True, linestyle=":", alpha=0.4)

    save(fig, "F02")

def f03():
    """BC11-F03: Factor B de Debye-Waller y RMSF."""
    fig, ax = plt.subplots(figsize=(6.8, 3.8), dpi=300)
    B_factors = np.linspace(5, 80, 200)
    # B = (8 * pi^2 / 3) * <u^2> => RMSF = sqrt(<u^2>) = sqrt(3*B / (8*pi^2))
    rmsf = np.sqrt(3 * B_factors / (8 * np.pi**2))

    ax.plot(B_factors, rmsf, color=BLUE, lw=2.5, label="$\\text{RMSF} = \\sqrt{3B / 8\\pi^2}$")
    ax.axvspan(5, 20, color="#EAF2EC", alpha=0.8, label="Núcleo Proteico Rígido ($B < 20\\text{ \\AA}^2$)")
    ax.axvspan(45, 80, color="#FBEAEB", alpha=0.8, label="Bucles Flexibles / Desorden ($B > 45\\text{ \\AA}^2$)")

    ax.set_xlabel("Factor Térmico de Debye-Waller $B$ ($\\text{\\AA}^2$)", fontsize=9.5)
    ax.set_ylabel("Fluctuación Atómica RMSF ($\\text{\\AA}$)", fontsize=9.5)
    ax.set_title("Relación entre Factor B y Fluctuación Atómica Cuadrática Media", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_xlim(5, 80)
    ax.set_ylim(0.4, 1.8)
    ax.legend(frameon=True, facecolor="white", edgecolor="none", fontsize=8)
    ax.grid(True, linestyle=":", alpha=0.6)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
