#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH13: Prediccion estructural con IA y evaluacion de confianza.

Implementa clasificacion de bandas pLDDT de AlphaFold, analisis de matrices PAE
interdominio, evaluacion de pLDDT medio, y verificacion de la desigualdad triangular (Triangle Update).
"""

from __future__ import annotations

import argparse
import math
import sys


def classify_plddt(score: float) -> str:
    if score < 0.0 or score > 100.0:
        raise ValueError("El score pLDDT debe estar en el intervalo [0, 100]")
    if score >= 90.0:
        return "VERY_HIGH"
    elif score >= 70.0:
        return "CONFIDENT"
    elif score >= 50.0:
        return "LOW"
    else:
        return "VERY_LOW_OR_IDP"


def calculate_mean_plddt(scores: list[float]) -> float:
    if len(scores) == 0:
        raise ValueError("La lista de scores no puede estar vacia")
    for s in scores:
        if s < 0.0 or s > 100.0:
            raise ValueError("Cada score pLDDT debe estar en [0, 100]")
    return sum(scores) / len(scores)


def evaluate_interdomain_pae(pae_matrix: list[list[float]]) -> tuple[float, str]:
    if len(pae_matrix) == 0 or any(len(row) != len(pae_matrix[0]) for row in pae_matrix):
        raise ValueError("La matriz PAE debe ser rectangular y no vacia")
    total_elements = len(pae_matrix) * len(pae_matrix[0])
    mean_pae = sum(val for row in pae_matrix for val in row) / total_elements
    if mean_pae < 5.0:
        status = "RIGID_ORIENTATION"
    elif mean_pae <= 15.0:
        status = "INTERMEDIATE_ORIENTATION"
    else:
        status = "FLEXIBLE_LINKER"
    return mean_pae, status


def check_triangle_inequality(d_ij: float, d_jk: float, d_ik: float) -> bool:
    if d_ij < 0 or d_jk < 0 or d_ik < 0:
        raise ValueError("Las distancias no pueden ser negativas")
    return (d_ik <= d_ij + d_jk) and (d_ij <= d_jk + d_ik) and (d_jk <= d_ij + d_ik)


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH13 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # plddt
    p_plddt = subparsers.add_parser("plddt")
    p_plddt.add_argument("--score", type=float, default=92.5)

    # mean_plddt
    p_mean = subparsers.add_parser("mean_plddt")
    p_mean.add_argument("--scores", type=str, default="95.0,92.0,88.0,45.0")

    # pae
    p_pae = subparsers.add_parser("pae")
    p_pae.add_argument("--matrix", type=str, default="2.5,3.0;3.0,2.8")

    # triangle
    p_tri = subparsers.add_parser("triangle")
    p_tri.add_argument("--d12", type=float, default=3.0)
    p_tri.add_argument("--d23", type=float, default=4.0)
    p_tri.add_argument("--d13", type=float, default=5.0)

    args = parser.parse_args()

    if args.subcommand == "plddt":
        try:
            band = classify_plddt(args.score)
            print(f"PLDDT_SCORE:{args.score:.2f} BAND:{band}")
        except ValueError as e:
            # la guarda de rango informa por la salida estandar, sin abortar
            print(f"PLDDT_SCORE:{args.score:.2f} VALID:False ERROR:{e}")
    elif args.subcommand == "mean_plddt":
        s_list = [float(x) for x in args.scores.split(",")]
        m = calculate_mean_plddt(s_list)
        print(f"RESIDUES_COUNT:{len(s_list)} MEAN_PLDDT:{m:.6f}")
    elif args.subcommand == "pae":
        # se admiten los dos puntos como separador de filas, ademas del punto y
        # coma, para que la orden pueda escribirse sin comillas en la Shell
        rows = [[float(v) for v in r.split(",")] for r in args.matrix.replace(":", ";").split(";")]
        mean_pae, status = evaluate_interdomain_pae(rows)
        print(f"ROWS:{len(rows)} COLS:{len(rows[0])} MEAN_PAE_A:{mean_pae:.6f} STATUS:{status}")
    elif args.subcommand == "triangle":
        valid = check_triangle_inequality(args.d12, args.d23, args.d13)
        print(f"D12:{args.d12:.2f} D23:{args.d23:.2f} D13:{args.d13:.2f} VALID:{valid}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
