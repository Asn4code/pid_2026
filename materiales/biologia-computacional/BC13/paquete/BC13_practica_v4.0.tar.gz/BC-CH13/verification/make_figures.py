#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH13."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Diagrama de la arquitectura de AlphaFold2 que muestra el flujo desde MSA y pares por el Evoformer hacia el Structure Module.",
    "F02": "Escala de fiabilidad local pLDDT de AlphaFold con sus cuatro franjas de confianza coloreadas desde muy alta hasta muy baja.",
    "F03": "Matriz de Error Alineado Predicho PAE que distingue dominios globulares rígidos con bajo error relativo de uniones inter-dominio flexibles."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC13-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC13-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC13-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH13 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC13-F01: Arquitectura de AlphaFold2."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.1, "Arquitectura de Aprendizaje Profundo de AlphaFold2", ha="center", color=BLUE, fontweight="bold", fontsize=11)

    modules = [
        ("1. Entrada y MSA", "Secuencia diana\nAlineamiento MSA\nBúsqueda de plantillas", 1.8, 2.0, BLUE),
        ("2. Bloque Evoformer", "Atención axial en MSA\nRepresentación de pares\nActualizaciones triangulares", 5.0, 2.0, ORANGE),
        ("3. Structure Module", "Invariant Point Attention\nRotaciones / Traslaciones\nCoordenadas 3D + pLDDT/PAE", 8.2, 2.0, GREEN)
    ]
    for title, desc, cx, cy, col in modules:
        mbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(mbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8.5)

    ax.add_patch(FancyArrowPatch((3.3, 2.0), (3.5, 2.0), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))
    ax.add_patch(FancyArrowPatch((6.5, 2.0), (6.7, 2.0), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))

    save(fig, "F01")

def f02():
    """BC13-F02: Escala de confianza pLDDT."""
    fig, ax = plt.subplots(figsize=(7.5, 3.8), dpi=300)
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(50, 4.0, "Escala Oficial de Confianza Local pLDDT (AlphaFold)", ha="center", color=BLUE, fontweight="bold", fontsize=11)

    bands = [
        (0, 50, "Muy baja ($<50$)", "Naranja", "#FF7D45", "IDPs / Desorden conformacional"),
        (50, 70, "Baja ($50\\text{--}70$)", "Amarillo", "#FFDB13", "Bucles flexibles / Poca confianza"),
        (70, 90, "Alta ($70\\text{--}90$)", "Cian", "#65CBF3", "Topología del esqueleto fiable"),
        (90, 100, "Muy alta ($>90$)", "Azul marino", "#0053D6", "Cadenas laterales de alta fidelidad")
    ]

    for x0, x1, label, cname, col, desc in bands:
        w = x1 - x0
        rect = Rectangle((x0, 2.2), w, 0.8, fc=col, ec="white", lw=1.5)
        ax.add_patch(rect)
        ax.text(x0 + w/2, 2.6, f"{label}", ha="center", va="center", color="white" if x0 >= 70 or x0 < 50 else "black", fontweight="bold", fontsize=8.5)
        ax.text(x0 + w/2, 1.4, desc, ha="center", va="center", color=GRAY, fontsize=7.5, rotation=0)

    # Ticks line
    ax.plot([0, 100], [2.1, 2.1], color=GRAY, lw=1.5)
    for x in [0, 50, 70, 90, 100]:
        ax.plot([x, x], [2.0, 2.1], color=GRAY, lw=1.5)
        ax.text(x, 1.8, f"{x}", ha="center", color=GRAY, fontsize=8.5)

    save(fig, "F02")

def f03():
    """BC13-F03: Matriz PAE (Predicted Aligned Error)."""
    fig, ax = plt.subplots(figsize=(5.0, 4.2), dpi=300)
    n = 100
    pae = np.zeros((n, n))

    # Domain 1 (1 to 50): very low error
    pae[0:50, 0:50] = np.random.uniform(1.0, 4.0, (50, 50))
    # Domain 2 (51 to 100): very low error
    pae[50:100, 50:100] = np.random.uniform(1.0, 4.0, (50, 50))
    # Inter-domain (1-50 vs 51-100): high error (flexible linker)
    pae[0:50, 50:100] = np.random.uniform(18.0, 28.0, (50, 50))
    pae[50:100, 0:50] = np.random.uniform(18.0, 28.0, (50, 50))

    im = ax.imshow(pae, cmap="Greens_r", vmin=0, vmax=30, origin="upper")
    cbar = fig.colorbar(im, ax=ax, shrink=0.8)
    cbar.set_label("Error Alineado Esperado (\\AA)", fontsize=8.5)

    ax.set_title("Matriz PAE: Dominios Rígidos vs Enlace Flexible", fontsize=10, fontweight="bold", color=BLUE)
    ax.set_xlabel("Residuo Alineado $j$", fontsize=8.5)
    ax.set_ylabel("Residuo de Referencia $i$", fontsize=8.5)

    ax.text(25, 25, "Dominio 1\nRígido", color="white", fontweight="bold", ha="center", va="center", fontsize=8)
    ax.text(75, 75, "Dominio 2\nRígido", color="white", fontweight="bold", ha="center", va="center", fontsize=8)
    ax.text(75, 25, "Orientación\nIncierta", color="#174A7E", fontweight="bold", ha="center", va="center", fontsize=8)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
