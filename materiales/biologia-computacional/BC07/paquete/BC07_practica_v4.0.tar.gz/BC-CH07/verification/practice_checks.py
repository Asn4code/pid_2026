#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH07: Calidad de lecturas, formato FASTQ y preprocesamiento."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    decode_phred_string,
    parse_fastq_block,
    q_to_error_prob,
    sliding_window_trim,
)


def practice_anchor() -> None:
    # 1. Phred conversion for '?' (ASCII 63 -> Q=30)
    q_30 = ord("?") - 33
    p_30 = q_to_error_prob(q_30)
    
    # 2. FASTQ parsing of model read
    lines = [
        "@READ_01",
        "ATCGATCG",
        "+",
        "IIII????",
    ]
    parsed = parse_fastq_block(lines)
    scores_str = ";".join(str(s) for s in parsed["SCORES"])
    
    # 3. Sliding window trim (W=4, Q_min=20)
    seq = "ATCGATCGAT"
    qual = "IIIIII!!!!"
    t_seq, t_qual, t_len = sliding_window_trim(seq, qual, window_size=4, min_qual=20.0)
    
    print(f"PHRED_CHAR:? PHRED_Q:{q_30} ERR_PROB:{p_30:.6f} READ:{parsed['HEADER']} SCORES:{scores_str} MEAN_Q:{parsed['MEAN_Q']:.2f} TRIM_LEN:{t_len} TRIM_SEQ:{t_seq}")


def practice_perturbation() -> None:
    q_20 = ord("5") - 33
    p_20 = q_to_error_prob(q_20)
    print(f"PERTURBED_CHAR:5 PHRED_Q:{q_20} ERR_PROB:{p_20:.6f}")


def practice_domain_guard(qual_char: str = "\x1f") -> None:
    try:
        decode_phred_string(qual_char, offset=33)
        print(f"GUARD_CHAR:{repr(qual_char)} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_CHAR:{repr(qual_char)} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH07 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--char", type=str, default="\x1f")

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.char)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
