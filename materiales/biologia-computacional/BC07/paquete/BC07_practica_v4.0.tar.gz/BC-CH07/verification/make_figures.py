#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH07."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Anatomía del registro FASTQ de cuatro líneas y codificación de calidad Phred más 33 en caracteres ASCII.",
    "F02": "Perfil diagnóstico de calidad por ciclo de secuenciación de FastQC con zonas verde, amarilla y roja.",
    "F03": "Algoritmo de recorte por ventana deslizante y contraste entre coordenadas 1-based y 0-based."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC07-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC07-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC07-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH07 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC07-F01: Formato FASTQ y Phred+33."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Fastq box
    fbox = FancyBboxPatch((0.5, 0.4), 9.0, 3.7, boxstyle="round,pad=0.15", fc="white", ec=BLUE, lw=2)
    ax.add_patch(fbox)
    ax.text(5.0, 3.75, "Estructura de un Registro FASTQ (4 Líneas)", ha="center", color=BLUE, fontweight="bold", fontsize=11)

    lines = [
        ("Línea 1 (@ID):", "@SEQ_001_ILLUMINA_READ_1/1", BLUE),
        ("Línea 2 (Secuencia):", "A T G C C A T T G T A A", GREEN),
        ("Línea 3 (Separador):", "+", GRAY),
        ("Línea 4 (Calidad Phred+33):", "I I I I ? ? ? ? 5 5 5 !", RED)
    ]
    for i, (label, val, col) in enumerate(lines):
        y = 2.9 - i * 0.7
        ax.text(1.0, y, label, color=col, fontweight="bold", fontsize=9.5)
        ax.text(4.2, y, val, color=col, fontfamily="monospace", fontsize=11, fontweight="bold")

    # Callout for Phred mapping
    ax.text(5.0, 0.2, "Decodificación: '?' $\\to \\text{ASCII } 63 - 33 = Q30$ ($P_{\\text{err}} = 0.001$, Precisión $99.9\\%$)",
            ha="center", color=BLUE, fontsize=8.5, fontstyle="italic")

    save(fig, "F01")

def f02():
    """BC07-F02: Perfil FastQC por posición."""
    fig, ax = plt.subplots(figsize=(7.5, 3.8), dpi=300)
    cycles = np.arange(1, 151)
    # Quality starts high (Q38) and slightly decays towards 150 bp
    np.random.seed(42)
    mean_q = 38.0 - (cycles / 150)**2 * 12.0 + np.random.normal(0, 0.4, len(cycles))

    # Background zones
    ax.axhspan(28, 42, color="#EAF2EC", alpha=0.9, label="Zona Verde (Excelente: $Q \\geq 28$)")
    ax.axhspan(20, 28, color="#FFF9E6", alpha=0.9, label="Zona Amarilla (Aceptable: $20 \\leq Q < 28$)")
    ax.axhspan(0, 20, color="#FBEAEB", alpha=0.9, label="Zona Roja (Pobre: $Q < 20$)")

    ax.plot(cycles, mean_q, color=BLUE, lw=2.2, label="Calidad Phred Media")

    ax.set_xlabel("Ciclo de Secuenciación (Posición de Base en pb)", fontsize=9.5)
    ax.set_ylabel("Puntuación de Calidad Phred ($Q$)", fontsize=9.5)
    ax.set_title("Perfil de Calidad por Base (FastQC Quality Distribution)", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_xlim(1, 150)
    ax.set_ylim(0, 42)
    ax.legend(frameon=True, facecolor="white", edgecolor="none", fontsize=8, loc="lower left")
    ax.grid(True, linestyle=":", alpha=0.5)

    save(fig, "F02")

def f03():
    """BC07-F03: Ventana deslizante y 1-based vs 0-based."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Sliding window illustration
    wbox = FancyBboxPatch((0.5, 2.2), 9.0, 1.9, boxstyle="round,pad=0.1", fc="white", ec=GREEN, lw=1.8)
    ax.add_patch(wbox)
    ax.text(5.0, 3.75, "Recorte por Ventana Deslizante ($W=4, Q_{\\text{mín}}=20$)", ha="center", color=GREEN, fontweight="bold", fontsize=10)
    q_vals = "[35, 38, 32, 28, 30, 18, 12, 10, 8]"
    ax.text(5.0, 3.1, f"Calidades: {q_vals}", ha="center", fontfamily="monospace", fontsize=9.5, color=GRAY)
    ax.text(5.0, 2.5, "Ventana [18, 12, 10, 8] media $= 12.0 < 20 \\to$ Recorte en posición 5",
            ha="center", color=RED, fontweight="bold", fontsize=8.5)

    # Coordinates comparison below
    cbox = FancyBboxPatch((0.5, 0.2), 9.0, 1.6, boxstyle="round,pad=0.1", fc=LIGHT, ec=ORANGE, lw=1.5)
    ax.add_patch(cbox)
    ax.text(5.0, 1.45, "Comparativa de Sistemas de Coordenadas Genómicas", ha="center", color=ORANGE, fontweight="bold", fontsize=9.5)
    ax.text(2.6, 0.7, "1-Based Cerrado [start, end]\n(GFF3, GTF, VCF, SAM)", ha="center", color=BLUE, fontsize=8.5, fontweight="bold")
    ax.text(7.4, 0.7, "0-Based Semiabierto [start, end)\n(BED, BAM, Python, UCSC)", ha="center", color=ORANGE, fontsize=8.5, fontweight="bold")

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
