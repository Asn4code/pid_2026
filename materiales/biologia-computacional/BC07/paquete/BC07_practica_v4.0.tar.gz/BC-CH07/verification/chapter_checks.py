#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH07: Calidad de lecturas, formato FASTQ y preprocesamiento.

Implementa parsing de registros FASTQ de 4 lineas, conversion logaritmica Phred (Q <-> Perr),
decodificacion ASCII Phred+33, estadisticas de calidad media y recorte de calidad por ventana deslizante.
"""

from __future__ import annotations

import argparse
import math
import sys


def q_to_error_prob(q: float) -> float:
    return 10.0 ** (-q / 10.0)


def error_prob_to_q(p: float) -> float:
    if p <= 0.0 or p > 1.0:
        raise ValueError("Probabilidad de error debe pertenecer a (0.0, 1.0]")
    return -10.0 * math.log10(p)


def decode_phred_string(qual_str: str, offset: int = 33) -> list[int]:
    scores: list[int] = []
    for ch in qual_str:
        val = ord(ch) - offset
        if val < 0 or val > 93:
            raise ValueError(f"Caracter de calidad fuera de rango ({ch}, ASCII {ord(ch)}, Q={val}) para offset={offset}")
        scores.append(val)
    return scores


def encode_phred_string(scores: list[int], offset: int = 33) -> str:
    chars: list[str] = []
    for q in scores:
        if q < 0 or q > 93:
            raise ValueError(f"Puntuacion Phred fuera de rango ({q})")
        chars.append(chr(q + offset))
    return "".join(chars)


def parse_fastq_block(lines: list[str]) -> dict[str, str | list[int] | float]:
    if len(lines) != 4:
        raise ValueError(f"Un registro FASTQ debe contener exactamente 4 lineas, recibido {len(lines)}")
    
    header = lines[0].strip()
    seq = lines[1].strip()
    plus = lines[2].strip()
    qual = lines[3].strip()

    if not header.startswith("@"):
        raise ValueError(f"La primera linea del FASTQ debe comenzar por '@': {header}")
    if not plus.startswith("+"):
        raise ValueError(f"La tercera linea del FASTQ debe comenzar por '+': {plus}")
    if len(seq) != len(qual):
        raise ValueError(f"Longitud discordante entre secuencia ({len(seq)}) y calidad ({len(qual)})")

    scores = decode_phred_string(qual, offset=33)
    mean_q = sum(scores) / len(scores) if scores else 0.0
    mean_err = sum(q_to_error_prob(q) for q in scores) / len(scores) if scores else 0.0

    return {
        "HEADER": header,
        "SEQ": seq,
        "QUAL_STR": qual,
        "SCORES": scores,
        "LENGTH": len(seq),
        "MEAN_Q": mean_q,
        "MEAN_ERR": mean_err,
    }


def sliding_window_trim(seq: str, qual_str: str, window_size: int = 4, min_qual: float = 20.0, offset: int = 33) -> tuple[str, str, int]:
    if len(seq) != len(qual_str):
        raise ValueError("Secuencia y calidades con longitudes discordantes")
    if window_size <= 0:
        raise ValueError("El tamano de ventana debe ser positivo")
    
    scores = decode_phred_string(qual_str, offset=offset)
    n = len(seq)
    if n < window_size:
        return (seq, qual_str, n)

    cut_idx = n
    for i in range(n - window_size + 1):
        window_mean = sum(scores[i : i + window_size]) / float(window_size)
        if window_mean < min_qual:
            cut_idx = i
            break
            
    trimmed_seq = seq[:cut_idx]
    trimmed_qual = qual_str[:cut_idx]
    return (trimmed_seq, trimmed_qual, len(trimmed_seq))


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH07 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # phred
    p_phred = subparsers.add_parser("phred")
    p_phred.add_argument("qual_char", type=str)
    p_phred.add_argument("--offset", type=int, default=33)

    # fastq parse
    p_fq = subparsers.add_parser("parse_fastq")
    p_fq.add_argument("--header", type=str, default="@READ_01")
    p_fq.add_argument("--seq", type=str, default="ATCGATCG")
    p_fq.add_argument("--plus", type=str, default="+")
    p_fq.add_argument("--qual", type=str, default="IIII????")

    # trim
    p_trim = subparsers.add_parser("trim")
    p_trim.add_argument("--seq", type=str, default="ATCGATCGAT")
    p_trim.add_argument("--qual", type=str, default="IIIIII!!!!")
    p_trim.add_argument("--window", type=int, default=4)
    p_trim.add_argument("--min_qual", type=float, default=20.0)

    args = parser.parse_args()

    if args.subcommand == "phred":
        q = ord(args.qual_char) - args.offset
        p = q_to_error_prob(q)
        print(f"CHAR:{args.qual_char} ASCII:{ord(args.qual_char)} OFFSET:{args.offset} PHRED_Q:{q} ERR_PROB:{p:.6f}")
    elif args.subcommand == "parse_fastq":
        lines = [args.header, args.seq, args.plus, args.qual]
        res = parse_fastq_block(lines)
        scores_str = ";".join(str(s) for s in res["SCORES"])
        print(f"READ:{res['HEADER']} LENGTH:{res['LENGTH']} SCORES:{scores_str} MEAN_Q:{res['MEAN_Q']:.2f} MEAN_ERR:{res['MEAN_ERR']:.6f}")
    elif args.subcommand == "trim":
        t_seq, t_qual, t_len = sliding_window_trim(args.seq, args.qual, args.window, args.min_qual)
        print(f"ORIG_LEN:{len(args.seq)} TRIM_LEN:{t_len} TRIM_SEQ:{t_seq} TRIM_QUAL:{t_qual}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
