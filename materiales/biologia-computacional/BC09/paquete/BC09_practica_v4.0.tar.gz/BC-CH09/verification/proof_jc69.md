# Dominio de JC69

Para que

`d = -(3/4) ln(1 - 4p/3)`

sea real y finita, el argumento del logaritmo debe ser estrictamente positivo:

`1 - 4p/3 > 0`, y por tanto `p < 3/4`.

Como una proporción observada no puede ser negativa, el dominio didáctico es
`0 <= p < 3/4`. En `p = 3/4` el argumento es cero y no existe una distancia
real finita. Esta prueba es el oráculo formal de `BC09-A002`; la fuente científica
y la notación deben revisarse de forma independiente en C4.
