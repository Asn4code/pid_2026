# Prueba formal de BC09-A047: distancia p

Sean dos secuencias alineadas no vacías con `L` columnas comparables. Para cada
columna `i`, el indicador `I_i` vale uno si los símbolos difieren y cero si
coinciden. El número de discordancias es `m = suma_i I_i`. La proporción de
columnas discordantes es, por definición, la media de esos indicadores:

`p = (suma_i I_i) / L = m / L`, con `L > 0` y `0 <= m <= L`.

Por tanto `0 <= p <= 1`. La prueba no decide qué columnas deben excluirse por
huecos o ambigüedad; esa regla debe declararse antes de fijar `L`.
