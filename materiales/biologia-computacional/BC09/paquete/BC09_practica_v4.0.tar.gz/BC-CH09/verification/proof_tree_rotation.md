# Prueba formal de BC09-A006: invariancia por rotación

Un árbol enraizado puede representarse como una colección de clados, donde
cada clado es el conjunto de hojas descendientes de un nodo. Intercambiar el
orden gráfico de los hijos de un nodo no modifica qué hojas descienden de él.
Por tanto, la colección de clados permanece idéntica. La rotación cambia la
inmersión del árbol en el plano, pero no su topología.
