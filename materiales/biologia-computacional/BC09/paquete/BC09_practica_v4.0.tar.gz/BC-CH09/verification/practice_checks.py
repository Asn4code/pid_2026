#!/usr/bin/env python3
"""Fuente única de cómputo del anexo práctico de BC-CH09.

Lee siempre `data/practice_sequences.fasta`; ningún subcomando repite una
segunda copia de las secuencias. El anexo es propio del capítulo
(`practical_coupling: own`) y usa un conjunto de cuatro secuencias sintéticas
distinto del ejemplo A-B-C-D de la teoría.

Subcomandos:
  anchor          p-distancia y corrección JC69 de S1-S2, altura de la primera
                  fusión UPGMA y primera actualización ponderada hacia S3.
  full_tree       UPGMA ponderado completo sobre las cuatro secuencias con
                  distancias corregidas JC69.
  perturb_model   Igual que full_tree pero usando p-distancia sin corregir,
                  para aislar el efecto del modelo.
  perturb_data    Igual que full_tree pero con dos sustituciones adicionales
                  en S3, para aislar el efecto de los datos.
  domain_guard    Confirma que JC69 rechaza una p-distancia fuera de dominio
                  en vez de devolver un número engañoso.
"""

from __future__ import annotations

import argparse
import math
import sys
from itertools import combinations
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "practice_sequences.fasta"

# Posiciones (índice 0) y bases sustituidas en la perturbación de datos.
# Declaradas aquí, no en un segundo archivo, para que la perturbación sea una
# decisión visible del ejercicio y no un dato oculto.
PERTURBED_S3_SUBSTITUTIONS = {2: "A", 9: "A"}


def read_fasta(path: Path) -> dict[str, str]:
    sequences: dict[str, str] = {}
    label = None
    chunks: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith(">"):
            if label is not None:
                sequences[label] = "".join(chunks)
            label = line[1:].split()[0]
            chunks = []
        elif line.strip():
            chunks.append(line.strip())
    if label is not None:
        sequences[label] = "".join(chunks)
    return sequences


def p_distance(a: str, b: str) -> tuple[int, float]:
    if len(a) != len(b):
        raise ValueError("las secuencias comparadas deben tener la misma longitud")
    diffs = sum(1 for x, y in zip(a, b) if x != y)
    return diffs, diffs / len(a)


def jc69(p: float) -> float:
    if not 0.0 <= p < 0.75:
        raise ValueError("JC69 requiere 0 <= p < 0.75 para una distancia real finita")
    return -0.75 * math.log(1.0 - 4.0 * p / 3.0)


def pairwise_jc69(sequences: dict[str, str]) -> dict[frozenset[str], float]:
    taxa = list(sequences)
    distances: dict[frozenset[str], float] = {}
    for a, b in combinations(taxa, 2):
        _, p = p_distance(sequences[a], sequences[b])
        distances[frozenset((a, b))] = jc69(p)
    return distances


def pairwise_p(sequences: dict[str, str]) -> dict[frozenset[str], float]:
    taxa = list(sequences)
    distances: dict[frozenset[str], float] = {}
    for a, b in combinations(taxa, 2):
        _, p = p_distance(sequences[a], sequences[b])
        distances[frozenset((a, b))] = p
    return distances


def weighted_upgma(distances: dict[frozenset[str], float], taxa: list[str]) -> list[dict]:
    """UPGMA ponderado por tamaño de clúster. Devuelve el registro de fusiones."""
    dist = dict(distances)
    sizes = {t: 1 for t in taxa}
    active = set(taxa)
    log: list[dict] = []
    while len(active) > 1:
        names = sorted(active)
        best = None
        for x, y in combinations(names, 2):
            d = dist[frozenset((x, y))]
            if best is None or d < best[0]:
                best = (d, x, y)
        d, x, y = best
        new_name = f"({x},{y})"
        wx, wy = sizes[x], sizes[y]
        for other in active:
            if other in (x, y):
                continue
            dx = dist[frozenset((x, other))]
            dy = dist[frozenset((y, other))]
            dist[frozenset((new_name, other))] = (wx * dx + wy * dy) / (wx + wy)
        sizes[new_name] = wx + wy
        active = (active - {x, y}) | {new_name}
        log.append(
            {
                "merge": f"{x}+{y}",
                "weights": (wx, wy),
                "distance": round(d, 6),
                "height": round(d / 2, 6),
                "cluster": new_name,
            }
        )
    return log


def format_log(log: list[dict]) -> str:
    return "; ".join(
        f"{step['merge']}(w={step['weights'][0]}:{step['weights'][1]})"
        f"->d={step['distance']:.6f},h={step['height']:.6f}"
        for step in log
    )


def cmd_anchor(sequences: dict[str, str]) -> None:
    diffs, p = p_distance(sequences["S1"], sequences["S2"])
    d12 = jc69(p)
    h12 = d12 / 2
    _, p13 = p_distance(sequences["S1"], sequences["S3"])
    _, p23 = p_distance(sequences["S2"], sequences["S3"])
    d13, d23 = jc69(p13), jc69(p23)
    updated = (1 * d13 + 1 * d23) / (1 + 1)
    print(
        f"diffs_S1_S2={diffs} p_S1_S2={p:.6f} jc69_S1_S2={d12:.6f} "
        f"height_first_merge={h12:.6f} "
        f"d_S1_S3={d13:.6f} d_S2_S3={d23:.6f} "
        f"weighted_update_S1S2_to_S3={updated:.6f}"
    )


def cmd_full_tree(sequences: dict[str, str]) -> None:
    taxa = list(sequences)
    distances = pairwise_jc69(sequences)
    log = weighted_upgma(distances, taxa)
    print(f"model=JC69 {format_log(log)}")


def cmd_perturb_model(sequences: dict[str, str]) -> None:
    taxa = list(sequences)
    distances = pairwise_p(sequences)
    log = weighted_upgma(distances, taxa)
    print(f"model=p_distance {format_log(log)}")


def cmd_perturb_data(sequences: dict[str, str]) -> None:
    taxa = list(sequences)
    perturbed = dict(sequences)
    bases = "ACGT"
    s3 = list(perturbed["S3"])
    changes = []
    for position, forced_base in PERTURBED_S3_SUBSTITUTIONS.items():
        original = s3[position]
        assert forced_base != original, "la perturbación debe cambiar la base"
        assert forced_base in bases
        changes.append((position, original, forced_base))
        s3[position] = forced_base
    perturbed["S3"] = "".join(s3)
    distances = pairwise_jc69(perturbed)
    log = weighted_upgma(distances, taxa)
    changes_text = ",".join(f"{pos}:{orig}->{new}" for pos, orig, new in changes)
    print(f"model=JC69 perturbed_S3_changes={changes_text} {format_log(log)}")


def cmd_domain_guard(_: dict[str, str]) -> None:
    try:
        jc69(0.8)
    except ValueError:
        print("domain_guard=REJECTED p=0.8 out_of_domain=True")
    else:
        raise AssertionError("JC69 debía rechazar p=0.8 y no lo hizo")


def _perturbed_sequences(sequences: dict[str, str]) -> dict[str, str]:
    perturbed = dict(sequences)
    s3 = list(perturbed["S3"])
    for position, forced_base in PERTURBED_S3_SUBSTITUTIONS.items():
        s3[position] = forced_base
    perturbed["S3"] = "".join(s3)
    return perturbed


def cmd_invariant_first_merge(sequences: dict[str, str]) -> None:
    """Comprueba que S1+S2 es la primera fusión en las cuatro variantes."""
    taxa = list(sequences)
    variants = {
        "base_jc69": weighted_upgma(pairwise_jc69(sequences), taxa),
        "perturb_model": weighted_upgma(pairwise_p(sequences), taxa),
        "perturb_data": weighted_upgma(pairwise_jc69(_perturbed_sequences(sequences)), taxa),
    }
    results = {name: log[0]["merge"] in ("S1+S2", "S2+S1") for name, log in variants.items()}
    ok = all(results.values())
    detail = " ".join(f"{name}={'S1+S2' if value else 'OTHER'}" for name, value in results.items())
    print(f"invariant_first_merge_S1_S2={ok} {detail}")
    if not ok:
        raise AssertionError("S1+S2 dejó de ser la primera fusión en alguna variante")


COMMANDS = {
    "anchor": cmd_anchor,
    "full_tree": cmd_full_tree,
    "perturb_model": cmd_perturb_model,
    "perturb_data": cmd_perturb_data,
    "domain_guard": cmd_domain_guard,
    "invariant_first_merge": cmd_invariant_first_merge,
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=sorted(COMMANDS))
    parser.add_argument("--data", type=Path, default=DATA_PATH)
    args = parser.parse_args()
    sequences = read_fasta(args.data)
    expected_taxa = {"S1", "S2", "S3", "S4"}
    if set(sequences) != expected_taxa:
        raise SystemExit(f"fasta inesperado: se esperaban {sorted(expected_taxa)}, se leyeron {sorted(sequences)}")
    COMMANDS[args.command](sequences)
    return 0


if __name__ == "__main__":
    sys.exit(main())
