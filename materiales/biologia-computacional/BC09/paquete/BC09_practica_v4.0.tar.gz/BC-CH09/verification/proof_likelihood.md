# Prueba formal de BC09-A055: producto y log-verosimilitud

Si el modelo considera que los sitios D_i son independientes condicionados
al árbol T y a sus parámetros theta, la regla del producto da

P(D|T,theta) = producto_i P(D_i|T,theta).

Como ln(ab)=ln(a)+ln(b) para probabilidades positivas,

ln L(T,theta;D) = suma_i ln P(D_i|T,theta).

Esta identidad justifica sumar log-verosimilitudes de sitio. No demuestra que
la independencia, el árbol o el modelo describan adecuadamente el proceso real.
