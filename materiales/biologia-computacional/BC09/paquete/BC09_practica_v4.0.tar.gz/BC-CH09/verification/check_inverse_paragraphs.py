#!/usr/bin/env python3
"""Fail closed if the inverse disposition of theory.tex is incomplete or stale."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path
import re
import sys


CHAPTER = Path(__file__).resolve().parents[1]
THEORY = CHAPTER / "theory.tex"
CLAIMS = CHAPTER / "claims.csv"
DISPOSITION = CHAPTER / "audit" / "inverse_paragraph_disposition.csv"
FIELDS = (
    "theory_sha256",
    "paragraph_id",
    "paragraph_index",
    "text_sha256",
    "classification",
    "claim_ids",
    "justification",
    "coverage_note",
    "human_reviewer",
    "reviewed_on",
)
CLAIM_TOKEN = re.compile(r"BC09-A\d{3}")
EVALUABLE_PROSE = re.compile(
    r"\b(debe|deben|exige|requiere|rechaza|produce|calcula|implica|"
    r"conclu|interpreta|permite|demuestra|comprueba|verifica)\b",
    re.IGNORECASE,
)


def paragraphs(text: str) -> list[str]:
    return [chunk.strip() for chunk in re.split(r"\n\s*\n", text) if chunk.strip()]


def normalized(chunk: str) -> str:
    return "\n".join(line.rstrip() for line in chunk.splitlines()).strip()


def disposition_id(chunk: str, occurrence: int) -> tuple[str, str]:
    digest = hashlib.sha256(normalized(chunk).encode("utf-8")).hexdigest()
    return f"BC09-P-{digest[:12]}-{occurrence:02d}", digest


def visible_prose(chunk: str) -> str:
    lines = []
    for line in chunk.splitlines():
        stripped = line.strip()
        if stripped.startswith("%"):
            continue
        if re.fullmatch(r"\\(?:RouteEssential|RouteStudy|RouteReference)", stripped):
            continue
        if re.fullmatch(r"\\graphicspath.*", stripped):
            continue
        if re.fullmatch(r"\\(?:chapter|section|subsection|subsection\*|section\*|paragraph)\{.*", stripped):
            continue
        lines.append(stripped)
    return " ".join(lines)


def main() -> int:
    theory_bytes = THEORY.read_bytes()
    theory_hash = hashlib.sha256(theory_bytes).hexdigest()
    chunks = paragraphs(theory_bytes.decode("utf-8"))
    with CLAIMS.open(newline="", encoding="utf-8") as handle:
        claims = list(csv.DictReader(handle))
    registered = {row["claim_id"] for row in claims}
    theory_claims = {
        row["claim_id"] for row in claims if row["manuscript_anchor"].startswith("theory.tex:")
    }
    with DISPOSITION.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        if tuple(reader.fieldnames or ()) != FIELDS:
            raise RuntimeError("cabecera de disposición inversa ausente o divergente")
        rows = list(reader)

    errors: list[str] = []
    if len(rows) != len(chunks):
        errors.append(f"párrafos esperados={len(chunks)} inventariados={len(rows)}")
    occurrences: dict[str, int] = {}
    associated: set[str] = set()
    for index, chunk in enumerate(chunks, start=1):
        if index > len(rows):
            errors.append(f"falta el párrafo {index}")
            continue
        row = rows[index - 1]
        _, digest = disposition_id(chunk, 1)
        occurrences[digest] = occurrences.get(digest, 0) + 1
        paragraph_id, text_hash = disposition_id(chunk, occurrences[digest])
        if row["theory_sha256"] != theory_hash:
            errors.append(f"{paragraph_id}: hash global de theory.tex divergente")
        if row["paragraph_index"] != str(index):
            errors.append(f"{paragraph_id}: índice divergente")
        if row["paragraph_id"] != paragraph_id:
            errors.append(f"párrafo {index}: ID estable divergente")
        if row["text_sha256"] != text_hash:
            errors.append(f"{paragraph_id}: hash de texto divergente")
        classification = row["classification"].strip()
        ids = [item for item in row["claim_ids"].split(";") if item]
        if row["human_reviewer"] != "author-C4-r7" or row["reviewed_on"] != "2026-08-06":
            errors.append(f"{paragraph_id}: revisión humana r7 no registrada")
        if classification not in {"CLAIM", "NONSUBSTANTIVE"}:
            errors.append(f"{paragraph_id}: clasificación vacía o inválida")
        elif classification == "CLAIM":
            if not ids:
                errors.append(f"{paragraph_id}: CLAIM sin claim_ids")
            unknown = set(ids) - registered
            if unknown:
                errors.append(f"{paragraph_id}: claims inexistentes {sorted(unknown)}")
            associated.update(ids)
            if row["justification"].strip():
                errors.append(f"{paragraph_id}: CLAIM no debe usar justificación sustitutiva")
            if not row["coverage_note"].strip():
                errors.append(f"{paragraph_id}: CLAIM sin nota de cobertura humana")
        else:
            if ids:
                errors.append(f"{paragraph_id}: NONSUBSTANTIVE no admite claim_ids")
            if not row["justification"].strip():
                errors.append(f"{paragraph_id}: NONSUBSTANTIVE sin justificación")
            if row["coverage_note"].strip():
                errors.append(f"{paragraph_id}: NONSUBSTANTIVE no admite coverage_note")
            prose = visible_prose(chunk)
            if CLAIM_TOKEN.search(chunk) or "% LOAD-MANUAL:" in chunk:
                errors.append(f"{paragraph_id}: marcador evaluable clasificado NONSUBSTANTIVE")
            if prose and (re.search(r"\d", prose) or EVALUABLE_PROSE.search(prose)):
                errors.append(f"{paragraph_id}: número o proposición evaluable clasificado NONSUBSTANTIVE")
    missing_claims = theory_claims - associated
    if missing_claims:
        errors.append(f"claims de theory.tex sin disposición: {sorted(missing_claims)}")
    if len(rows) > len(chunks):
        errors.append(f"sobran {len(rows) - len(chunks)} filas")
    if errors:
        for error in errors:
            print(f"INVERSE_PARAGRAPH_ERROR {error}", file=sys.stderr)
        return 1
    print(
        f"INVERSE_PARAGRAPH_OK theory_sha256={theory_hash} "
        f"paragraphs={len(chunks)} theory_claims={len(theory_claims)} "
        f"human_claim_reviews={sum(row['classification'] == 'CLAIM' for row in rows)}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
