#!/usr/bin/env python3
"""Comprueba clados invariantes en dos escrituras obtenidas por rotación."""


def leaf_set(node):
    if isinstance(node, str):
        return frozenset([node])
    return frozenset().union(*(leaf_set(child) for child in node))


def nontrivial_clades(node, total):
    if isinstance(node, str):
        return set()
    result = set()
    for child in node:
        leaves = leaf_set(child)
        if 1 < len(leaves) < total:
            result.add("".join(sorted(leaves)))
        result.update(nontrivial_clades(child, total))
    return result


tree_one = (("A", "B"), ("C", "D"))
tree_rotated = (("D", "C"), ("B", "A"))
clades_one = nontrivial_clades(tree_one, 4)
clades_two = nontrivial_clades(tree_rotated, 4)
assert clades_one == clades_two
print(" ".join(sorted(clades_one)))
