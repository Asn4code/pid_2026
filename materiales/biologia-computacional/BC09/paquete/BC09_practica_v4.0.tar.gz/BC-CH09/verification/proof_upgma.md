# Prueba formal de BC09-A026: actualización ponderada de UPGMA

La distancia entre dos clústeres en UPGMA es la media de todas las distancias
entre pares de hojas, una en cada clúster. Si `U=A unión B`, entonces la suma
de distancias desde `U` a `C` contiene `|A||C|` pares de tipo A--C y `|B||C|`
pares de tipo B--C. Al dividir por `(|A|+|B|)|C|` se obtiene

`d(U,C) = (|A| d(A,C) + |B| d(B,C))/(|A|+|B|)`.

La media no ponderada sólo coincide con esta expresión cuando ambos clústeres
tienen el mismo número de hojas.
