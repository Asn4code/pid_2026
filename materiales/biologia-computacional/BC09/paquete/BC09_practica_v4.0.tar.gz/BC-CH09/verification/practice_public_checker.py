#!/usr/bin/env python3
"""Comprobador público del cálculo ancla de BC-CH09 (no revela la solución).

El alumnado introduce sus propios resultados intermedios; el script comprueba
propiedades y consistencia algebraica interna, no compara contra un valor
oculto que se imprima al fallar. Un `FAIL` explica qué relación no se cumple,
nunca cuál es el número correcto.

Uso:
  python3 practice_public_checker.py \
      --diffs N --p P --jc69 D --d13 D13 --d23 D23 --updated U

Todos los valores son los que el alumnado calculó a mano para S1, S2 y S3
usando `data/practice_sequences.fasta`.
"""

from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "practice_sequences.fasta"
SEQUENCE_LENGTH = 16
TOLERANCE = 1e-4


def read_fasta(path: Path) -> dict[str, str]:
    sequences: dict[str, str] = {}
    label = None
    chunks: list[str] = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith(">"):
            if label is not None:
                sequences[label] = "".join(chunks)
            label = line[1:].split()[0]
            chunks = []
        elif line.strip():
            chunks.append(line.strip())
    if label is not None:
        sequences[label] = "".join(chunks)
    return sequences


def check(label: str, condition: bool, hint: str, failures: list[str]) -> None:
    if condition:
        print(f"PASS  {label}")
    else:
        print(f"FAIL  {label} — {hint}")
        failures.append(label)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--diffs", type=int, required=True, help="posiciones distintas entre S1 y S2")
    parser.add_argument("--p", type=float, required=True, help="p-distancia S1-S2")
    parser.add_argument("--jc69", type=float, required=True, help="distancia JC69 corregida S1-S2")
    parser.add_argument("--d13", type=float, required=True, help="distancia JC69 corregida S1-S3 (dada)")
    parser.add_argument("--d23", type=float, required=True, help="distancia JC69 corregida S2-S3 (dada)")
    parser.add_argument("--updated", type=float, required=True, help="actualización ponderada de {S1,S2} hacia S3")
    args = parser.parse_args()

    failures: list[str] = []

    sequences = read_fasta(DATA_PATH)
    true_diffs = sum(1 for x, y in zip(sequences["S1"], sequences["S2"]) if x != y)

    check(
        "longitud_secuencias",
        len(sequences["S1"]) == SEQUENCE_LENGTH and len(sequences["S2"]) == SEQUENCE_LENGTH,
        "S1 y S2 deben tener longitud 16 en el fasta publicado; revisa la lectura del archivo.",
        failures,
    )
    check(
        "conteo_diferencias",
        args.diffs == true_diffs,
        "el número de posiciones distintas entre S1 y S2 no coincide con un recuento directo "
        "sobre `data/practice_sequences.fasta`; recuenta posición a posición.",
        failures,
    )
    check(
        "p_distancia_definicion",
        abs(args.p - args.diffs / SEQUENCE_LENGTH) < TOLERANCE,
        "p no es diffs/16 con los valores que declaraste; revisa la división.",
        failures,
    )
    check(
        "p_en_dominio_jc69",
        0.0 <= args.p < 0.75,
        "una p fuera de [0, 0.75) no admite corrección JC69 finita; algo falló antes de este paso.",
        failures,
    )
    if 0.0 <= args.p < 0.75:
        recomputed_jc69 = -0.75 * math.log(1.0 - 4.0 * args.p / 3.0)
        check(
            "formula_jc69",
            abs(args.jc69 - recomputed_jc69) < TOLERANCE,
            "tu distancia JC69 no coincide con -0.75*ln(1 - 4p/3) evaluada en tu propia p; "
            "revisa el logaritmo y los coeficientes, no vuelvas a copiar un resultado ajeno.",
            failures,
        )
    check(
        "actualizacion_ponderada_algebra",
        abs(args.updated - (1 * args.d13 + 1 * args.d23) / 2) < TOLERANCE,
        "la actualización de {S1,S2} hacia S3 debe ser el promedio ponderado por tamaño de "
        "clúster (1 y 1 en esta primera fusión) de d13 y d23 que tú mismo declaraste; "
        "revisa la fórmula, no el valor de d13/d23.",
        failures,
    )
    check(
        "distancias_no_negativas",
        args.jc69 >= 0 and args.d13 >= 0 and args.d23 >= 0 and args.updated >= 0,
        "una distancia evolutiva corregida no puede ser negativa.",
        failures,
    )

    if failures:
        print(f"\nRESULT=FAIL failed_checks={','.join(failures)}")
        return 1
    print("\nRESULT=PASS")
    return 0


if __name__ == "__main__":
    sys.exit(main())
