#!/usr/bin/env python3
"""Execute the real Bio.Phylo API on a pinned minimal Newick input."""

from __future__ import annotations

import hashlib
from io import StringIO
import os
from pathlib import Path
import sys


# Import outside the project tree to avoid accidental source-tree shadowing.
os.chdir("/tmp")
import Bio  # noqa: E402
from Bio import Phylo  # noqa: E402


EXPECTED_BIOPYTHON = "1.84"
INPUT = Path(__file__).resolve().parent / "data" / "biophylo_minimal.newick"
EXPECTED_TERMINALS = ("A", "B", "C")


def parse_terminals(newick: str) -> tuple[str, ...]:
    tree = Phylo.read(StringIO(newick), "newick")
    return tuple(terminal.name for terminal in tree.get_terminals())


def rejects_wrong_expectation(observed: tuple[str, ...]) -> bool:
    try:
        if observed != ("A", "B", "D"):
            raise AssertionError("terminal expectation mismatch")
    except AssertionError:
        return True
    return False


def rejects_empty_input() -> bool:
    try:
        Phylo.read(StringIO(""), "newick")
    except ValueError:
        return True
    return False


def main() -> None:
    if sys.version_info[:2] != (3, 9):
        raise RuntimeError(f"unexpected Python runtime: {sys.version_info[:2]}")
    if Bio.__version__ != EXPECTED_BIOPYTHON:
        raise RuntimeError(f"unexpected Biopython runtime: {Bio.__version__}")
    payload = INPUT.read_bytes()
    newick = payload.decode("ascii").strip()
    observed = parse_terminals(newick)
    if observed != EXPECTED_TERMINALS:
        raise AssertionError(f"unexpected terminals: {observed}")
    package_file = Path(Bio.__file__).resolve()
    package_sha256 = hashlib.sha256(package_file.read_bytes()).hexdigest()
    print(
        f"python={sys.version_info.major}.{sys.version_info.minor} "
        f"biopython={Bio.__version__} api=Bio.Phylo.read format=newick "
        f"input_sha256={hashlib.sha256(payload).hexdigest()} "
        f"package_init_sha256={package_sha256} terminals={','.join(observed)} count={len(observed)} "
        f"empty_rejected={rejects_empty_input()} "
        f"wrong_expectation_rejected={rejects_wrong_expectation(observed)}"
    )


if __name__ == "__main__":
    main()
