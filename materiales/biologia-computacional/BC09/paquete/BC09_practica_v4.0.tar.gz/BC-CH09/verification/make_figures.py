#!/usr/bin/env python3
"""Genera las figuras originales y reproducibles del capítulo BC-CH09."""

from __future__ import annotations

import argparse
import datetime as dt
import math
import os
import tempfile
from pathlib import Path

# Matplotlib consulta esta variable al crear el tráiler PDF. Se fija antes de
# importar pyplot para que dos ejecuciones produzcan el mismo binario.
os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch

from fixtures import (
    BOOTSTRAP_OUTCOMES,
    BOOTSTRAP_REPLICATES,
    CHAIN_EDGES,
    CHAIN_STAGES,
    GENE_COPY_GROUPS,
    LBA,
    MSA_1,
    MSA_2,
    RAW_MSA,
    ROOTED_SPLIT,
    SPECIES,
    SPECIES_TREE_ORDER,
    TREE_COUNT_ANCHORS,
    TREE_ROTATIONS,
    UNROOTED_SPLIT,
    UPGMA,
    UPGMA_DRAW,
)

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
GRAY = "#555555"
LIGHT = "#E8EEF3"
ALT_TEXTS = {
    "F01": "Tres rotaciones conservan los clados AB y CD.",
    "F02": "Un árbol enraizado con raíz rotulada se contrasta con el split no enraizado AB frente a CD.",
    "F03": "Dos MSA válidos de ocho columnas recuperan las mismas secuencias crudas y difieren en la colocación de huecos.",
    "F04": "Siete etapas conectan pregunta, secuencias, MSA, modelo, búsqueda, apoyo y afirmación.",
    "F05": "La curva JC69 pasa por p 0,1 y diverge al acercarse a p 0,75.",
    "F06": "Dendrograma UPGMA con A, B, C y D en hojas terminales equidistantes 15,5 de la raíz.",
    "F07": "El número de topologías no enraizadas crece combinatoriamente con el número de taxones.",
    "F08": "Cuatro remuestreos de ocho columnas producen AB, AC, AB y AB, equivalente a 75 por ciento.",
    "F09": "Ramas terminales largas A y D separadas en la historia quedan agrupadas por homoplasias en el esquema erróneo.",
    "F10": "El árbol génico contiene copias alfa y beta de las mismas especies A, B, C y D del árbol de especies.",
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)



def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC09-{name}.pdf"
    temporary: Path | None = None
    try:
        # NamedTemporaryFile solo reserva un nombre único. Matplotlib escribe
        # el PDF completo en ese inode; os.replace publica después el binario
        # de una vez dentro del mismo sistema de archivos.
        with tempfile.NamedTemporaryFile(
            dir=OUT, prefix=f".BC09-{name}.", suffix=".pdf", delete=False
        ) as handle:
            temporary = Path(handle.name)
        fig.savefig(
            temporary,
            bbox_inches="tight",
            metadata={
                "Title": f"BC09-{name}",
                "Subject": ALT_TEXTS[name],
                "Creator": "BC-CH09 make_figures.py",
                "CreationDate": FIXED_PDF_DATE,
                "ModDate": FIXED_PDF_DATE,
            },
        )
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        os.replace(temporary, target)
        temporary = None
        directory_fd = os.open(OUT, os.O_RDONLY | getattr(os, "O_DIRECTORY", 0))
        try:
            os.fsync(directory_fd)
        finally:
            os.close(directory_fd)
    finally:
        plt.close(fig)
        if temporary is not None:
            temporary.unlink(missing_ok=True)


def edge(ax, a, b, color=GRAY, width=1.8, style="-"):
    ax.plot([a[0], b[0]], [a[1], b[1]], color=color, lw=width, ls=style, zorder=1)


def label(ax, p, text, dx=0.03, dy=0.0, **kwargs):
    ax.text(p[0] + dx, p[1] + dy, text, va="center", fontsize=10, **kwargs)


def tree_panel(ax, order, title):
    root = (0.08, 0.5)
    n1 = (0.42, 0.68)
    n2 = (0.42, 0.32)
    tips = [(0.88, 0.85), (0.88, 0.57), (0.88, 0.43), (0.88, 0.15)]
    edge(ax, root, n1); edge(ax, root, n2)
    edge(ax, n1, tips[0]); edge(ax, n1, tips[1])
    edge(ax, n2, tips[2]); edge(ax, n2, tips[3])
    for point, taxon in zip(tips, order):
        label(ax, point, taxon)
    ax.scatter(*root, s=18, color=ORANGE, zorder=2)
    ax.scatter([n1[0], n2[0]], [n1[1], n2[1]], s=14, color=BLUE, zorder=2)
    ax.set_title(title, fontsize=11)
    ax.set_xlim(0, 1.08); ax.set_ylim(0, 1); ax.axis("off")


def f01():
    fig, axes = plt.subplots(1, 3, figsize=(7.2, 2.9))
    titles = ("Dibujo 1", "Rotación en ambos nodos", "Rotación en la raíz")
    for ax, order, title in zip(axes, TREE_ROTATIONS, titles):
        tree_panel(ax, order, title)
    fig.suptitle("Tres dibujos, los mismos clados: {A,B} y {C,D}", fontsize=12, color=BLUE)
    fig.tight_layout(rect=(0, 0, 1, .88))
    save(fig, "F01")


def f02():
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.5))
    tree_panel(axes[0], tuple(ROOTED_SPLIT[0] + ROOTED_SPLIT[1]), "Enraizado: hay dirección histórica")
    axes[0].annotate("RAÍZ", xy=(.08,.5), xytext=(.02,.12), fontsize=10, weight="bold",
                     arrowprops={"arrowstyle":"->", "color":"black"})
    axes[0].annotate("hacia las hojas", xy=(.72,.76), xytext=(.30,.92), fontsize=9,
                     arrowprops={"arrowstyle":"->", "color":"black"})
    ax = axes[1]
    center = (0.5, 0.5)
    # El orden de dibujo procede de la tupla estable; UNROOTED_SPLIT se usa
    # únicamente como objeto matemático sin orden en el oráculo.
    left_taxa, right_taxa = ROOTED_SPLIT
    tips = {left_taxa[0]: (0.12, .82), left_taxa[1]: (.12, .18), right_taxa[0]: (.88, .82), right_taxa[1]: (.88, .18)}
    left, right = (.34, .5), (.66, .5)
    edge(ax, left, right)
    edge(ax, left, tips[left_taxa[0]]); edge(ax, left, tips[left_taxa[1]])
    edge(ax, right, tips[right_taxa[0]]); edge(ax, right, tips[right_taxa[1]])
    for taxon, point in tips.items(): label(ax, point, taxon, dx=.02)
    ax.text(center[0], .08, "La bipartición AB | CD no fija una raíz", ha="center", fontsize=9)
    ax.set_title("No enraizado: relaciones sin polaridad", fontsize=10)
    ax.set_xlim(0, 1); ax.set_ylim(0, 1); ax.axis("off")
    fig.suptitle("La raíz añade polaridad; no aparece por mover el dibujo", fontsize=12, color=BLUE, y=.99)
    fig.tight_layout(rect=(0,0,1,.90))
    save(fig, "F02")


def f03():
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.axis("off")
    ax.text(.03, .93, "Secuencias", fontsize=11, weight="bold", color=BLUE)
    raw = [f"{name}  {sequence}" for name, sequence in RAW_MSA.items()]
    for i, line in enumerate(raw): ax.text(.03, .82-i*.08, line, family="monospace", fontsize=11)
    ax.text(.37, .93, "Hipótesis MSA 1", fontsize=11, weight="bold", color=GREEN)
    msa1 = [f"{name}  {sequence}" for name, sequence in MSA_1.items()]
    for i, line in enumerate(msa1): ax.text(.37, .82-i*.08, line, family="monospace", fontsize=11)
    ax.text(.70, .93, "Hipótesis MSA 2", fontsize=11, weight="bold", color=ORANGE)
    msa2 = [f"{name}  {sequence}" for name, sequence in MSA_2.items()]
    for i, line in enumerate(msa2): ax.text(.70, .82-i*.08, line, family="monospace", fontsize=11)
    ax.add_patch(FancyBboxPatch((.33,.50),.64,.13,boxstyle="round,pad=.02",fc=LIGHT,ec="none"))
    ax.text(.65,.565,"Los guiones cambian qué residuos se comparan columna a columna.",ha="center",va="center",fontsize=10)
    ax.add_patch(FancyArrowPatch((.18,.46),(.45,.20),arrowstyle="->",mutation_scale=15,color=GRAY))
    ax.add_patch(FancyArrowPatch((.54,.46),(.54,.20),arrowstyle="->",mutation_scale=15,color=GREEN))
    ax.add_patch(FancyArrowPatch((.83,.46),(.67,.20),arrowstyle="->",mutation_scale=15,color=ORANGE))
    ax.text(.54,.10,"Cada alineamiento induce un conjunto distinto de caracteres",ha="center",fontsize=11,weight="bold")
    save(fig, "F03")


def f04():
    fig, ax = plt.subplots(figsize=(7.2, 4.4))
    ax.axis("off")
    boxes = CHAIN_STAGES
    positions=[(.12,.73),(.37,.73),(.62,.73),(.87,.73),(.25,.32),(.50,.32),(.75,.32)]
    for i, ((head, body), (x,y)) in enumerate(zip(boxes, positions)):
        ax.add_patch(FancyBboxPatch((x-.10,y-.12),.20,.24,boxstyle="round,pad=.012",fc=LIGHT if i%2==0 else "#E6F0EC",ec=BLUE,lw=1.2))
        ax.text(x,y+.035,head,ha="center",va="center",fontsize=10,weight="bold")
        ax.text(x,y-.045,body,ha="center",va="center",fontsize=9,wrap=True)
    for source, target in CHAIN_EDGES:
        x, y = positions[source]
        nx, ny = positions[target]
        if source == 3:
            start, end = (x, y-.13), (nx, ny+.13)
            connection = "arc3,rad=.25"
        else:
            start, end = (x+.105, y), (nx-.105, ny)
            connection = "arc3,rad=0"
        ax.add_patch(FancyArrowPatch(start, end, arrowstyle="->", connectionstyle=connection,
                                     mutation_scale=14, color=ORANGE))
    ax.text(.5,.06,"Una decisión aguas arriba puede alterar las inferencias posteriores",ha="center",fontsize=10,color=GRAY)
    ax.set_xlim(0,1); ax.set_ylim(0,1)
    save(fig, "F04")


def f05():
    fig, ax = plt.subplots(figsize=(7.4, 4.4))
    ps = [i/1000 for i in range(0,750)]
    ds = [-.75*math.log(1-4*p/3) for p in ps]
    ax.plot(ps, ds, color=BLUE, lw=2.2, label="distancia JC69")
    ax.plot(ps, ps, color=GRAY, ls="--", label="distancia observada p")
    ax.axvline(.75, color=ORANGE, ls=":", lw=2)
    ax.annotate("frontera p=0,75", xy=(.75,2.5), xytext=(.52,3.35), arrowprops={"arrowstyle":"->","color":ORANGE}, color=ORANGE)
    ax.scatter([.1],[-.75*math.log(1-4*.1/3)],color=GREEN,zorder=3)
    ax.annotate("p=0,10 → d=0,107326",xy=(.1,-.75*math.log(1-4*.1/3)),xytext=(.18,.55),arrowprops={"arrowstyle":"->"})
    ax.set(xlabel="Proporción observada de diferencias, p",ylabel="Sustituciones estimadas por sitio",xlim=(0,.78),ylim=(0,4))
    ax.legend(frameon=False,loc="upper left"); ax.grid(alpha=.2)
    save(fig, "F05")


def f06():
    fig, ax = plt.subplots(figsize=(7.2, 4.5))
    y = UPGMA_DRAW["leaf_y"]
    leaf_x = UPGMA_DRAW["leaf_x"]
    ab_x = UPGMA_DRAW["ab_x"]
    abc_x = UPGMA_DRAW["abc_x"]
    root_x = UPGMA_DRAW["root_x"]
    # El eje mide distancia desde la raíz: todas las hojas terminan en 15,5.
    for taxon in "ABCD": ax.text(leaf_x[taxon]+.25,y[taxon],taxon,va="center",fontsize=11)
    ax.plot([ab_x,leaf_x["A"]],[y["A"],y["A"]],color=BLUE); ax.plot([ab_x,leaf_x["B"]],[y["B"],y["B"]],color=BLUE)
    ax.plot([ab_x,ab_x],[y["B"],y["A"]],color=BLUE)
    yab=(y["A"]+y["B"])/2
    ax.plot([abc_x,ab_x],[yab,yab],color=GREEN,lw=2)
    ax.plot([abc_x,leaf_x["C"]],[y["C"],y["C"]],color=GREEN)
    ax.plot([abc_x,abc_x],[y["C"],yab],color=GREEN)
    yabc=(yab+y["C"])/2
    ax.plot([root_x,abc_x],[yabc,yabc],color=ORANGE,lw=2)
    ax.plot([root_x,leaf_x["D"]],[y["D"],y["D"]],color=ORANGE)
    ax.plot([root_x,root_x],[y["D"],yabc],color=ORANGE)
    ax.text(ab_x,3.55,f"AB: altura {UPGMA['h_ab']:.1f}".replace(".",","),ha="center",fontsize=9)
    ax.text(abc_x,2.05,f"ABC: altura {UPGMA['h_abc']:.2f}".replace(".",","),ha="center",fontsize=9)
    ax.text(root_x+.15,1.1,f"raíz: altura {UPGMA['h_root']:.1f}".replace(".",","),ha="left",fontsize=9)
    ax.set_xlim(0,17); ax.set_ylim(.2,3.9); ax.set_xlabel("altura ultramétrica acumulada"); ax.set_yticks([])
    ax.spines[["left","right","top"]].set_visible(False); ax.grid(axis="x",alpha=.2)
    save(fig, "F06")


def double_factorial(value):
    result=1
    for factor in range(value,0,-2): result*=factor
    return result


def f07():
    fig, ax = plt.subplots(figsize=(7.2,4.3))
    ns=list(range(4,31)); logs=[math.log10(double_factorial(2*n-5)) for n in ns]
    ax.plot(ns,logs,color=BLUE,lw=2); ax.scatter([4,10],[logs[0],logs[6]],color=ORANGE,zorder=3)
    ax.annotate("4 taxones: 3",(4,logs[0]),xytext=(7,2),arrowprops={"arrowstyle":"->"})
    ax.annotate("10 taxones: 2.027.025",(10,logs[6]),xytext=(13,5),arrowprops={"arrowstyle":"->"})
    ax.set(xlabel="Número de taxones",ylabel="log10 del número de topologías no enraizadas",title="El espacio de árboles crece de forma combinatoria")
    ax.grid(alpha=.2)
    save(fig, "F07")


def f08():
    fig, ax = plt.subplots(figsize=(7.2,4.2)); ax.axis("off")
    columns=["1","2","3","4","5","6","7","8"]
    ax.text(.08,.87,"MSA original",weight="bold",color=BLUE)
    for i,c in enumerate(columns): ax.text(.08+i*.055,.72,c,ha="center",family="monospace")
    for row,(rep,outcome) in enumerate(zip(BOOTSTRAP_REPLICATES,BOOTSTRAP_OUTCOMES)):
        yy=.53-row*.12
        ax.text(.02,yy,f"R{row+1}",fontsize=9)
        for i,c in enumerate(rep): ax.text(.08+i*.055,yy,str(c),ha="center",family="monospace",fontsize=9)
        ax.text(.58,yy,"→ árbol →",fontsize=9)
        ax.text(.76,yy,f"clado {outcome}",fontsize=9,color=GREEN if outcome=="AB" else ORANGE)
    ax.text(.76,.08,"AB aparece en 3 de 4 réplicas: 75 %",ha="center",weight="bold")
    ax.text(.33,.08,"Misma longitud; columnas muestreadas\ncon reemplazo",ha="center",fontsize=9.5,color=GRAY)
    save(fig, "F08")


def f09():
    fig, axes=plt.subplots(1,2,figsize=(7.2,4.4))
    def scaled_tree(ax, pairs, title):
        root=(.05,.5); upper=(.30,.72); lower=(.30,.28)
        edge(ax,root,upper); edge(ax,root,lower)
        ys=(.88,.62,.38,.12)
        for node,(taxon,length_class),yy in zip((upper,upper,lower,lower),pairs,ys):
            length = LBA[f"{length_class}_length"]
            x = LBA["node_x"] + length
            edge(ax,node,(x,yy),width=2.2 if length_class=="long" else 1.5)
            label_text = "larga" if length_class == "long" else "corta"
            ax.text(x+.02,yy,f"{taxon} ({label_text})",va="center",fontsize=9)
        ax.set_title(title,fontsize=10); ax.set_xlim(0,1.05);ax.set_ylim(0,1);ax.axis("off")
    scaled_tree(axes[0],LBA["generating_order"],"Historia: A y D separados")
    scaled_tree(axes[1],LBA["attracted_order"],"Error: homoplasias agrupan A y D")
    fig.suptitle("Atracción de ramas largas: la longitud es una magnitud, no una etiqueta",fontsize=11,color=BLUE)
    fig.text(.5,.055,"Escala del esquema: rama corta = 1 unidad; rama larga = 3 unidades",ha="center",fontsize=9.5,color=GRAY)
    fig.tight_layout(rect=(0,.12,1,.88))
    save(fig, "F09")


def f10():
    fig, axes=plt.subplots(1,2,figsize=(7.2,4.8))
    ax=axes[0]; tree_panel(ax,[f"especie {species}" for species in SPECIES_TREE_ORDER],"Árbol de especies")
    ax=axes[1]
    root=(.05,.5); dup=(.18,.5)
    edge(ax,root,dup,color=GRAY); ax.scatter(*dup,color=ORANGE,s=30,zorder=3)
    upper=(.31,.72); lower=(.31,.28); edge(ax,dup,upper,color=BLUE); edge(ax,dup,lower,color=GREEN)
    tips_alpha=[(.82,.94),(.82,.82),(.82,.70),(.82,.58)]
    tips_beta=[(.82,.42),(.82,.30),(.82,.18),(.82,.06)]
    for origin,tips,color in ((upper,tips_alpha,BLUE),(lower,tips_beta,GREEN)):
        mid1=(.52,(tips[0][1]+tips[1][1])/2); mid2=(.52,(tips[2][1]+tips[3][1])/2)
        edge(ax,origin,mid1,color=color); edge(ax,origin,mid2,color=color)
        for mid,tip in ((mid1,tips[0]),(mid1,tips[1]),(mid2,tips[2]),(mid2,tips[3])): edge(ax,mid,tip,color=color)
    labels=list(GENE_COPY_GROUPS["alpha"] + GENE_COPY_GROUPS["beta"])
    for point,textv in zip(tips_alpha+tips_beta,labels): label(ax,point,textv,dx=.015)
    ax.text(.20,.48,"duplicación anterior\na las especiaciones",ha="center",va="top",fontsize=8.5,color=ORANGE)
    ax.set_title("Árbol génico: dos copias por especie",fontsize=10); ax.set_xlim(0,1.28);ax.set_ylim(0,1);ax.axis("off")
    fig.suptitle("La historia de un gen no se identifica automáticamente con la historia de las especies",fontsize=11,color=BLUE)
    fig.tight_layout(rect=(0,0,1,.92))
    save(fig, "F10")


FIGURES={"F01":f01,"F02":f02,"F03":f03,"F04":f04,"F05":f05,"F06":f06,"F07":f07,"F08":f08,"F09":f09,"F10":f10}


def semantic_check(name: str) -> None:
    """Oráculos de contenido; generar un PDF no basta para aprobar una figura."""
    if name == "F01":
        expected = {frozenset(group) for group in ROOTED_SPLIT}
        assert all({frozenset(order[:2]), frozenset(order[2:])} == expected for order in TREE_ROTATIONS)
    elif name == "F02":
        assert {frozenset(group) for group in ROOTED_SPLIT} == set(UNROOTED_SPLIT)
        assert set().union(*map(set, ROOTED_SPLIT)) == set("ABCD")
    elif name == "F03":
        for msa in (MSA_1, MSA_2):
            assert len({len(sequence) for sequence in msa.values()}) == 1
            assert {name_: sequence.replace("-", "") for name_, sequence in msa.items()} == RAW_MSA
        columns_1 = tuple(zip(*MSA_1.values()))
        columns_2 = tuple(zip(*MSA_2.values()))
        assert columns_1 != columns_2
    elif name == "F04":
        assert tuple(head for head, _ in CHAIN_STAGES) == ("Pregunta", "Secuencias", "MSA", "Modelo", "Búsqueda", "Apoyo", "Afirmación")
        assert CHAIN_EDGES == tuple((index, index + 1) for index in range(6))
    elif name == "F05":
        assert math.isclose(-.75 * math.log(1 - 4 * .1 / 3), .1073256327, rel_tol=0, abs_tol=1e-9)
    elif name == "F06":
        assert set(UPGMA_DRAW["leaf_x"]) == set("ABCD")
        assert set(UPGMA_DRAW["leaf_x"].values()) == {UPGMA["h_root"]}
        assert math.isclose(UPGMA_DRAW["ab_x"], 7.0)
        assert math.isclose(UPGMA_DRAW["abc_x"], 2.75)
    elif name == "F07":
        assert all(double_factorial(2 * n - 5) == count for n, count in TREE_COUNT_ANCHORS.items())
    elif name == "F08":
        assert all(len(rep) == 8 and all(1 <= index <= 8 for index in rep) for rep in BOOTSTRAP_REPLICATES)
        assert any(len(set(rep)) < 8 for rep in BOOTSTRAP_REPLICATES)
        assert BOOTSTRAP_OUTCOMES.count("AB") == 3
    elif name == "F09":
        generating = dict(LBA["generating_order"])
        attracted = dict(LBA["attracted_order"])
        assert set(generating) == set(attracted) == set("ABCD")
        assert generating["A"] == generating["D"] == "long"
        assert attracted["A"] == attracted["D"] == "long"
        assert math.isclose(LBA["long_length"] / LBA["short_length"], 3.0)
    elif name == "F10":
        gene_species = {label.split(":")[0] for group in GENE_COPY_GROUPS.values() for label in group}
        assert set(SPECIES) == gene_species
        assert set(GENE_COPY_GROUPS) == {"alpha", "beta"}
        assert all(len(group) == len(SPECIES) for group in GENE_COPY_GROUPS.values())
        assert len(set(GENE_COPY_GROUPS["alpha"] + GENE_COPY_GROUPS["beta"])) == 2 * len(SPECIES)


def main():
    parser=argparse.ArgumentParser(); parser.add_argument("--all",action="store_true"); parser.add_argument("--check",choices=FIGURES)
    args=parser.parse_args()
    if args.all:
        for name, function in FIGURES.items():
            semantic_check(name)
            function()
        print(f"FIGURES_OK={len(FIGURES)}")
    elif args.check:
        semantic_check(args.check)
        FIGURES[args.check]()
        path=OUT/f"BC09-{args.check}.pdf"
        if not path.is_file() or path.stat().st_size < 1000: raise SystemExit(f"figura ausente o vacía: {path}")
        print(f"{args.check}_OK")
    else:
        parser.error("use --all o --check")


if __name__ == "__main__": main()
