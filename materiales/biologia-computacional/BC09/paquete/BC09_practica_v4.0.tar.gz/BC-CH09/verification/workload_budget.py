#!/usr/bin/env python3
"""Presupuesto analítico y reproducible para la ruta esencial de BC-CH09.

No simula comprensión humana. Cuenta la prosa marcada como esencial y los
anclajes manuales/ejecutables del manuscrito; aplica rangos conservadores
declarados para planificación. Un ensayo con estudiantes validará después el
modelo sin convertir una estimación no medida en hecho.
"""

from __future__ import annotations

import re
from pathlib import Path


THEORY = Path(__file__).resolve().parents[1] / "theory.tex"
READING_WPM = (110, 140)  # lectura técnica: supuesto de planificación
MANUAL_MINUTES = (12, 18)  # por cálculo ancla, incluida comprobación
EXECUTION_MINUTES = (10, 15)  # por listado esencial, incluida interpretación
CONSOLIDATION_MINUTES = (45, 60)  # síntesis y recuperación espaciada inicial


def visible_words(text: str) -> list[str]:
    text = re.sub(r"%.*", " ", text)
    text = re.sub(r"\\(?:cite|ref|label)\{[^}]*\}", " ", text)
    text = re.sub(r"\\[A-Za-z]+\*?(?:\[[^]]*\])?", " ", text)
    text = re.sub(r"[{}$&_~^\\]", " ", text)
    return re.findall(r"[A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9]+(?:[-–][A-Za-zÁÉÍÓÚÜÑáéíóúüñ0-9]+)*", text)


def population() -> tuple[int, int, int]:
    route = None
    essential_lines: list[str] = []
    manual = 0
    listings = 0
    inside_listing = False
    for line in THEORY.read_text(encoding="utf-8").splitlines():
        if "\\RouteEssential" in line:
            route = "essential"
        elif "\\RouteStudy" in line:
            route = "study"
        elif "\\RouteReference" in line:
            route = "reference"
        if "% LOAD-MANUAL:" in line and route == "essential":
            manual += 1
        if "\\begin{lstlisting}" in line:
            inside_listing = True
            if route == "essential":
                listings += 1
        if route == "essential" and not inside_listing:
            essential_lines.append(line)
        if "\\end{lstlisting}" in line:
            inside_listing = False
    return len(visible_words("\n".join(essential_lines))), manual, listings


def main() -> None:
    words, manual, listings = population()
    reading_low = words / READING_WPM[1]
    reading_high = words / READING_WPM[0]
    low = reading_low + manual * MANUAL_MINUTES[0] + listings * EXECUTION_MINUTES[0] + CONSOLIDATION_MINUTES[0]
    high = reading_high + manual * MANUAL_MINUTES[1] + listings * EXECUTION_MINUTES[1] + CONSOLIDATION_MINUTES[1]
    print(
        f"essential_words={words} manual_anchors={manual} essential_listings={listings} "
        f"reading_wpm={READING_WPM[0]}-{READING_WPM[1]} "
        f"budget_minutes={round(low)}-{round(high)}"
    )


if __name__ == "__main__":
    main()
