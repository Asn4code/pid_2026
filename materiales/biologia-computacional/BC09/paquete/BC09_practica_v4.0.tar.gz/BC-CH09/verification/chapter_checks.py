#!/usr/bin/env python3
"""Comprobaciones pequeñas y deterministas para los ejemplos de BC-CH09.

Cada subcomando imprime una única salida estable para que la fábrica pueda
compararla con el valor publicado. No requiere bibliotecas externas.
"""

from __future__ import annotations

import argparse
import ast
import csv
import hashlib
import math
from pathlib import Path
import sys

from fixtures import (
    BOOTSTRAP_OUTCOMES,
    BOOTSTRAP_REPLICATES,
    DISTANCE_MATRIX,
    GAP_POLICY_ALIGNMENT,
    HEURISTIC_LANDSCAPE,
    INPUT_RECORDS,
    MODEL_SELECTION_CANDIDATES,
    MODEL_SELECTION_EXAMPLE,
    PIPELINE_TAXA,
    PRUNING_EXAMPLE,
    PROGRESSIVE_GUIDE_PLAN,
    UPGMA,
    UPGMA_COPHENETIC,
)


SNAPSHOT = Path(__file__).resolve().parent / "snapshots" / "iqtree_command_reference_2025-06-05.tsv"
SNAPSHOT_SHA256 = "b18780ee1b32845edafd957388518d1c2f7a967101889c3ab91b02ed95f3fc90"


def iqtree_snapshot() -> dict[tuple[str, str], tuple[str, str]]:
    payload = SNAPSHOT.read_bytes()
    observed = hashlib.sha256(payload).hexdigest()
    if observed != SNAPSHOT_SHA256:
        raise RuntimeError(f"instantánea IQ-TREE divergente: {observed}")
    lines = [line for line in payload.decode("utf-8").splitlines() if not line.startswith("#")]
    rows = csv.DictReader(lines, delimiter="\t")
    parsed = {
        (row["option"], row["value"]): (row["section"], row["operation"])
        for row in rows
    }
    if len(parsed) != 5:
        raise RuntimeError("la instantánea IQ-TREE debe contener cinco filas únicas")
    return parsed


def jc69(p: float) -> float:
    if not 0.0 <= p < 0.75:
        raise ValueError("JC69 exige 0 <= p < 0.75 para una distancia real finita")
    return -0.75 * math.log(1.0 - 4.0 * p / 3.0)


def k2p(p_transiciones: float, q_transversiones: float) -> float:
    if p_transiciones < 0.0 or q_transversiones < 0.0 or p_transiciones + q_transversiones > 1.0:
        raise ValueError("P y Q deben ser proporciones no negativas y P+Q <= 1")
    a = 1.0 - 2.0 * p_transiciones - q_transversiones
    b = 1.0 - 2.0 * q_transversiones
    if a <= 0.0 or b <= 0.0:
        raise ValueError("P y Q quedan fuera del dominio real de K2P")
    return -0.5 * math.log(a) - 0.25 * math.log(b)


def p_distance(seq1: str, seq2: str) -> float:
    """Proporción de discordancias en dos secuencias alineadas no vacías."""
    if len(seq1) != len(seq2):
        raise ValueError("las secuencias alineadas deben tener igual longitud")
    if not seq1:
        raise ValueError("el alineamiento no puede estar vacío")
    return sum(left != right for left, right in zip(seq1, seq2)) / len(seq1)


def mismatches(seq1: str, seq2: str) -> tuple[int, int, int]:
    if len(seq1) != len(seq2):
        raise ValueError("las secuencias alineadas deben tener igual longitud")
    transitions = {("A", "G"), ("G", "A"), ("C", "T"), ("T", "C")}
    total = ts = tv = 0
    for left, right in zip(seq1, seq2):
        if left == right:
            continue
        total += 1
        if (left, right) in transitions:
            ts += 1
        else:
            tv += 1
    return total, ts, tv


def nj_q_matrix(matrix: dict[str, dict[str, float]]) -> dict[tuple[str, str], float]:
    taxa = sorted(matrix)
    if len(taxa) < 3:
        raise ValueError("NJ requiere al menos tres taxones")
    if any(set(matrix[taxon]) != set(taxa) for taxon in taxa):
        raise ValueError("la matriz NJ debe ser cuadrada y mantener las etiquetas")
    if any(matrix[a][b] != matrix[b][a] for a in taxa for b in taxa):
        raise ValueError("la matriz NJ debe ser simétrica")
    n = len(taxa)
    sums = {a: sum(matrix[a][b] for b in taxa) for a in taxa}
    return {
        (a, b): (n - 2) * matrix[a][b] - sums[a] - sums[b]
        for i, a in enumerate(taxa)
        for b in taxa[i + 1 :]
    }


def cophenetic_residuals() -> dict[str, float]:
    """Residuo cophenético menos distancia de entrada para el ejemplo UPGMA."""
    cophenetic = UPGMA_COPHENETIC
    observed = {"AB": 17.0, "AC": 21.0, "BC": 30.0, "AD": 31.0, "BD": 34.0, "CD": 28.0}
    return {pair: cophenetic[pair] - observed[pair] for pair in observed}


def ultrametric_violations(matrix: dict[str, dict[str, float]]) -> int:
    taxa = sorted(matrix)
    violations = 0
    for i, a in enumerate(taxa):
        for j, b in enumerate(taxa[i + 1 :], start=i + 1):
            for c in taxa[j + 1 :]:
                values = sorted((matrix[a][b], matrix[a][c], matrix[b][c]))
                violations += values[1] != values[2]
    return violations


def double_factorial(value: int) -> int:
    result = 1
    for factor in range(value, 0, -2):
        result *= factor
    return result


def fitch_score(pattern: dict[str, str], split: tuple[tuple[str, str], tuple[str, str]]) -> int:
    score = 0
    internal = []
    for pair in split:
        left = {pattern[pair[0]]}
        right = {pattern[pair[1]]}
        common = left & right
        if common:
            internal.append(common)
        else:
            internal.append(left | right)
            score += 1
    common = internal[0] & internal[1]
    if not common:
        score += 1
    return score


def upgma_trace() -> tuple[float, float, float, float, float]:
    ab_height = 17.0 / 2.0
    ab_c = (21.0 + 30.0) / 2.0
    ab_d = (31.0 + 34.0) / 2.0
    abc_height = ab_c / 2.0
    abc_d = (2.0 * ab_d + 1.0 * 28.0) / 3.0
    root_height = abc_d / 2.0
    assert (ab_height, ab_c, ab_d, abc_height, abc_d, root_height) == (
        UPGMA["h_ab"], UPGMA["d_ab_c"], UPGMA["d_ab_d"],
        UPGMA["h_abc"], UPGMA["d_abc_d"], UPGMA["h_root"],
    )
    return ab_height, ab_c, ab_d, abc_height, root_height


def greedy_search(start: str) -> tuple[str, int]:
    """Ascenso estricto sobre el paisaje mínimo declarado en fixtures."""
    current = start
    while True:
        better = [
            neighbor for neighbor in HEURISTIC_LANDSCAPE[current]["neighbors"]
            if HEURISTIC_LANDSCAPE[neighbor]["score"] > HEURISTIC_LANDSCAPE[current]["score"]
        ]
        if not better:
            return current, HEURISTIC_LANDSCAPE[current]["score"]
        current = max(better, key=lambda node: HEURISTIC_LANDSCAPE[node]["score"])


def information_criteria(log_likelihood: float, parameters: int, sites: int) -> tuple[float, float, float]:
    if parameters < 0 or sites <= parameters + 1:
        raise ValueError("AICc exige n > k + 1 y un número no negativo de parámetros")
    aic = -2.0 * log_likelihood + 2.0 * parameters
    aicc = aic + 2.0 * parameters * (parameters + 1.0) / (sites - parameters - 1.0)
    bic = -2.0 * log_likelihood + parameters * math.log(sites)
    return aic, aicc, bic


def best_candidate(scores: dict[str, float]) -> str:
    if not scores:
        raise ValueError("se necesita al menos un modelo candidato")
    return min(scores, key=scores.__getitem__)


def validate_input_records(records: tuple[dict[str, str], ...], expected_molecule: str) -> None:
    required = {"label", "organism", "accession", "version", "molecule", "sequence", "source"}
    allowed = required | {"reuse_justification"}
    labels = [record["label"] for record in records]
    if len(labels) != len(set(labels)):
        raise ValueError("las etiquetas deben ser únicas")
    valid = set("ACDEFGHIKLMNPQRSTVWY") if expected_molecule == "protein" else set("ACGT")
    for record in records:
        if not required <= set(record) <= allowed or any(not record[field] for field in required):
            raise ValueError("cada registro necesita metadatos completos")
        if record["molecule"] != expected_molecule:
            raise ValueError("tipo molecular inesperado")
        if not set(record["sequence"]) <= valid:
            raise ValueError("carácter inválido para el tipo molecular")
    accession_organisms: dict[str, set[str]] = {}
    for record in records:
        accession_organisms.setdefault(record["accession"], set()).add(record["organism"])
    for accession, organisms in accession_organisms.items():
        if len(organisms) > 1 and not all(
            record.get("reuse_justification")
            for record in records
            if record["accession"] == accession
        ):
            raise ValueError("una accesión reutilizada entre organismos exige justificación")


def rejection_observed(records: tuple[dict[str, str], ...], expected_molecule: str) -> bool:
    try:
        validate_input_records(records, expected_molecule)
    except ValueError:
        return True
    return False


def pruning_likelihood() -> tuple[float, float]:
    """Caso binario: poda postorden frente a enumeración de estados internos."""
    data = PRUNING_EXAMPLE
    states = data["states"]
    prior = data["prior"]
    transition = data["transition"]
    tips = data["tips"]

    def cherry_partial(left_tip: str, right_tip: str) -> dict[int, float]:
        return {
            parent: transition[parent][tips[left_tip]] * transition[parent][tips[right_tip]]
            for parent in states
        }

    left = cherry_partial("A", "B")
    right = cherry_partial("C", "D")
    pruned = 0.0
    for root in states:
        left_sum = sum(transition[root][internal] * left[internal] for internal in states)
        right_sum = sum(transition[root][internal] * right[internal] for internal in states)
        pruned += prior[root] * left_sum * right_sum

    brute_force = sum(
        prior[root]
        * transition[root][left_internal]
        * transition[left_internal][tips["A"]]
        * transition[left_internal][tips["B"]]
        * transition[root][right_internal]
        * transition[right_internal][tips["C"]]
        * transition[right_internal][tips["D"]]
        for root in states
        for left_internal in states
        for right_internal in states
    )
    return pruned, brute_force


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "check",
        choices=(
            "toy_mismatches",
            "p_distance_formula",
            "p_distance_cases",
            "jc69",
            "jc69_domain",
            "k2p",
            "k2p_domain",
            "upgma_trace",
            "upgma_diagnostics",
            "upgma_newick",
            "nj_q",
            "topology_counts",
            "parsimony",
            "bootstrap",
            "matrix_invariants",
            "optional_command",
            "clade_compare",
            "tree_scope_compare",
            "progressive_alignment_trace",
            "gap_policies",
            "substitution_classes",
            "heuristic_search",
            "iqtree_semantics",
            "information_criteria",
            "likelihood_pruning",
            "bootstrap_monte_carlo",
            "model_candidate_scope",
            "input_controls",
            "python_constructs",
            "runtime_contract",
            "accessibility_source_contract",
            "log_likelihood_order",
        ),
    )
    args = parser.parse_args()

    if args.check == "toy_mismatches":
        seq1 = "ACGTACGTACGTACGTACGT"
        seq2 = "ACGTACGGACGTACGGACGT"
        total, ts, tv = mismatches(seq1, seq2)
        positions = [
            f"{index}:{left}>{right}"
            for index, (left, right) in enumerate(zip(seq1, seq2), start=1)
            if left != right
        ]
        print(
            f"positions={','.join(positions)} differences={total} "
            f"P={ts/20:.2f} Q={tv/20:.2f} p={total/20:.2f}"
        )
    elif args.check == "p_distance_formula":
        print(f"m=2 L=20 p={2/20:.2f}")
    elif args.check == "p_distance_cases":
        normal = p_distance("ACGT", "AGGT")
        try:
            p_distance("AC", "A")
        except ValueError:
            unequal_rejected = True
        else:
            unequal_rejected = False
        try:
            p_distance("", "")
        except ValueError:
            empty_rejected = True
        else:
            empty_rejected = False
        print(
            f"normal={normal:.2f} unequal_rejected={unequal_rejected} "
            f"empty_rejected={empty_rejected}"
        )
    elif args.check == "jc69":
        print(f"{jc69(0.1):.6f}")
    elif args.check == "jc69_domain":
        finite = math.isfinite(jc69(0.749))
        try:
            jc69(0.75)
        except ValueError:
            rejected = True
        else:
            rejected = False
        print(f"p0.749_finite={finite} p0.750_rejected={rejected}")
    elif args.check == "k2p":
        print(f"{k2p(0.08, 0.02):.6f}")
    elif args.check == "k2p_domain":
        valid = math.isfinite(k2p(0.08, 0.02))
        rejected = []
        for p_value, q_value in ((-0.01, 0.02), (0.50, 0.0), (0.0, 0.50), (0.80, 0.30)):
            try:
                k2p(p_value, q_value)
            except ValueError:
                rejected.append(True)
            else:
                rejected.append(False)
        print(f"valid_finite={valid} invalid_rejected={all(rejected)} cases={len(rejected)}")
    elif args.check == "upgma_trace":
        h_ab, ab_c, ab_d, h_abc, h_root = upgma_trace()
        print(
            f"hAB={h_ab:.2f} dAB_C={ab_c:.2f} dAB_D={ab_d:.2f} "
            f"hABC={h_abc:.2f} dABC_D={2*h_root:.2f} hroot={h_root:.2f}"
        )
    elif args.check == "upgma_diagnostics":
        residuals = cophenetic_residuals()
        compact = ",".join(f"{pair}:{value:+.1f}" for pair, value in residuals.items())
        print(f"ultrametric_violations={ultrametric_violations(DISTANCE_MATRIX)} residuals={compact}")
    elif args.check == "upgma_newick":
        newick = "(((A:8.5,B:8.5):4.25,C:12.75):2.75,D:15.5);"
        root_distances = {
            "A": 2.75 + 4.25 + 8.5,
            "B": 2.75 + 4.25 + 8.5,
            "C": 2.75 + 12.75,
            "D": 15.5,
        }
        print(f"order=AB-C-D tips={','.join(sorted(root_distances))} root_distance={min(root_distances.values()):.1f} equal={len(set(root_distances.values())) == 1} newick_ok={newick.endswith(';')}")
    elif args.check == "nj_q":
        q_values = nj_q_matrix(DISTANCE_MATRIX)
        minimum = min(q_values.values())
        pairs = ",".join("".join(pair) for pair, value in q_values.items() if value == minimum)
        print(f"minQ={minimum:.0f} pairs={pairs}")
    elif args.check == "topology_counts":
        counts = [double_factorial(2 * n - 5) for n in (4, 10, 80)]
        print(f"n4={counts[0]} n10={counts[1]} log10n80={math.log10(counts[2]):.3f}")
    elif args.check == "parsimony":
        trees = (("A", "B"), ("C", "D")), (("A", "C"), ("B", "D")), (("A", "D"), ("B", "C"))
        singleton = {"A": "G", "B": "A", "C": "A", "D": "A"}
        informative = {"A": "A", "B": "A", "C": "G", "D": "G"}
        s1 = [fitch_score(singleton, tree) for tree in trees]
        s2 = [fitch_score(informative, tree) for tree in trees]
        print(f"singleton={','.join(map(str, s1))} informative={','.join(map(str, s2))}")
    elif args.check == "bootstrap":
        population = tuple(range(1, 9))
        lengths_ok = all(len(rep) == len(population) for rep in BOOTSTRAP_REPLICATES)
        indices_ok = all(index in population for rep in BOOTSTRAP_REPLICATES for index in rep)
        replacement_visible = any(len(set(rep)) < len(rep) for rep in BOOTSTRAP_REPLICATES)
        support = 100 * BOOTSTRAP_OUTCOMES.count("AB") / len(BOOTSTRAP_OUTCOMES)
        print(
            f"lengths_ok={lengths_ok} indices_ok={indices_ok} "
            f"replacement_visible={replacement_visible} AB_support={support:.1f}"
        )
    elif args.check == "matrix_invariants":
        matrix = DISTANCE_MATRIX
        taxa = sorted(matrix)
        symmetric = all(matrix[a][b] == matrix[b][a] for a in taxa for b in taxa)
        zero_diagonal = all(matrix[a][a] == 0 for a in taxa)
        nonnegative = all(matrix[a][b] >= 0 for a in taxa for b in taxa)
        print(f"taxa={len(taxa)} symmetric={symmetric} diagonal0={zero_diagonal} nonnegative={nonnegative}")
    elif args.check == "optional_command":
        command = ["iqtree3", "-s", "alignment.fasta", "-m", "MFP", "-B", "1000", "--seed", "20260805"]
        print(" ".join(command))
    elif args.check == "clade_compare":
        raw = {frozenset(("A", "B")), frozenset(("A", "B", "C"))}
        trimmed = {frozenset(("A", "B")), frozenset(("A", "B", "D"))}
        shared = raw & trimmed
        only_raw = raw - trimmed
        only_trimmed = trimmed - raw
        encode = lambda groups: ";".join("".join(sorted(group)) for group in sorted(groups, key=lambda item: tuple(sorted(item))))
        print(f"shared={encode(shared)} raw_only={encode(only_raw)} trimmed_only={encode(only_trimmed)}")
    elif args.check == "tree_scope_compare":
        first = {
            "clades": {frozenset(("A", "B"))},
            "outgroup": "D",
            "terminal_lengths": {"A": 0.10, "B": 0.10, "C": 0.20, "D": 0.30},
        }
        second = {
            "clades": {frozenset(("A", "B"))},
            "outgroup": "C",
            "terminal_lengths": {"A": 0.15, "B": 0.12, "C": 0.25, "D": 0.22},
        }
        shared = first["clades"] & second["clades"]
        lengths_equal = first["terminal_lengths"] == second["terminal_lengths"]
        outgroup_equal = first["outgroup"] == second["outgroup"]
        assert shared == {frozenset(("A", "B"))} and not lengths_equal and not outgroup_equal
        print("shared=AB terminal_lengths_equal=False outgroup_equal=False dimensions_separate=True")
    elif args.check == "progressive_alignment_trace":
        available = {"A", "B", "C"}
        trace = []
        for left, right, merged in PROGRESSIVE_GUIDE_PLAN:
            assert left in available and right in available
            available.add(merged)
            trace.append(f"{left}+{right}->{merged}")
        assert PROGRESSIVE_GUIDE_PLAN[1][0] == PROGRESSIVE_GUIDE_PLAN[0][2]
        print(f"steps={';'.join(trace)} final=ABC early_output_reused=True")
    elif args.check == "gap_policies":
        alignment = GAP_POLICY_ALIGNMENT
        taxa = tuple(alignment)
        assert len({len(sequence) for sequence in alignment.values()}) == 1
        pair_ab = sum(
            alignment["A"][index] != "-" and alignment["B"][index] != "-"
            for index in range(len(alignment["A"]))
        )
        complete = sum(
            all(alignment[taxon][index] != "-" for taxon in taxa)
            for index in range(len(alignment["A"]))
        )
        print(f"columns=5 pairwise_AB={pair_ab} complete={complete} differ={pair_ab != complete}")
    elif args.check == "substitution_classes":
        bases = "ACGT"
        transitions = {("A", "G"), ("G", "A"), ("C", "T"), ("T", "C")}
        directed_changes = {(left, right) for left in bases for right in bases if left != right}
        transversions = directed_changes - transitions
        assert len(directed_changes) == 12 and len(transitions) == 4 and len(transversions) == 8
        print("directed_changes=12 transitions=4 transversions=8 partition=True")
    elif args.check == "heuristic_search":
        local_node, local_score = greedy_search("T0")
        global_node, global_score = greedy_search("T2")
        assert (local_node, local_score) == ("T1", 7)
        assert (global_node, global_score) == ("T3", 9)
        print("start_T0=T1:7 start_T2=T3:9 local_below_global=True")
    elif args.check == "iqtree_semantics":
        semantics = iqtree_snapshot()
        assert semantics[("-n", "0")][1] == "skip subsequent tree search"
        assert semantics[("-t", "BIONJ")][1] == "start tree reconstruction from BIONJ tree"
        assert semantics[("-m", "MF")][1].endswith("without tree reconstruction")
        assert semantics[("-m", "MFP")][1].endswith("followed by tree reconstruction")
        assert semantics[("-merit", "AIC|AICc|BIC")][0] == "Automatic model selection"
        print(
            f"snapshot_sha256={SNAPSHOT_SHA256} rows={len(semantics)} "
            "n0=skip_search BIONJ=start_tree MF=select MFP=select+tree merits=AIC|AICc|BIC"
        )
    elif args.check == "information_criteria":
        example = MODEL_SELECTION_EXAMPLE
        aic, aicc, bic = information_criteria(
            example["log_likelihood"], example["parameters"], example["sites"]
        )
        assert math.isclose(aic, 250.0)
        assert math.isclose(aicc, 250.63829787234042)
        assert math.isclose(bic, 263.0258509299405)
        print(f"AIC={aic:.3f} AICc={aicc:.3f} BIC={bic:.3f} distinct=True")
    elif args.check == "likelihood_pruning":
        pruned, brute_force = pruning_likelihood()
        assert math.isclose(pruned, brute_force, rel_tol=0, abs_tol=1e-15)
        print(f"pruned={pruned:.6f} brute_force={brute_force:.6f} equal=True")
    elif args.check == "bootstrap_monte_carlo":
        probability = 0.75
        se_100 = math.sqrt(probability * (1.0 - probability) / 100)
        se_1000 = math.sqrt(probability * (1.0 - probability) / 1000)
        assert se_1000 < se_100 and math.isclose(se_100 / se_1000, math.sqrt(10.0))
        print(f"p=0.75 SE_B100={se_100:.6f} SE_B1000={se_1000:.6f} decreases=True")
    elif args.check == "model_candidate_scope":
        case = MODEL_SELECTION_CANDIDATES
        restricted = best_candidate(case["restricted_scores"])
        expanded = best_candidate(case["expanded_scores"])
        generating = case["generating_model"]
        assert generating not in case["restricted_scores"] and restricted != generating
        assert generating in case["expanded_scores"] and expanded == generating
        print(
            f"restricted={restricted} generating_present=False expanded={expanded} "
            "generating_present=True exclusion_blocks_selection=True"
        )
    elif args.check == "input_controls":
        records = INPUT_RECORDS
        validate_input_records(records, "protein")
        duplicate = (records[0], {**records[1], "label": records[0]["label"]})
        wrong_type = (records[0], {**records[1], "molecule": "dna"})
        invalid_character = (records[0], {**records[1], "sequence": "MRTW?"})
        reused_accession = (records[0], {**records[1], "accession": records[0]["accession"]})
        empty_sequence = (records[0], {**records[1], "sequence": ""})
        lengths = [len(record["sequence"]) for record in records]
        taxa_equal = len({frozenset(value) for value in PIPELINE_TAXA.values()}) == 1
        assert taxa_equal
        print(
            f"records={len(records)} metadata_complete=True labels_unique=True type=protein alphabet_valid=True "
            f"length_min={min(lengths)} length_max={max(lengths)} "
            f"duplicate_rejected={rejection_observed(duplicate, 'protein')} "
            f"wrong_type_rejected={rejection_observed(wrong_type, 'protein')} "
            f"invalid_rejected={rejection_observed(invalid_character, 'protein')} "
            f"accession_reuse_rejected={rejection_observed(reused_accession, 'protein')} "
            f"empty_rejected={rejection_observed(empty_sequence, 'protein')} taxa_equal={taxa_equal}"
        )
    elif args.check == "python_constructs":
        ordered = ["A", "B", "A"]
        mapping = {"A": 1, "B": 2}
        unique = set(ordered)

        def positive_total(values: list[int]) -> int:
            total = 0
            for value in values:
                if value < 0:
                    raise ValueError("solo valores no negativos")
                total += value
            return total

        negative_rejected = False
        try:
            positive_total([1, -1])
        except ValueError:
            negative_rejected = True
        assert ordered == ["A", "B", "A"] and mapping["B"] == 2 and unique == {"A", "B"}
        assert positive_total([1, 2, 3]) == 6 and negative_rejected
        print(
            "list_order_and_duplicates=True dict_key_lookup=2 set_unique=2 "
            "function_result=6 if_for_raise=True assert_reached=True"
        )
    elif args.check == "runtime_contract":
        version_ok = sys.version_info >= (3, 9)
        tree = ast.parse(Path(__file__).read_text(encoding="utf-8"))
        imports = {
            alias.name.split(".")[0]
            for node in tree.body if isinstance(node, ast.Import)
            for alias in node.names
        }
        imports.update(
            node.module.split(".")[0]
            for node in tree.body if isinstance(node, ast.ImportFrom) and node.module
        )
        standard_or_local_only = imports <= {
            "__future__", "argparse", "ast", "csv", "hashlib", "math", "pathlib", "sys", "fixtures"
        }
        assert version_ok and standard_or_local_only
        print(
            f"python={sys.version_info.major}.{sys.version_info.minor} minimum_3_9=True "
            "syntax_ast=True imports_standard_or_local=True target=chapter_checks.py"
        )
    elif args.check == "accessibility_source_contract":
        theory = (Path(__file__).resolve().parents[1] / "theory.tex").read_text(encoding="utf-8")
        actual_text = "/ActualText" in theory
        visible_alternative = "Descripción alternativa." in theory
        marked_catalog_absent = "/MarkInfo" not in theory
        pdfua_not_claimed = "/Marked true ni se presenta esta capa como validación PDF/UA" in theory
        assert actual_text and visible_alternative and marked_catalog_absent and pdfua_not_claimed
        print(
            "actualtext_source=True visible_alternative_source=True "
            "marked_catalog_absent=True pdfua_not_claimed=True"
        )
    elif args.check == "log_likelihood_order":
        first = -1200.0
        second = -1250.0
        likelihood_ratio = math.exp(first - second)
        assert first > second and likelihood_ratio > 1.0
        print(f"lnL1={first:.0f} lnL2={second:.0f} first_greater=True likelihood_ratio=exp(50)")


if __name__ == "__main__":
    main()
