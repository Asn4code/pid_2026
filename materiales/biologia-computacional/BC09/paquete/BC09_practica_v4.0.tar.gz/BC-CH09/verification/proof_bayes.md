# Prueba formal de BC09-A034: identidad de Bayes usada en el capítulo

Por definición de probabilidad condicionada,
`P(D,T,theta)=P(D|T,theta)P(T,theta)` y también
`P(D,T,theta)=P(T,theta|D)P(D)`. Igualando ambas expresiones y dividiendo por
`P(D)>0` se obtiene
`P(T,theta|D)=P(D|T,theta)P(T,theta)/P(D)`.

La identidad no demuestra que una cadena MCMC haya convergido ni que el modelo
sea adecuado; esas son condiciones adicionales de la inferencia aplicada.
