# Prueba formal de BC09-A049: dominio real finito de K2P

La expresión de K2P contiene `ln(1-2P-Q)` y `ln(1-2Q)`. Ambos logaritmos son
reales y finitos exactamente cuando sus argumentos son estrictamente positivos:

`1-2P-Q > 0` y `1-2Q > 0`.

Además, al ser proporciones observadas, `P >= 0`, `Q >= 0` y `P+Q <= 1`.
En cualquiera de las dos fronteras logarítmicas la distancia deja de ser real
finita. Estas condiciones verifican el dominio publicado en BC09-A049; no
demuestran que K2P sea un modelo adecuado para un conjunto biológico concreto.
