#!/usr/bin/env python3
"""Prueba carrera generador×2 + compilación sobre las figuras publicadas."""

from __future__ import annotations

import hashlib
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time


CHAPTER = Path(__file__).resolve().parents[1]
FACTORY = Path(__file__).resolve().parents[4]
FIGURES = tuple(CHAPTER / "figures" / f"BC09-F{index:02d}.pdf" for index in range(1, 11))


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def assert_complete_pdf(path: Path) -> None:
    payload = path.read_bytes()
    if not payload.startswith(b"%PDF-") or b"%%EOF" not in payload[-1024:]:
        raise RuntimeError(f"PDF parcial o inválido observado: {path}")


def main() -> None:
    if not all(path.is_file() for path in FIGURES):
        raise SystemExit("faltan figuras antes de la prueba concurrente")
    expected = {path.name: digest(path) for path in FIGURES}
    script = CHAPTER / "verification" / "make_figures.py"

    with tempfile.TemporaryDirectory(prefix="bc09-atomic-") as temporary:
        temporary_path = Path(temporary)
        generators = []
        for index in range(2):
            environment = os.environ.copy()
            environment["MPLCONFIGDIR"] = str(temporary_path / f"mpl-{index}")
            generators.append(
                subprocess.Popen(
                    [sys.executable, str(script), "--all"],
                    cwd=FACTORY,
                    env=environment,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )
            )
        build = subprocess.Popen(
            [
                sys.executable,
                "tools/build.py",
                str(CHAPTER / "chapter.tex"),
                "--output-dir",
                str(temporary_path / "chapter-build"),
            ],
            cwd=FACTORY,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )

        reads = 0
        while any(process.poll() is None for process in (*generators, build)):
            for path in FIGURES:
                assert_complete_pdf(path)
                reads += 1
            time.sleep(0.01)

        failures = []
        for label, process in (("generator-1", generators[0]), ("generator-2", generators[1]), ("build", build)):
            stdout, stderr = process.communicate()
            if process.returncode != 0:
                failures.append(f"{label} rc={process.returncode}\n{stdout}\n{stderr}")
        if failures:
            raise RuntimeError("\n".join(failures))

    for path in FIGURES:
        assert_complete_pdf(path)
    observed = {path.name: digest(path) for path in FIGURES}
    leftovers = tuple((CHAPTER / "figures").glob(".BC09-*.pdf"))
    if observed != expected:
        raise RuntimeError("los hashes cambiaron tras la prueba concurrente")
    if leftovers:
        raise RuntimeError(f"temporales residuales: {leftovers}")
    if reads <= 0:
        raise RuntimeError("la prueba no observó ninguna lectura concurrente")
    print(
        "ATOMIC_CONCURRENCY_OK generators=2 build=1 reads_positive=True "
        "hashes_stable=True temp_files=0"
    )


if __name__ == "__main__":
    main()
