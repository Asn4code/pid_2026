#!/usr/bin/env python3
"""Comprueba que UPGMA actualiza distancias ponderando por tamaño de clúster."""

cluster_size = 2
singleton_size = 1
distance_cluster = 32.5
distance_singleton = 28.0
updated = (
    cluster_size * distance_cluster + singleton_size * distance_singleton
) / (cluster_size + singleton_size)
print(f"{updated:.6f}")
