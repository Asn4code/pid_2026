"""Datos sintéticos únicos compartidos por texto, verificaciones y figuras.

Las figuras no mantienen una segunda copia de topologías, coordenadas o
rótulos sustantivos: el generador consume estos objetos y los oráculos los
inspeccionan antes de escribir el PDF.
"""

CHAIN_STAGES = (
    ("Pregunta", "qué historia"),
    ("Secuencias", "muestra y ortología"),
    ("MSA", "homología posicional"),
    ("Modelo", "cambio esperado"),
    ("Búsqueda", "criterio y heurística"),
    ("Apoyo", "estabilidad"),
    ("Afirmación", "alcance y límites"),
)
CHAIN_EDGES = tuple(zip(range(len(CHAIN_STAGES) - 1), range(1, len(CHAIN_STAGES))))

TREE_ROTATIONS = (
    ("A", "B", "C", "D"),
    ("B", "A", "D", "C"),
    ("C", "D", "A", "B"),
)
ROOTED_SPLIT = (("A", "B"), ("C", "D"))
UNROOTED_SPLIT = frozenset((frozenset(("A", "B")), frozenset(("C", "D"))))

DISTANCE_MATRIX = {
    "A": {"A": 0, "B": 17, "C": 21, "D": 31},
    "B": {"A": 17, "B": 0, "C": 30, "D": 34},
    "C": {"A": 21, "B": 30, "C": 0, "D": 28},
    "D": {"A": 31, "B": 34, "C": 28, "D": 0},
}

UPGMA = {
    "h_ab": 8.5,
    "d_ab_c": 25.5,
    "d_ab_d": 32.5,
    "h_abc": 12.75,
    "d_abc_d": 31.0,
    "h_root": 15.5,
}

# Coordenadas desde la raíz, derivadas de las alturas de UPGMA. La figura F06
# consume exactamente este objeto y no vuelve a escribir 7, 2.75 o 15.5.
UPGMA_DRAW = {
    "root_x": 0.0,
    "abc_x": UPGMA["h_root"] - UPGMA["h_abc"],
    "ab_x": UPGMA["h_root"] - UPGMA["h_ab"],
    "leaf_x": {taxon: UPGMA["h_root"] for taxon in "ABCD"},
    "leaf_y": {"A": 3.2, "B": 2.4, "C": 1.6, "D": 0.6},
}

UPGMA_COPHENETIC = {
    "AB": 17.0,
    "AC": 25.5,
    "BC": 25.5,
    "AD": 31.0,
    "BD": 31.0,
    "CD": 31.0,
}

RAW_MSA = {"A": "ACCTGAC", "B": "ACCTAC", "C": "ACTTGAC"}
MSA_1 = {"A": "ACC-TGAC", "B": "ACC-T-AC", "C": "A-CTTGAC"}
MSA_2 = {"A": "ACCT-GAC", "B": "ACCT--AC", "C": "AC-TTGAC"}

BOOTSTRAP_REPLICATES = (
    (1, 1, 3, 4, 4, 6, 8, 8),
    (2, 3, 3, 5, 5, 6, 7, 8),
    (1, 2, 4, 4, 5, 7, 7, 8),
    (1, 2, 3, 4, 5, 6, 7, 8),
)
BOOTSTRAP_OUTCOMES = ("AB", "AC", "AB", "AB")

TREE_COUNT_ANCHORS = {4: 3, 10: 2_027_025}

# Esquema F09: las longitudes terminales son magnitudes, no etiquetas. La
# razón 3:1 queda definida y comprobada sobre las mismas coordenadas dibujadas.
LBA = {
    "node_x": 0.28,
    "short_length": 0.20,
    "long_length": 0.60,
    "generating_order": (("A", "long"), ("B", "short"), ("C", "short"), ("D", "long")),
    "attracted_order": (("A", "long"), ("D", "long"), ("B", "short"), ("C", "short")),
}

SPECIES = ("A", "B", "C", "D")
SPECIES_TREE_ORDER = SPECIES
GENE_COPY_GROUPS = {
    "alpha": tuple(f"{species}: copia alpha" for species in SPECIES),
    "beta": tuple(f"{species}: copia beta" for species in SPECIES),
}

# Trazas mínimas para afirmaciones algorítmicas. No pretenden implementar
# MAFFT ni una búsqueda filogenética real; hacen computable la estructura del
# ejemplo pedagógico exactamente declarada en la prosa.
PROGRESSIVE_GUIDE_PLAN = (("A", "B", "AB"), ("AB", "C", "ABC"))
GAP_POLICY_ALIGNMENT = {
    "A": "AC-GT",
    "B": "ACTGT",
    "C": "AC-G-",
}
HEURISTIC_LANDSCAPE = {
    "T0": {"score": 4, "neighbors": ("T1",)},
    "T1": {"score": 7, "neighbors": ("T0",)},
    "T2": {"score": 6, "neighbors": ("T3",)},
    "T3": {"score": 9, "neighbors": ("T2",)},
}

MODEL_SELECTION_EXAMPLE = {"log_likelihood": -120.0, "parameters": 5, "sites": 100}

MODEL_SELECTION_CANDIDATES = {
    "generating_model": "GTR+G",
    "restricted_scores": {"JC": 18.4, "HKY": 11.2},
    "expanded_scores": {"JC": 18.4, "HKY": 11.2, "GTR+G": 9.7},
}

INPUT_RECORDS = (
    {
        "label": "spA_alpha",
        "organism": "species_A",
        "accession": "ACC001",
        "version": "1",
        "molecule": "protein",
        "sequence": "MKTWQ",
        "source": "synthetic-teaching-fixture",
    },
    {
        "label": "spB_alpha",
        "organism": "species_B",
        "accession": "ACC002",
        "version": "1",
        "molecule": "protein",
        "sequence": "MRTWQ",
        "source": "synthetic-teaching-fixture",
    },
)

PIPELINE_TAXA = {
    "msa": {"spA_alpha", "spB_alpha"},
    "matrix": {"spA_alpha", "spB_alpha"},
    "tree": {"spA_alpha", "spB_alpha"},
}

PRUNING_EXAMPLE = {
    "states": (0, 1),
    "prior": {0: 0.5, 1: 0.5},
    "transition": {0: {0: 0.9, 1: 0.1}, 1: {0: 0.1, 1: 0.9}},
    "tips": {"A": 0, "B": 0, "C": 1, "D": 1},
}
