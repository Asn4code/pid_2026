#!/usr/bin/env python3
"""Oráculos mínimos para los ejemplos JC69 y K2P del piloto BC-CH09."""

import math
import sys


def jc69(p: float) -> float:
    if not 0.0 <= p < 0.75:
        raise ValueError("JC69 requiere 0 <= p < 0.75 para una distancia real finita")
    return -0.75 * math.log(1.0 - 4.0 * p / 3.0)


def k2p(transitions: float, transversions: float) -> float:
    first = 1.0 - 2.0 * transitions - transversions
    second = 1.0 - 2.0 * transversions
    if first <= 0.0 or second <= 0.0:
        raise ValueError("K2P fuera del dominio real")
    return -0.5 * math.log(first) - 0.25 * math.log(second)


if len(sys.argv) != 2:
    raise SystemExit("uso: distances.py jc69|k2p")

if sys.argv[1] == "jc69":
    print(f"{jc69(0.1):.6f}")
elif sys.argv[1] == "k2p":
    print(f"{k2p(0.08, 0.02):.6f}")
else:
    raise SystemExit("modelo desconocido")
