#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH05."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Embudo de plegamiento de Anfinsen que ilustra el descenso desde estados desnaturalizados de alta entropía hacia el mínimo de energía libre nativo.",
    "F02": "Mapa de contactos inter-residuos a distancia umbral de 8.0 Angstroms que delata la presencia de hélices alfa y láminas beta.",
    "F03": "Superposición estructural de Kabsch que muestra la traslación de centroides, matriz de rotación óptima por SVD y alineamiento de coordenadas."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC05-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC05-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC05-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH05 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC05-F01: Embudo de plegamiento de Anfinsen."""
    fig, ax = plt.subplots(figsize=(7.2, 4.0), dpi=300)
    ax.set_xlim(-5, 5)
    ax.set_ylim(0, 5)
    ax.axis("off")

    # Funnel profile
    y = np.linspace(0.6, 4.2, 100)
    x_left = -0.8 - (y - 0.6)**1.1
    x_right = 0.8 + (y - 0.6)**1.1

    ax.plot(x_left, y, color=BLUE, lw=2.5)
    ax.plot(x_right, y, color=BLUE, lw=2.5)
    ax.fill_betweenx(y, x_left, x_right, color="#EBF2F8", alpha=0.7)

    # Annotations
    ax.text(0, 4.5, "Estados Desnaturalizados\n(Alta Entropía Conformacional, Múltiples Microestados)",
            ha="center", va="center", color=RED, fontweight="bold", fontsize=8.5)
    ax.text(0, 2.5, "Intermediarios de Plegamiento\n(Glóbulo Fundido / Molten Globule)",
            ha="center", va="center", color=ORANGE, fontsize=8)
    ax.text(0, 0.3, "Estado Nativo Activo\n(Mínimo Global de $\\Delta G$, Estructura 3D Única)",
            ha="center", va="center", color=GREEN, fontweight="bold", fontsize=8.5)

    # Side arrows for energy and entropy
    ax.add_patch(FancyArrowPatch((-3.8, 4.2), (-3.8, 0.8), arrowstyle="->", color=BLUE, lw=2))
    ax.text(-4.0, 2.5, "Energía Libre de Gibbs ($\\Delta G$) $\\downarrow$", ha="right", va="center", rotation=90, color=BLUE, fontsize=8.5, fontweight="bold")

    save(fig, "F01")

def f02():
    """BC05-F02: Mapa de contactos atómicos 8.0 A."""
    fig, ax = plt.subplots(figsize=(4.5, 4.0), dpi=300)
    n = 20
    np.random.seed(42)
    contact_map = np.zeros((n, n))

    # Main diagonal
    for i in range(n):
        contact_map[i, i] = 1.0
        # Alpha helix local band (i to i+3, i+4)
        if i + 1 < n: contact_map[i, i+1] = contact_map[i+1, i] = 1.0
        if i + 2 < n: contact_map[i, i+2] = contact_map[i+2, i] = 1.0
        if i + 3 < n: contact_map[i, i+3] = contact_map[i+3, i] = 1.0

    # Antiparallel beta sheet contact band (anti-diagonal block)
    for k in range(5):
        i = 2 + k
        j = 18 - k
        contact_map[i, j] = contact_map[j, i] = 1.0

    im = ax.imshow(contact_map, cmap="Blues", origin="upper")
    ax.set_title("Mapa de Contactos ($d_{ij} \\leq 8.0\\text{ \\AA}$)", fontsize=10.5, fontweight="bold", color=BLUE)
    ax.set_xlabel("Índice de Residuo $j$", fontsize=9)
    ax.set_ylabel("Índice de Residuo $i$", fontsize=9)
    ax.text(3, 16, "Lámina $\\beta$", color=RED, fontweight="bold", fontsize=8)
    ax.text(12, 11, "Hélice $\\alpha$", color=BLUE, fontweight="bold", fontsize=8)

    save(fig, "F02")

def f03():
    """BC05-F03: Superposición geométrica de Kabsch y RMSD."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    stages = [
        ("1. Centrado", "Traslación de estructuras\n$\\vec{r}_i' = \\vec{r}_i - \\vec{\\mu}$\nCentroides en $(0,0,0)$", 1.8, 2.2, BLUE),
        ("2. Matriz de Covarianza y SVD", "$R = P^T Q$\nDescomposición SVD:\n$R = V \\Sigma W^T$\n$U = W \\text{diag}(1,1,\\det) V^T$", 5.0, 2.2, ORANGE),
        ("3. Rotación Óptima y RMSD", "Coordenadas superpuestas:\n$P_{\\text{rot}} = P U$\n$\\text{RMSD} = \\sqrt{\\frac{1}{N}\\sum d_i^2}$", 8.2, 2.2, GREEN)
    ]
    for title, desc, cx, cy, col in stages:
        sbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(sbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8)

    ax.add_patch(FancyArrowPatch((3.3, 2.2), (3.5, 2.2), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))
    ax.add_patch(FancyArrowPatch((6.5, 2.2), (6.7, 2.2), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
