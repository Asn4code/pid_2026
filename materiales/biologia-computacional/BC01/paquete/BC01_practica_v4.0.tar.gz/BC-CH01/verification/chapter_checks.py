#!/usr/bin/env python3
"""Comprobaciones reproducibles y deterministas para BC-CH01.

Cubre operaciones fundamentales de secuencias en Python: conteo de nucleotidos,
contenido GC, complemento reverso, transcripcion, ventanas deslizantes y
validacion con excepciones.
"""

from __future__ import annotations

import argparse
import json
import sys


DNA_COMPLEMENT = str.maketrans("ACGTacgt", "TGCAtgca")


def validate_dna(seq: str) -> bool:
    valid_bases = set("ACGT")
    upper_seq = seq.upper()
    invalid = set(upper_seq) - valid_bases
    if invalid:
        raise ValueError(f"Bases invalidas detectadas: {sorted(invalid)}")
    return True


def nucleotide_counts(seq: str) -> dict[str, int]:
    upper_seq = seq.upper()
    validate_dna(upper_seq)
    counts = {b: upper_seq.count(b) for b in "ACGT"}
    counts["TOTAL"] = len(upper_seq)
    return counts


def gc_content(seq: str) -> float:
    upper_seq = seq.upper()
    if not upper_seq:
        return 0.0
    validate_dna(upper_seq)
    g_count = upper_seq.count("G")
    c_count = upper_seq.count("C")
    return ((g_count + c_count) / len(upper_seq)) * 100.0


def reverse_complement(seq: str) -> str:
    upper_seq = seq.upper()
    validate_dna(upper_seq)
    return upper_seq.translate(DNA_COMPLEMENT)[::-1]


def transcribe_dna(seq: str) -> str:
    upper_seq = seq.upper()
    validate_dna(upper_seq)
    return upper_seq.replace("T", "U")


def sliding_window_gc(seq: str, window_size: int = 4, step: int = 2) -> list[dict[str, float | int | str]]:
    upper_seq = seq.upper()
    validate_dna(upper_seq)
    results = []
    n = len(upper_seq)
    for start in range(0, n - window_size + 1, step):
        window = upper_seq[start : start + window_size]
        gc = ((window.count("G") + window.count("C")) / window_size) * 100.0
        results.append({
            "start": start,
            "end": start + window_size,
            "window": window,
            "gc_percent": gc,
        })
    return results


def amino_acid_class(aa: str) -> str:
    classes = {
        "A": "No polar / Alifatico",
        "V": "No polar / Alifatico",
        "L": "No polar / Alifatico",
        "I": "No polar / Alifatico",
        "M": "No polar / Alifatico",
        "P": "No polar / Alifatico",
        "G": "No polar / Alifatico (Aquiral)",
        "F": "Aromatico",
        "Y": "Aromatico / Polar",
        "W": "Aromatico",
        "S": "Polar sin carga",
        "T": "Polar sin carga",
        "C": "Polar sin carga (Puentes disulfuro)",
        "N": "Polar sin carga",
        "Q": "Polar sin carga",
        "D": "Acido / Carga negativa",
        "E": "Acido / Carga negativa",
        "K": "Basico / Carga positiva",
        "R": "Basico / Carga positiva",
        "H": "Basico / Carga positiva (Histidina)",
    }
    return classes.get(aa.upper(), "Desconocido")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH01 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # gc_content
    p_gc = subparsers.add_parser("gc_content")
    p_gc.add_argument("seq", type=str)

    # reverse_complement
    p_rc = subparsers.add_parser("reverse_complement")
    p_rc.add_argument("seq", type=str)

    # transcribe
    p_tx = subparsers.add_parser("transcribe")
    p_tx.add_argument("seq", type=str)

    # nucleotide_counts
    p_nc = subparsers.add_parser("nucleotide_counts")
    p_nc.add_argument("seq", type=str)

    # sliding_window
    p_sw = subparsers.add_parser("sliding_window")
    p_sw.add_argument("seq", type=str)
    p_sw.add_argument("--window", type=int, default=4)
    p_sw.add_argument("--step", type=int, default=2)

    # validate_dna
    p_val = subparsers.add_parser("validate_dna")
    p_val.add_argument("seq", type=str)

    # aa_class
    p_aa = subparsers.add_parser("aa_class")
    p_aa.add_argument("aa", type=str)

    args = parser.parse_args()

    if args.subcommand == "gc_content":
        val = gc_content(args.seq)
        print(f"SEQ:{args.seq.upper()} GC_PERCENT:{val:.6f}")
    elif args.subcommand == "reverse_complement":
        rc = reverse_complement(args.seq)
        print(f"SEQ:{args.seq.upper()} REV_COMP:{rc}")
    elif args.subcommand == "transcribe":
        rna = transcribe_dna(args.seq)
        print(f"DNA:{args.seq.upper()} RNA:{rna}")
    elif args.subcommand == "nucleotide_counts":
        counts = nucleotide_counts(args.seq)
        print(f"SEQ:{args.seq.upper()} A:{counts['A']} C:{counts['C']} G:{counts['G']} T:{counts['T']} TOTAL:{counts['TOTAL']}")
    elif args.subcommand == "sliding_window":
        windows = sliding_window_gc(args.seq, args.window, args.step)
        summary = ";".join(f"{w['start']}-{w['end']}:{w['window']}:{w['gc_percent']:.1f}%" for w in windows)
        print(f"SEQ:{args.seq.upper()} WINDOW:{args.window} STEP:{args.step} WINDOWS:{summary}")
    elif args.subcommand == "validate_dna":
        try:
            validate_dna(args.seq)
            print(f"SEQ:{args.seq.upper()} VALID:True")
        except ValueError as e:
            print(f"SEQ:{args.seq.upper()} VALID:False ERROR:{e}")
    elif args.subcommand == "aa_class":
        cls_name = amino_acid_class(args.aa)
        print(f"AA:{args.aa.upper()} CLASS:{cls_name}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
