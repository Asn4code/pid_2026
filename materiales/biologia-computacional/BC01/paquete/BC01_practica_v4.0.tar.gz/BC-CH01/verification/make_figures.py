#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH01."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Diagrama de flujo del Dogma Central: ADN a ARN por transcripción, ARN a Proteína por traducción, con transcripción inversa y replicación de ARN.",
    "F02": "Representación del código genético degenerado con 64 codones, codón de inicio AUG y 3 codones de parada.",
    "F03": "Sistema de coordenadas biológicas: hebra directa 5' a 3', hebra complementaria reversa y marcos de lectura 1-based."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC01-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC01-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC01-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH01 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC01-F01: Flujo del Dogma Central."""
    fig, ax = plt.subplots(figsize=(8.5, 3.2), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4)
    ax.axis("off")

    # Boxes
    boxes = [
        ("ADN\n(Genoma / 3.2 Gb)", 1.5, 2.0, BLUE),
        ("ARN\n(Transcriptoma)", 5.0, 2.0, GREEN),
        ("Proteína\n(Proteoma / 3D)", 8.5, 2.0, ORANGE)
    ]
    for text, cx, cy, col in boxes:
        box = FancyBboxPatch((cx-1.2, cy-0.8), 2.4, 1.6, boxstyle="round,pad=0.2",
                             fc=LIGHT, ec=col, lw=2.5)
        ax.add_patch(box)
        ax.text(cx, cy, text, ha="center", va="center", color=col, fontweight="bold", fontsize=11)

    # Arrows
    # DNA -> RNA (Transcripción)
    a1 = FancyArrowPatch((2.8, 2.0), (3.7, 2.0), arrowstyle="->", mutation_scale=20, color=BLUE, lw=2)
    ax.add_patch(a1)
    ax.text(3.25, 2.3, "Transcripción\n(ARN Pol II)", ha="center", va="bottom", fontsize=8.5, color=BLUE)

    # RNA -> Protein (Traducción)
    a2 = FancyArrowPatch((6.3, 2.0), (7.2, 2.0), arrowstyle="->", mutation_scale=20, color=GREEN, lw=2)
    ax.add_patch(a2)
    ax.text(6.75, 2.3, "Traducción\n(Ribosoma)", ha="center", va="bottom", fontsize=8.5, color=GREEN)

    # Reverse transcription RNA -> DNA
    a3 = FancyArrowPatch((4.8, 1.1), (1.7, 1.1), connectionstyle="arc3,rad=0.3",
                         arrowstyle="->", mutation_scale=15, color=RED, lw=1.5, ls="--")
    ax.add_patch(a3)
    ax.text(3.25, 0.4, "Transcripción Inversa (Retrotranscriptasa)", ha="center", va="top", fontsize=8, color=RED)

    # DNA replication loop
    a4 = FancyArrowPatch((1.0, 2.9), (2.0, 2.9), connectionstyle="arc3,rad=1.2",
                         arrowstyle="->", mutation_scale=15, color=BLUE, lw=1.5)
    ax.add_patch(a4)
    ax.text(1.5, 3.6, "Replicación", ha="center", va="bottom", fontsize=8, color=BLUE)

    save(fig, "F01")

def f02():
    """BC02-F02: Código genético y redundancia."""
    fig, ax = plt.subplots(figsize=(7.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 5)
    ax.axis("off")

    # Title box
    tbox = FancyBboxPatch((0.5, 3.8), 9.0, 0.9, boxstyle="round,pad=0.1", fc=LIGHT, ec=BLUE, lw=1.5)
    ax.add_patch(tbox)
    ax.text(5.0, 4.25, "El Código Genético: 64 Codones de Triplete", ha="center", va="center", color=BLUE, fontweight="bold", fontsize=11)

    # 3 Categories
    cards = [
        ("Codón de Inicio\n(Universal)", "AUG\n(Metionina / Met)", 2.0, 2.0, GREEN),
        ("Codones Codificantes\n(Degenerados / Redundantes)", "61 Codones\n-> 20 Aminoácidos Estándar\n(Ej. Leucina: 6 codones)", 5.0, 2.0, BLUE),
        ("Codones de Parada\n(Señal Stop)", "UAA (Ochre)\nUAG (Amber)\nUGA (Opal)", 8.0, 2.0, RED)
    ]
    for title, desc, cx, cy, col in cards:
        cbox = FancyBboxPatch((cx-1.3, cy-1.3), 2.6, 2.6, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(cbox)
        ax.text(cx, cy+0.75, title, ha="center", va="center", color=col, fontweight="bold", fontsize=9.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8.5)

    save(fig, "F02")

def f03():
    """BC01-F03: Sistema de coordenadas biológicas y complementariedad."""
    fig, ax = plt.subplots(figsize=(8.5, 3.4), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4)
    ax.axis("off")

    # DNA duplex diagram
    # Forward strand
    ax.text(0.5, 2.8, "5'", fontsize=12, fontweight="bold", color=BLUE, va="center")
    ax.text(9.5, 2.8, "3'", fontsize=12, fontweight="bold", color=BLUE, va="center")
    fwd_seq = "A   T   G   G   C   C   A   T   T   G   T   A"
    coords  = "1   2   3   4   5   6   7   8   9  10  11  12"
    ax.text(5.0, 2.8, fwd_seq, ha="center", va="center", fontfamily="monospace", fontsize=12, color=BLUE, fontweight="bold")
    ax.text(5.0, 3.4, coords, ha="center", va="center", fontfamily="monospace", fontsize=8.5, color=GRAY)
    ax.text(5.0, 3.8, "Coordenadas Biológicas (1-based cerrado)", ha="center", va="center", fontsize=9, color=GRAY, fontstyle="italic")

    # Hydrogen bonds
    for i in range(12):
        x = 1.35 + i * 0.66
        ax.plot([x, x], [2.3, 2.0], color="#AAAAAA", lw=1.5, ls=":")

    # Reverse strand
    ax.text(0.5, 1.5, "3'", fontsize=12, fontweight="bold", color=ORANGE, va="center")
    ax.text(9.5, 1.5, "5'", fontsize=12, fontweight="bold", color=ORANGE, va="center")
    rev_seq = "T   A   C   C   G   G   T   A   A   C   A   T"
    ax.text(5.0, 1.5, rev_seq, ha="center", va="center", fontfamily="monospace", fontsize=12, color=ORANGE, fontweight="bold")

    # Annotation boxes
    abox1 = FancyBboxPatch((1.0, 0.2), 3.6, 0.7, boxstyle="round,pad=0.1", fc=LIGHT, ec=BLUE, lw=1)
    ax.add_patch(abox1)
    ax.text(2.8, 0.55, "Hebra Directa (+): ATGGCCATTGTA", ha="center", va="center", fontsize=8, color=BLUE)

    abox2 = FancyBboxPatch((5.4, 0.2), 3.6, 0.7, boxstyle="round,pad=0.1", fc=LIGHT, ec=ORANGE, lw=1)
    ax.add_patch(abox2)
    ax.text(7.2, 0.55, "Reversa Complementaria (5'->3'): TACAATGGCCAT", ha="center", va="center", fontsize=8, color=ORANGE)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
