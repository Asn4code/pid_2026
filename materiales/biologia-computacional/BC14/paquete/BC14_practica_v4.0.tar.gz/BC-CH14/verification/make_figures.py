#!/usr/bin/env python3
"""Genera las figuras vectoriales originales y accesibles del capítulo BC-CH14."""

from __future__ import annotations

import argparse
import datetime as dt
import os
import tempfile
from pathlib import Path

os.environ["SOURCE_DATE_EPOCH"] = "1785888000"

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Circle, Rectangle

matplotlib.rcParams["pdf.fonttype"] = 42
matplotlib.rcParams["font.size"] = 10
matplotlib.rcParams["font.family"] = "DejaVu Sans"

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
BLUE = "#174A7E"
GREEN = "#2A6F62"
ORANGE = "#C76D2A"
RED = "#A83232"
GRAY = "#555555"
LIGHT = "#F4F7F9"

ALT_TEXTS = {
    "F01": "Descomposición energética de un campo de fuerza macromolecular en términos enlazados y no enlazados de Lennard-Jones y Coulomb.",
    "F02": "Esquema del acoplamiento molecular ligando receptor en la caja de docking y conversión de afinidad a constante de disociación.",
    "F03": "Similitud molecular de Tanimoto sobre huellas binarias y los cuatro criterios de druglikeness de la regla de cinco de Lipinski."
}

FIXED_PDF_DATE = dt.datetime(2026, 8, 5, 0, 0, 0, tzinfo=dt.timezone.utc)

def save(fig: plt.Figure, name: str) -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    target = OUT / f"BC14-{name}.pdf"
    with tempfile.NamedTemporaryFile(dir=OUT, prefix=f".BC14-{name}.", suffix=".pdf", delete=False) as handle:
        temporary = Path(handle.name)
    fig.savefig(
        temporary,
        bbox_inches="tight",
        metadata={
            "Title": f"BC14-{name}",
            "Subject": ALT_TEXTS[name],
            "Creator": "BC-CH14 make_figures.py",
            "CreationDate": FIXED_PDF_DATE,
            "ModDate": FIXED_PDF_DATE,
        },
    )
    with temporary.open("rb") as handle:
        os.fsync(handle.fileno())
    os.replace(temporary, target)
    plt.close(fig)

def f01():
    """BC14-F01: Campo de fuerza macromolecular."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.1, "Descomposición Energética de Campos de Fuerza (AMBER / CHARMM / OPLS)", ha="center", color=BLUE, fontweight="bold", fontsize=10.5)

    terms = [
        ("Términos Enlazados", "• Enlaces: $k_b (r - r_0)^2$\n• Ángulos: $k_\\theta (\\theta - \\theta_0)^2$\n• Diedros: $\\frac{V_n}{2}[1+\\cos(n\\phi-\\gamma)]$", 2.6, 2.0, BLUE),
        ("Términos No Enlazados", "• Van der Waals:\n  Lennard-Jones $4\\epsilon [(\\sigma/r)^{12} - (\\sigma/r)^6]$\n• Electrostática:\n  Coulomb $\\frac{q_i q_j}{4\\pi \\epsilon_0 r_{ij}}$", 7.4, 2.0, GREEN)
    ]
    for title, desc, cx, cy, col in terms:
        tbox = FancyBboxPatch((cx-2.1, cy-1.4), 4.2, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(tbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9.5)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8.5)

    save(fig, "F01")

def f02():
    """BC14-F02: Docking molecular y constante Kd."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    ax.text(5.0, 4.1, "Acoplamiento Molecular (Docking) y Termodinámica de Unión", ha="center", color=BLUE, fontweight="bold", fontsize=10.5)

    steps = [
        ("1. Diana y Grid Box", "Estructura 3D del receptor\nDefinición de cavidad activa\nMapas de potencial de afinidad", 1.8, 2.0, BLUE),
        ("2. Muestreo de Poses", "Algoritmo genético Lamarckiano\nRotación de enlaces libres\nAutoDock Vina", 5.0, 2.0, ORANGE),
        ("3. Afinidad y $K_d$", "Puntuación de energía libre:\n$\\Delta G = -8.4\\text{ kcal/mol}$\n$K_d = e^{\\Delta G / RT} \\approx 0.69\\text{ }\\mu\\text{M}$", 8.2, 2.0, GREEN)
    ]
    for title, desc, cx, cy, col in steps:
        sbox = FancyBboxPatch((cx-1.4, cy-1.4), 2.8, 2.8, boxstyle="round,pad=0.15", fc="white", ec=col, lw=2)
        ax.add_patch(sbox)
        ax.text(cx, cy+0.9, title, ha="center", color=col, fontweight="bold", fontsize=9)
        ax.text(cx, cy-0.2, desc, ha="center", va="center", color=GRAY, fontsize=8)

    ax.add_patch(FancyArrowPatch((3.3, 2.0), (3.5, 2.0), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))
    ax.add_patch(FancyArrowPatch((6.5, 2.0), (6.7, 2.0), arrowstyle="->", color=GRAY, lw=2.5, mutation_scale=15))

    save(fig, "F02")

def f03():
    """BC14-F03: Similitud Tanimoto y Regla de Lipinski."""
    fig, ax = plt.subplots(figsize=(8.5, 3.8), dpi=300)
    ax.set_xlim(0, 10)
    ax.set_ylim(0, 4.5)
    ax.axis("off")

    # Left box: Tanimoto
    b1 = FancyBboxPatch((0.5, 0.4), 4.2, 3.7, boxstyle="round,pad=0.15", fc="white", ec=BLUE, lw=2)
    ax.add_patch(b1)
    ax.text(2.6, 3.75, "Similitud de Tanimoto", ha="center", color=BLUE, fontweight="bold", fontsize=10)
    ax.text(2.6, 2.7, "Huellas moleculares binarias:\n$T(A, B) = \\frac{|A \\cap B|}{|A \\cup B|} = \\frac{c}{a + b - c}$", ha="center", va="center", color=GRAY, fontsize=9)
    ax.text(2.6, 1.1, "Ejemplo modelo:\n$a=3, b=3, c=2 \\to T = 0.500000$", ha="center", color=BLUE, fontweight="bold", fontsize=8.5)

    # Right box: Lipinski Rule of 5
    b2 = FancyBboxPatch((5.3, 0.4), 4.2, 3.7, boxstyle="round,pad=0.15", fc="white", ec=GREEN, lw=2)
    ax.add_patch(b2)
    ax.text(7.4, 3.75, "Regla de 5 de Lipinski (Druglikeness)", ha="center", color=GREEN, fontweight="bold", fontsize=10)
    ax.text(7.4, 2.4, "1. Peso molecular: $MW \\leq 500\\text{ Da}$\n2. Lipofilia: $\\log P \\leq 5$\n3. Donadores H: $HBD \\leq 5$\n4. Aceptores H: $HBA \\leq 10$", ha="center", va="center", color=GRAY, fontsize=8.5)
    ax.text(7.4, 0.9, "Predice biodisponibilidad oral óptima", ha="center", color=GREEN, fontweight="bold", fontsize=8.5)

    save(fig, "F03")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--check", choices=["F01", "F02", "F03", "all"], default="all")
    args = parser.parse_args()
    if args.check == "all":
        f01()
        f02()
        f03()
    elif args.check == "F01":
        f01()
    elif args.check == "F02":
        f02()
    elif args.check == "F03":
        f03()

if __name__ == "__main__":
    main()
