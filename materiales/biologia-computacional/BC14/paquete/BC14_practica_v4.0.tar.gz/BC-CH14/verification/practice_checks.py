#!/usr/bin/env python3
"""Comprobaciones para el anexo practico de BC-CH14: Dinamica molecular, docking y cribado virtual."""

from __future__ import annotations

import argparse
import sys

from chapter_checks import (
    calculate_tanimoto_similarity,
    delta_g_to_kd_micromolar,
    evaluate_lipinski_rule,
    verlet_step_position,
)


def practice_anchor() -> None:
    # 1. Lipinski rule
    viol, riesgo = evaluate_lipinski_rule(350.0, 2.5, 2, 4)
    
    # 2. Tanimoto similarity
    t_sim = calculate_tanimoto_similarity(10, 12, 8)
    
    # 3. Delta G to Kd
    kd_um = delta_g_to_kd_micromolar(-8.50, 298.15)
    
    # 4. Verlet step
    x1 = verlet_step_position(0.0, 1.0, 2.0, 0.5)
    
    print(
        f"LIPINSKI_VIOLATIONS:{viol} RIESGO_ABSORCION:{riesgo} "
        f"TANIMOTO:{t_sim:.6f} KD_UM:{kd_um:.6f} VERLET_X1:{x1:.6f}"
    )


def practice_perturbation() -> None:
    viol_bad, riesgo_bad = evaluate_lipinski_rule(650.0, 6.2, 7, 12)
    kd_weak = delta_g_to_kd_micromolar(-4.00, 298.15)
    print(
        f"PERTURBED_VIOLATIONS:{viol_bad} RIESGO_ABSORCION:{riesgo_bad} "
        f"WEAK_KD_UM:{kd_weak:.6f}"
    )


def practice_domain_guard(temperature: float = -5.0) -> None:
    try:
        delta_g_to_kd_micromolar(-8.50, temperature)
        print(f"GUARD_TEMP:{temperature} STATUS:ACCEPTED")
    except ValueError as e:
        print(f"GUARD_TEMP:{temperature} STATUS:REJECTED ERROR:{e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH14 Practice Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    subparsers.add_parser("anchor")
    subparsers.add_parser("perturbation")

    p_guard = subparsers.add_parser("domain_guard")
    p_guard.add_argument("--temp", type=float, default=-5.0)

    args = parser.parse_args()

    if args.subcommand == "anchor":
        practice_anchor()
    elif args.subcommand == "perturbation":
        practice_perturbation()
    elif args.subcommand == "domain_guard":
        practice_domain_guard(args.temp)

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
