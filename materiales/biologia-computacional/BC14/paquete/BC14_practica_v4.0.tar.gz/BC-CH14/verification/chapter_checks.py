#!/usr/bin/env python3
"""Comprobaciones deterministas para BC-CH14: Dinamica molecular, docking y cribado virtual.

Implementa la regla de 5 de Lipinski (Drug-likeness), calculo del coeficiente de similitud
de Tanimoto para huellas quimicas (fingerprints), conversion termodinamica de energia libre
de docking (Delta G) a constante de disociacion Kd, e integracion de Verlet para dinamica molecular.
"""

from __future__ import annotations

import argparse
import math
import sys


def evaluate_lipinski_rule(mw: float, logp: float, hbd: int, hba: int) -> tuple[int, bool]:
    if mw <= 0 or hbd < 0 or hba < 0:
        raise ValueError("Parametros fisicoquimicos deben tener valores validos no negativos")
    violations = 0
    if mw > 500.0:
        violations += 1
    if logp > 5.0:
        violations += 1
    if hbd > 5:
        violations += 1
    if hba > 10:
        violations += 1
    # la regla de cinco no es un clasificador binario de aptitud: se devuelve
    # el recuento y una etiqueta de riesgo de absorcion
    riesgo = "alto" if violations >= 2 else "bajo"
    return violations, riesgo


def calculate_tanimoto_similarity(count_a: int, count_b: int, count_common: int) -> float:
    if count_a < 0 or count_b < 0 or count_common < 0:
        raise ValueError("Los recuentos de bits no pueden ser negativos")
    if count_common > count_a or count_common > count_b:
        raise ValueError("Los bits comunes no pueden superar a los conjuntos individuales")
    union = count_a + count_b - count_common
    if union == 0:
        return 1.0
    return count_common / union


def delta_g_to_kd_micromolar(delta_g: float, temperature: float = 298.15) -> float:
    if temperature <= 0:
        raise ValueError("La temperatura absoluta debe ser estrictamente positiva")
    r_kcal = 0.00198720425864083  # kcal / (mol * K)
    rt = r_kcal * temperature
    kd_molar = math.exp(delta_g / rt)
    return kd_molar * 1e6  # conversion a micromolar (uM)


def velocity_verlet_step(x0: float, v0: float, a0: float, a1: float, dt: float) -> tuple:
    """Paso completo de velocity-Verlet: posicion nueva y velocidad nueva.

    a1 es la aceleracion recalculada con el campo de fuerza en la posicion
    nueva. En este ejemplo la aceleracion es constante, de modo que a1 == a0.
    """
    if dt <= 0:
        raise ValueError("El paso de tiempo dt debe ser positivo")
    x1 = x0 + (v0 * dt) + (0.5 * a0 * (dt ** 2))
    v1 = v0 + 0.5 * (a0 + a1) * dt
    return round(x1, 6), round(v1, 6)


def verlet_step_position(x0: float, v0: float, a0: float, dt: float) -> float:
    if dt <= 0:
        raise ValueError("El paso de integracion temporal dt debe ser estrictamente positivo")
    return x0 + v0 * dt + 0.5 * a0 * (dt ** 2)


def main() -> int:
    parser = argparse.ArgumentParser(description="BC-CH14 Checks")
    subparsers = parser.add_subparsers(dest="subcommand", required=True)

    # lipinski
    p_lip = subparsers.add_parser("lipinski")
    p_lip.add_argument("--mw", type=float, default=350.0)
    p_lip.add_argument("--logp", type=float, default=2.5)
    p_lip.add_argument("--hbd", type=int, default=2)
    p_lip.add_argument("--hba", type=int, default=4)

    # tanimoto
    p_tan = subparsers.add_parser("tanimoto")
    p_tan.add_argument("--a", type=int, default=10)
    p_tan.add_argument("--b", type=int, default=12)
    p_tan.add_argument("--c", type=int, default=8)

    # affinity
    p_aff = subparsers.add_parser("affinity")
    p_aff.add_argument("--delta_g", type=float, default=-8.50)
    p_aff.add_argument("--temp", type=float, default=298.15)

    # verlet
    p_ver = subparsers.add_parser("verlet")
    p_ver.add_argument("--x0", type=float, default=0.0)
    p_ver.add_argument("--v0", type=float, default=1.0)
    p_ver.add_argument("--a0", type=float, default=2.0)
    p_ver.add_argument("--dt", type=float, default=0.5)

    # velocity_verlet: paso completo, posicion y velocidad
    p_vv = subparsers.add_parser("velocity_verlet")
    p_vv.add_argument("--x0", type=float, default=0.0)
    p_vv.add_argument("--v0", type=float, default=1.0)
    p_vv.add_argument("--a0", type=float, default=2.0)
    p_vv.add_argument("--a1", type=float, default=2.0)
    p_vv.add_argument("--dt", type=float, default=0.5)

    args = parser.parse_args()

    if args.subcommand == "lipinski":
        viol, pass_ok = evaluate_lipinski_rule(args.mw, args.logp, args.hbd, args.hba)
        print(f"MW:{args.mw:.1f} LOGP:{args.logp:.2f} HBD:{args.hbd} HBA:{args.hba} VIOLATIONS:{viol} RIESGO_ABSORCION:{pass_ok}")
    elif args.subcommand == "tanimoto":
        t = calculate_tanimoto_similarity(args.a, args.b, args.c)
        print(f"BITS_A:{args.a} BITS_B:{args.b} COMMON:{args.c} TANIMOTO:{t:.6f}")
    elif args.subcommand == "affinity":
        try:
            kd_um = delta_g_to_kd_micromolar(args.delta_g, args.temp)
            print(f"DELTA_G:{args.delta_g:.2f} TEMP:{args.temp:.2f} KD_UM:{kd_um:.6f}")
        except ValueError as e:
            # la guarda de temperatura absoluta informa por la salida estandar
            print(f"DELTA_G:{args.delta_g:.2f} TEMP:{args.temp:.2f} VALID:False ERROR:{e}")
    elif args.subcommand == "velocity_verlet":
        x1, v1 = velocity_verlet_step(args.x0, args.v0, args.a0, args.a1, args.dt)
        print(f"X0:{args.x0:.2f} V0:{args.v0:.2f} DT:{args.dt:.2f} X1:{x1:.6f} V1:{v1:.6f}")
    elif args.subcommand == "verlet":
        x1 = verlet_step_position(args.x0, args.v0, args.a0, args.dt)
        print(f"X0:{args.x0:.2f} V0:{args.v0:.2f} A0:{args.a0:.2f} DT:{args.dt:.2f} X1:{x1:.6f}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
