# TC-CH05 · materiales de la práctica

Todo lo que necesita para el anexo práctico de TC-CH05. Funciona sin red y sin
más dependencia que Python 3.9 y un intérprete de órdenes.

## Qué hay aquí

- `practice_assets/` · el generador de su espacio de trabajo y el verificador
  de entrega.
- `data/` · los datos de partida, con su manifiesto de sumas.
- `verification/` · el oráculo del capítulo y el comprobador público de su
  módulo. Miden; no responden por usted.

## Cómo empezar

    ./practice_assets/create_workspace.sh TCCH05_entrega
    cd TCCH05_entrega

El generador crea la plantilla de su módulo, **sin implementar**, la tabla de
respuestas con solo su cabecera y las carpetas de resultados y notas.

## Antes de ejecutar nada

Escriba lo que espera obtener. El contraste entre su predicción y el resultado
es lo que se evalúa, no el resultado por sí solo.

## Cómo comprobar que ha terminado

    ./practice_assets/check_entrega.sh TCCH05_entrega

El verificador comprueba integridad y completitud. **No pone nota** y rechaza
tanto la entrega vacía como el espacio de trabajo recién generado.

## Integridad

`MANIFIESTO.sha256` fija las sumas de todo lo que se le entrega. Para
comprobarlo:

    sha256sum --check --strict MANIFIESTO.sha256
