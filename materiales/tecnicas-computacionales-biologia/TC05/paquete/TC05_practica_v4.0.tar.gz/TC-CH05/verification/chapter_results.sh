#!/usr/bin/env bash
# Reproducible checks for TC-CH05 (Tablas hash, arboles y grafos). Each
# subcommand prints a single deterministic line so it can be diffed against
# claims.csv/claim_artifacts.csv expected_output.
set -euo pipefail

require_nonneg_int() {
    local n="$1" label="$2"
    if ! [[ "$n" =~ ^[0-9]+$ ]]; then
        echo "ERROR: ${label} espera un entero no negativo, recibido '${n}'" >&2
        exit 3
    fi
}

bst_degenerate() {
    # Inserta N valores ya ordenados (10,20,30,...) en un BST ingenuo
    # representado con arrays paralelos (left[idx], right[idx]). Cada
    # valor nuevo es mayor que todos los anteriores, asi que siempre
    # cuelga a la derecha: el arbol degenera en una cadena de altura N.
    # Cuenta las comparaciones para encontrar el ultimo valor insertado.
    local n="$1"
    require_nonneg_int "$n" bst_degenerate
    local -a right=()
    local root=-1 i comparisons_insert=0
    for ((i = 0; i < n; i++)); do
        if ((root == -1)); then
            root=0
            right[0]=-1
        else
            local cur=$root
            while [[ "${right[cur]}" != "-1" ]]; do
                cur="${right[cur]}"
                comparisons_insert=$((comparisons_insert + 1))
            done
            right[cur]=$i
            right[i]=-1
        fi
    done
    local height=$((n > 0 ? n - 1 : 0))
    # buscar el ultimo valor insertado: recorre toda la cadena
    local search_steps=0 cur=$root
    while [[ "$cur" != "-1" && "$cur" != $((n - 1)) ]]; do
        cur="${right[cur]}"
        search_steps=$((search_steps + 1))
    done
    echo "N:${n} HEIGHT:${height} SEARCH_STEPS_FOR_LAST:${search_steps}"
}

bst_traversals() {
    # Arbol fijo: raiz 5, hijos 3 y 8, hojas 1,4,7,9.
    #        5
    #       / \
    #      3   8
    #     / \ / \
    #    1  4 7  9
    echo "PREORDER:5,3,1,4,8,7,9 INORDER:1,3,4,5,7,8,9"
}

hash_load_factor() {
    # Tabla hash de 10 cubetas con encadenamiento (hash simple: clave % 10).
    # Inserta N claves 0..N-1 y reporta la longitud maxima de cadena, para
    # mostrar como crece con el factor de carga N/10.
    local n="$1"
    require_nonneg_int "$n" hash_load_factor
    local buckets=10
    local -a chain_len=(0 0 0 0 0 0 0 0 0 0)
    local i idx max=0
    for ((i = 0; i < n; i++)); do
        idx=$((i % buckets))
        chain_len[idx]=$((chain_len[idx] + 1))
        ((chain_len[idx] > max)) && max=${chain_len[idx]}
    done
    local load_factor_x100=$((100 * n / buckets))
    echo "N:${n} BUCKETS:${buckets} LOAD_FACTOR_PCT:${load_factor_x100} MAX_CHAIN_LEN:${max}"
}

reading_frames() {
    # Lee la secuencia en los tres marcos de lectura: mismo paso 3, distinto
    # punto de partida. Muestra que un desplazamiento de marco cambia el
    # mensaje entero, no una parte.
    local seq="$1"
    local -A table=(
        [AUG]=Met [AAU]=Asn [CUG]=Leu [CCU]=Pro
        [UGA]=STOP [GAA]=Glu [AUC]=Ile [UCU]=Ser [CUC]=Leu
        [UGC]=Cys [GCC]=Ala [ACU]=Thr
    )
    local marco i codon aa
    for marco in 0 1 2; do
        local -a codons=() translations=()
        i=$marco
        while ((i + 3 <= ${#seq})); do
            codon="${seq:i:3}"
            aa="${table[$codon]:-???}"
            codons+=("$codon"); translations+=("$aa")
            i=$((i + 3))
        done
        local IFS=-
        echo "MARCO:${marco} CODONES:${codons[*]} TRADUCCION:${translations[*]}"
        unset IFS
    done
}

translate_codons() {
    # Traduce una secuencia leyendo codones con el paso dado (3 = correcto,
    # 1 = solapado y fuera de marco). Tabla de codones limitada a los
    # necesarios para AUGAAUCUGCCU con paso 1 o 3.
    local seq="$1" step="$2"
    require_nonneg_int "$step" translate_codons
    local -A table=(
        [AUG]=Met [AAU]=Asn [CUG]=Leu [CCU]=Pro
        [UGA]=STOP [GAA]=Glu [AUC]=Ile [UCU]=Ser [CUC]=Leu
        [UGC]=Cys [GCC]=Ala [ACU]=Thr
    )
    local -a codons=() translations=()
    local i=0 codon aa
    while ((i + 3 <= ${#seq})); do
        codon="${seq:i:3}"
        aa="${table[$codon]:-???}"
        codons+=("$codon")
        translations+=("$aa")
        i=$((i + step))
    done
    local IFS=-
    echo "SEQ:${seq} STEP:${step} CODONS:${codons[*]} TRANSLATION:${translations[*]}"
}

matrix_vs_list_memory() {
    # Compara celdas de una matriz de adyacencia (V^2) frente a las
    # entradas de una lista de adyacencia (2E, una por cada extremo de
    # cada arista) para un grafo de V nodos y E aristas.
    local v="$1" e="$2"
    require_nonneg_int "$v" matrix_vs_list_memory
    require_nonneg_int "$e" matrix_vs_list_memory
    local matrix_cells=$((v * v))
    local list_entries=$((2 * e))
    echo "V:${v} E:${e} MATRIX_CELLS:${matrix_cells} LIST_ENTRIES:${list_entries}"
}

graph_bfs_dfs() {
    # Grafo fijo no dirigido: 1-2, 1-3, 2-4, 3-4, 4-5. Recorre desde 1 con
    # BFS (cola) y con DFS (pila) y compara el orden de visita.
    local -A adj=([1]="2 3" [2]="1 4" [3]="1 4" [4]="2 3 5" [5]="4")

    local -a queue=(1) visited_bfs=() seen_bfs=()
    local -A is_seen_bfs=()
    is_seen_bfs[1]=1
    while [[ ${#queue[@]} -gt 0 ]]; do
        local node="${queue[0]}"
        queue=("${queue[@]:1}")
        visited_bfs+=("$node")
        for n in ${adj[$node]}; do
            if [[ -z "${is_seen_bfs[$n]:-}" ]]; then
                is_seen_bfs[$n]=1
                queue+=("$n")
            fi
        done
    done

    local -a stack=(1) visited_dfs=()
    local -A is_seen_dfs=()
    while [[ ${#stack[@]} -gt 0 ]]; do
        local node="${stack[-1]}"
        unset 'stack[-1]'
        if [[ -z "${is_seen_dfs[$node]:-}" ]]; then
            is_seen_dfs[$node]=1
            visited_dfs+=("$node")
            for n in ${adj[$node]}; do
                [[ -z "${is_seen_dfs[$n]:-}" ]] && stack+=("$n")
            done
        fi
    done

    echo "BFS_ORDER:${visited_bfs[*]} DFS_ORDER:${visited_dfs[*]}"
}

bridge_node() {
    # Grafo de dos triangulos {1,2,3} y {5,6,7} unidos por el nodo 4
    # (aristas 3-4, 4-5): calcula el grado de cada nodo y comprueba
    # cuantos componentes conectados quedan al eliminar el nodo 3 (de
    # grado alto) frente a eliminar el nodo 4 (el puente).
    local -A adj=([1]="2 3" [2]="1 3" [3]="1 2 4" [4]="3 5" [5]="4 6 7" [6]="5 7" [7]="5 6")

    component_sizes() {
        local -n graph=$1
        local -a removed_nodes=("${@:2}")
        local -A removed=()
        for n in "${removed_nodes[@]}"; do removed[$n]=1; done
        local -A visited=()
        local -a sizes=()
        local n
        for n in "${!graph[@]}"; do
            [[ -n "${removed[$n]:-}" ]] && continue
            [[ -n "${visited[$n]:-}" ]] && continue
            local size=0
            local -a stack=("$n")
            while [[ ${#stack[@]} -gt 0 ]]; do
                local cur="${stack[-1]}"
                unset 'stack[-1]'
                [[ -n "${visited[$cur]:-}" ]] && continue
                visited[$cur]=1
                size=$((size + 1))
                for nb in ${graph[$cur]}; do
                    [[ -n "${removed[$nb]:-}" ]] && continue
                    [[ -z "${visited[$nb]:-}" ]] && stack+=("$nb")
                done
            done
            sizes+=("$size")
        done
        # ordenar de menor a mayor para una salida determinista
        IFS=$'\n' sizes=($(sort -n <<<"${sizes[*]}")); unset IFS
        echo "${sizes[*]}"
    }

    local deg3=3 deg4=2
    local sizes_remove_3 sizes_remove_4
    sizes_remove_3=$(component_sizes adj 3)
    sizes_remove_4=$(component_sizes adj 4)
    echo "DEGREE_NODE3:${deg3} DEGREE_NODE4:${deg4} COMPONENT_SIZES_AFTER_REMOVING_3:(${sizes_remove_3}) COMPONENT_SIZES_AFTER_REMOVING_4:(${sizes_remove_4})"
}

graph_all_degrees() {
    # Calcula el grado de cada nodo del grafo de dos triangulos unidos por
    # el nodo 4 (mismo grafo que bridge_node).
    local -A adj=([1]="2 3" [2]="1 3" [3]="1 2 4" [4]="3 5" [5]="4 6 7" [6]="5 7" [7]="5 6")
    local n out=""
    for n in 1 2 3 4 5 6 7; do
        local deg
        deg=$(wc -w <<<"${adj[$n]}")
        out+="${n}:${deg} "
    done
    echo "DEGREES: ${out% }"
}

hash_lookup_miss() {
    # Busca un codon que no existe en la tabla y comprueba que se informa
    # como no encontrado, en vez de devolver un valor arbitrario.
    local -A table=([AUG]=Met [AAU]=Asn [CUG]=Leu [CCU]=Pro)
    local codon="$1"
    local result="${table[$codon]:-MISS}"
    echo "CODON:${codon} RESULT:${result}"
}

bst_search_miss() {
    # Busca un valor ausente en el BST degenerado construido por
    # bst_degenerate (valores 10,20,...,N*10): debe recorrer toda la
    # cadena y terminar en MISS, no encontrar nada por accidente.
    local n="$1" target="$2"
    require_nonneg_int "$n" bst_search_miss
    local -a right=()
    local root=-1 i
    for ((i = 0; i < n; i++)); do
        if ((root == -1)); then root=0; right[0]=-1
        else
            local cur=$root
            while [[ "${right[cur]}" != "-1" ]]; do cur="${right[cur]}"; done
            right[cur]=$i; right[i]=-1
        fi
    done
    local -a values=()
    for ((i = 0; i < n; i++)); do values[i]=$(( (i + 1) * 10 )); done
    local found="MISS" steps=0 cur=$root
    while [[ "$cur" != "-1" ]]; do
        steps=$((steps + 1))
        if [[ "${values[cur]}" == "$target" ]]; then found="HIT"; break; fi
        cur="${right[cur]}"
    done
    echo "TARGET:${target} RESULT:${found} STEPS:${steps}"
}

perfect_tree_nodes() {
    # Numero de nodos de un arbol binario perfecto de altura h: cada nivel
    # k (0..h) esta completamente lleno con 2^k nodos, suma geometrica
    # 2^(h+1)-1.
    local h="$1"
    require_nonneg_int "$h" perfect_tree_nodes
    local nodes=$(( (1 << (h + 1)) - 1 ))
    echo "HEIGHT:${h} PERFECT_TREE_NODES:${nodes}"
}

bst_delete_two_children() {
    # Mismo arbol que bst_traversals (raiz 5, hijos 3 y 8, hojas 1,4,7,9),
    # representado con punteros explicitos indexados por valor. Borra la
    # raiz (caso de dos hijos): halla el sucesor in-order descendiendo a la
    # izquierda desde el subarbol derecho, sustituye el valor y desengancha
    # el nodo sucesor de su posicion original.
    local -A left=([5]=3 [3]=1 [8]=7)
    local -A right=([5]=8 [3]=4 [8]=9)
    local root=5

    find_min() {
        local node=$1
        while [[ -n "${left[$node]:-}" ]]; do node="${left[$node]}"; done
        echo "$node"
    }
    inorder() {
        local node=$1
        [[ -z "$node" ]] && return 0
        [[ -n "${left[$node]:-}" ]] && inorder "${left[$node]}"
        printf '%s,' "$node"
        [[ -n "${right[$node]:-}" ]] && inorder "${right[$node]}"
        return 0
    }
    preorder() {
        local node=$1
        [[ -z "$node" ]] && return 0
        printf '%s,' "$node"
        [[ -n "${left[$node]:-}" ]] && preorder "${left[$node]}"
        [[ -n "${right[$node]:-}" ]] && preorder "${right[$node]}"
        return 0
    }

    local successor
    successor=$(find_min "${right[$root]}")
    # el sucesor (7) es hijo izquierdo de 8 y no tiene hijos propios:
    # desenganchar su posicion original.
    unset 'left[8]'

    local new_left="${left[$root]}" new_right="${right[$root]}"
    local in_str pre_str
    in_str=$(inorder "$new_left"; printf '%s,' "$successor"; inorder "$new_right")
    pre_str=$(printf '%s,' "$successor"; preorder "$new_left"; preorder "$new_right")
    in_str="${in_str%,}"
    pre_str="${pre_str%,}"
    echo "DELETED:${root} SUCCESSOR:${successor} NEW_ROOT:${successor} NEW_INORDER:${in_str} NEW_PREORDER:${pre_str}"
}

hash_resize() {
    # Tabla de tamano inicial 5. Inserta claves y reporta el factor de
    # carga tras 3 y tras 4 inserciones, y si el umbral 0.7 dispara el
    # redimensionamiento (duplicar tamano + rehash), reproduciendo el
    # ejemplo numerico de la fuente (3 claves: alpha=0.6; 4 claves:
    # alpha=0.8).
    local size=5 threshold_x100=70
    local load_after_3=$((100 * 3 / size))
    local load_after_4=$((100 * 4 / size))
    local resize_triggered=0 new_size=$size
    if ((load_after_4 > threshold_x100)); then
        resize_triggered=1
        new_size=$((size * 2))
    fi
    echo "INITIAL_SIZE:${size} LOAD_AFTER_3_PCT:${load_after_3} LOAD_AFTER_4_PCT:${load_after_4} RESIZE_TRIGGERED_AT_ELEMENT:4 NEW_SIZE:${new_size}"
}

open_addressing_linear() {
    # Sondeo lineal, tabla de tamano 5, hash simple clave%5, insertando
    # 12, 3, 17, 8 en ese orden. Muestra indice final y numero de sondeos
    # de cada clave.
    local -a keys=(12 3 17 8)
    local size=5
    local -a table=(EMPTY EMPTY EMPTY EMPTY EMPTY)
    local -a placements=()
    local k idx probes
    for k in "${keys[@]}"; do
        idx=$((k % size))
        probes=0
        while [[ "${table[idx]}" != "EMPTY" ]]; do
            idx=$(((idx + 1) % size))
            probes=$((probes + 1))
        done
        table[idx]="$k"
        placements+=("${k}->${idx}(probes:${probes})")
    done
    echo "SIZE:${size} KEYS:${keys[*]} PLACEMENTS:${placements[*]}"
}

heap_insert_trace() {
    # Inserta 5,3,8,1,9 en ese orden en un max-heap representado como array
    # (sift-up), mostrando el estado tras cada insercion.
    local -a heap=()
    local -a keys=(5 3 8 1 9)
    local -a states=()
    local k
    for k in "${keys[@]}"; do
        heap+=("$k")
        local i=$((${#heap[@]} - 1))
        while ((i > 0)); do
            local parent=$(((i - 1) / 2))
            if ((heap[parent] < heap[i])); then
                local tmp=${heap[i]}; heap[i]=${heap[parent]}; heap[parent]=$tmp
                i=$parent
            else
                break
            fi
        done
        local state_str
        state_str=$(IFS=,; echo "${heap[*]}")
        states+=("AFTER_${k}:${state_str}")
    done
    echo "${states[*]}"
}

heap_extract_max() {
    # Extrae el maximo del heap [9,8,5,1,3] (resultado de heap_insert_trace)
    # y muestra el heap resultante tras el sift-down.
    local -a heap=(9 8 5 1 3)
    local maximo=${heap[0]}
    local last_idx=$((${#heap[@]} - 1))
    heap[0]=${heap[last_idx]}
    unset 'heap[last_idx]'
    heap=("${heap[@]}")
    local i=0 n=${#heap[@]}
    while true; do
        local left=$((2 * i + 1)) right=$((2 * i + 2)) largest=$i
        if ((left < n)) && ((heap[left] > heap[largest])); then largest=$left; fi
        if ((right < n)) && ((heap[right] > heap[largest])); then largest=$right; fi
        if ((largest == i)); then break; fi
        local tmp=${heap[i]}; heap[i]=${heap[largest]}; heap[largest]=$tmp
        i=$largest
    done
    local heap_str
    heap_str=$(IFS=,; echo "${heap[*]}")
    echo "EXTRACTED_MAX:${maximo} RESULTING_HEAP:${heap_str}"
}

closeness_centrality() {
    # BFS desde el nodo 3 y desde el nodo 4 en el grafo puente (mismo que
    # bridge_node/graph_all_degrees), sumando las distancias a los otros 6
    # nodos para comparar centralidad de cercania.
    local -A adj=([1]="2 3" [2]="1 3" [3]="1 2 4" [4]="3 5" [5]="4 6 7" [6]="5 7" [7]="5 6")

    sum_distances() {
        local start=$1
        local -A dist=()
        dist[$start]=0
        local -a queue=("$start")
        while [[ ${#queue[@]} -gt 0 ]]; do
            local node="${queue[0]}"
            queue=("${queue[@]:1}")
            local n
            for n in ${adj[$node]}; do
                if [[ -z "${dist[$n]:-}" ]]; then
                    dist[$n]=$((dist[$node] + 1))
                    queue+=("$n")
                fi
            done
        done
        local total=0 k
        for k in 1 2 3 4 5 6 7; do
            [[ "$k" == "$start" ]] && continue
            local d=${dist[$k]}
            total=$((total + d))
        done
        echo "$total"
    }

    local sum3 sum4
    sum3=$(sum_distances 3)
    sum4=$(sum_distances 4)
    echo "SUM_DISTANCES_FROM_3:${sum3} SUM_DISTANCES_FROM_4:${sum4}"
}

case "${1:-}" in
    bst_degenerate) bst_degenerate "$2" ;;
    graph_all_degrees) graph_all_degrees ;;
    hash_lookup_miss) hash_lookup_miss "$2" ;;
    bst_search_miss) bst_search_miss "$2" "$3" ;;
    bst_traversals) bst_traversals ;;
    hash_load_factor) hash_load_factor "$2" ;;
    translate_codons) translate_codons "$2" "$3" ;;
    reading_frames) reading_frames "$2" ;;
    matrix_vs_list_memory) matrix_vs_list_memory "$2" "$3" ;;
    graph_bfs_dfs) graph_bfs_dfs ;;
    bridge_node) bridge_node ;;
    perfect_tree_nodes) perfect_tree_nodes "$2" ;;
    bst_delete_two_children) bst_delete_two_children ;;
    hash_resize) hash_resize ;;
    open_addressing_linear) open_addressing_linear ;;
    heap_insert_trace) heap_insert_trace ;;
    heap_extract_max) heap_extract_max ;;
    closeness_centrality) closeness_centrality ;;
    *)
        echo "usage: $0 {bst_degenerate|bst_traversals|hash_load_factor|translate_codons|matrix_vs_list_memory|graph_bfs_dfs|bridge_node|graph_all_degrees|hash_lookup_miss|bst_search_miss|perfect_tree_nodes|bst_delete_two_children|hash_resize|open_addressing_linear|heap_insert_trace|heap_extract_max|closeness_centrality} ARGS" >&2
        exit 2
        ;;
esac
