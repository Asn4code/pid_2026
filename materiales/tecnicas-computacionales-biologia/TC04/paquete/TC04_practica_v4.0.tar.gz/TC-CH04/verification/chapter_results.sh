#!/usr/bin/env bash
# Reproducible checks for TC-CH04 (Representacion en memoria y estructuras
# lineales). Each subcommand prints a single deterministic line so it can
# be diffed against claims.csv/claim_artifacts.csv expected_output.
set -euo pipefail

require_nonneg_int() {
    local n="$1" label="$2"
    if ! [[ "$n" =~ ^[0-9]+$ ]]; then
        echo "ERROR: ${label} espera un entero no negativo, recibido '${n}'" >&2
        exit 3
    fi
}

dynamic_array_growth() {
    # Simula un array dinamico que dobla su capacidad al llenarse. Cuenta
    # cuantas copias de elemento se hacen en total al anadir N elementos
    # uno a uno, para contrastar el total (O(N)) con el peor caso de
    # redimensionar de uno en uno (O(N^2)).
    local n="$1"
    require_nonneg_int "$n" dynamic_array_growth
    local capacity=1 size=0 copies=0 i
    for ((i = 0; i < n; i++)); do
        if ((size == capacity)); then
            copies=$((copies + size))
            capacity=$((capacity * 2))
        fi
        size=$((size + 1))
    done
    local naive=$((n * (n - 1) / 2))
    echo "N:${n} COPIES:${copies} NAIVE_RESIZE_EVERY_STEP_WOULD_BE:${naive}"
}

array_vs_list_access() {
    # Compara el coste de leer M posiciones aleatorias (pero fijas y
    # deterministas: 0, floor(n/3), floor(2n/3), n-1 repetidas) sobre una
    # coleccion de tamano N: en un array cada acceso cuesta 1 paso; en una
    # lista enlazada cuesta (indice+1) pasos porque hay que recorrerla
    # desde la cabeza.
    local n="$1"
    require_nonneg_int "$n" array_vs_list_access
    local -a positions=(0 $((n / 3)) $((2 * n / 3)) $((n - 1)))
    local array_steps=0 list_steps=0 pos
    for pos in "${positions[@]}"; do
        array_steps=$((array_steps + 1))
        list_steps=$((list_steps + pos + 1))
    done
    echo "N:${n} ACCESSES:${#positions[@]} ARRAY_STEPS:${array_steps} LIST_STEPS:${list_steps}"
}

linked_list_pointer_bug() {
    # Simula una lista enlazada de dos nodos [B, C] con arrays paralelos
    # (valor[indice], siguiente[indice]) y un puntero "cabeza" (indice o
    # -1 para null), para reproducir el fallo de insertarInicio_MAL y la
    # correccion.
    local -A valor siguiente
    local cabeza

    # Estado inicial: cabeza -> nodoB -> nodoC -> null
    valor[nodoB]="B"; siguiente[nodoB]="nodoC"
    valor[nodoC]="C"; siguiente[nodoC]="null"
    cabeza="nodoB"

    # Version MAL: mover la cabeza antes de enlazar.
    local cabeza_mal="$cabeza"
    valor[nodoA_mal]="A"
    cabeza_mal="nodoA_mal"                       # 1) L.cabeza <- nuevo (demasiado pronto)
    siguiente[nodoA_mal]="$cabeza_mal"           # 2) nuevo.siguiente <- L.cabeza (ya es el mismo nodo)
    local self_loop="no"
    [[ "${siguiente[nodoA_mal]}" == "nodoA_mal" ]] && self_loop="yes"
    local b_reachable_mal="no"
    [[ "${siguiente[$cabeza_mal]:-}" == "nodoB" ]] && b_reachable_mal="yes"

    # Version correcta: enlazar primero, mover la cabeza despues.
    local cabeza_ok="$cabeza"
    valor[nodoA_ok]="A"
    siguiente[nodoA_ok]="$cabeza_ok"             # 1) nuevo.siguiente <- L.cabeza (la cabeza real)
    cabeza_ok="nodoA_ok"                         # 2) L.cabeza <- nuevo
    local b_reachable_ok="no"
    [[ "${siguiente[$cabeza_ok]}" == "nodoB" ]] && b_reachable_ok="yes"

    echo "MAL_SELF_LOOP:${self_loop} MAL_B_REACHABLE:${b_reachable_mal} OK_B_REACHABLE:${b_reachable_ok}"
}

stack_validate() {
    # Valida el anidamiento de una cadena de parentesis/corchetes con una
    # pila (array indexado usado como pila) y, por separado, con un
    # contador ingenuo, para contrastar ambos veredictos sobre la misma
    # entrada.
    local input="$1"
    local -a stack=()
    local top valid_stack="yes" i c

    for ((i = 0; i < ${#input}; i++)); do
        c="${input:i:1}"
        case "$c" in
            '('|'[')
                stack+=("$c")
                ;;
            ')')
                if [[ ${#stack[@]} -eq 0 ]]; then valid_stack="no"; break; fi
                top="${stack[-1]}"
                unset 'stack[-1]'
                [[ "$top" == '(' ]] || { valid_stack="no"; break; }
                ;;
            ']')
                if [[ ${#stack[@]} -eq 0 ]]; then valid_stack="no"; break; fi
                top="${stack[-1]}"
                unset 'stack[-1]'
                [[ "$top" == '[' ]] || { valid_stack="no"; break; }
                ;;
        esac
    done
    [[ "$valid_stack" == "yes" && ${#stack[@]} -gt 0 ]] && valid_stack="no"

    local counter=0 valid_counter="yes"
    for ((i = 0; i < ${#input}; i++)); do
        c="${input:i:1}"
        case "$c" in
            '('|'[') counter=$((counter + 1)) ;;
            ')'|']') counter=$((counter - 1)) ;;
        esac
        ((counter < 0)) && valid_counter="no"
    done
    [[ "$valid_counter" == "yes" && "$counter" -ne 0 ]] && valid_counter="no"

    echo "INPUT:${input} STACK_VALID:${valid_stack} COUNTER_VALID:${valid_counter}"
}

priority_scan_cost() {
    # Cuenta las comparaciones necesarias para encontrar el maximo de una
    # lista enlazada simple sin ordenar de tamano N (recorrido completo):
    # N-1 comparaciones, no O(1).
    local n="$1"
    require_nonneg_int "$n" priority_scan_cost
    local comparisons=0
    if ((n > 0)); then
        comparisons=$((n - 1))
    fi
    echo "N:${n} COMPARISONS_TO_FIND_MAX:${comparisons}"
}

array_insert_shifts() {
    # Insertar en la posicion POS de un array de SIZE elementos exige
    # desplazar todos los elementos desde POS hasta el final: SIZE-POS
    # desplazamientos.
    local size="$1" pos="$2"
    require_nonneg_int "$size" array_insert_shifts
    require_nonneg_int "$pos" array_insert_shifts
    if ((pos > size)); then
        echo "ERROR: pos ${pos} fuera de rango para un array de tamano ${size}" >&2
        exit 3
    fi
    echo "SIZE:${size} POS:${pos} SHIFTS:$((size - pos))"
}

queue_fifo_order() {
    # Usa un array indexado como cola: enqueue añade al final, dequeue
    # extrae y elimina el primero. Procesa una lista de lecturas separadas
    # por espacios y devuelve el orden en que se extraen.
    local -a queue=($1)
    local -a order=()
    while [[ ${#queue[@]} -gt 0 ]]; do
        order+=("${queue[0]}")
        queue=("${queue[@]:1}")
    done
    echo "ENQUEUED:$1 DEQUEUED:${order[*]}"
}

stack_pop_empty() {
    # Control: hacer pop sobre una pila vacia debe detectarse, no
    # ejecutarse como si hubiera un elemento.
    local -a stack=()
    if [[ ${#stack[@]} -eq 0 ]]; then
        echo "POP_EMPTY_STACK:REJECTED"
    else
        echo "POP_EMPTY_STACK:EXECUTED"
    fi
}

queue_dequeue_empty() {
    # Control: hacer dequeue sobre una cola vacia debe detectarse, no
    # ejecutarse como si hubiera un elemento.
    local -a queue=()
    if [[ ${#queue[@]} -eq 0 ]]; then
        echo "DEQUEUE_EMPTY_QUEUE:REJECTED"
    else
        echo "DEQUEUE_EMPTY_QUEUE:EXECUTED"
    fi
}

to_binary() {
    # Convierte un entero no negativo a su representacion binaria de BITS
    # bits (con ceros a la izquierda), usando solo aritmetica de enteros.
    local n="$1" bits="$2" out="" i bit
    for ((i = bits - 1; i >= 0; i--)); do
        bit=$(( (n >> i) & 1 ))
        out+="$bit"
    done
    echo "$out"
}

twos_complement() {
    # Complemento a dos de -VALUE en BITS bits: invierte los bits de VALUE
    # y suma 1; comprueba que VALUE + resultado, truncado a BITS bits, da 0.
    local value="$1" bits="$2"
    require_nonneg_int "$value" twos_complement
    require_nonneg_int "$bits" twos_complement
    local mask=$(( (1 << bits) - 1 ))
    local inverted=$(( (~value) & mask ))
    local twos=$(( (inverted + 1) & mask ))
    local sum=$(( (value + twos) & mask ))
    echo "VALUE:${value} BITS:${bits} BINARY_VALUE:$(to_binary "$value" "$bits") INVERTED:$(to_binary "$inverted" "$bits") TWOS_COMPLEMENT:$(to_binary "$twos" "$bits") SUM_CHECK:$(to_binary "$sum" "$bits")"
}

float_imprecision() {
    # Suma 0.1+0.2 en coma flotante de doble precision (awk, no Bash puro:
    # Bash solo hace aritmetica entera) y compara con 0.3 exacto.
    local sum
    sum=$(awk 'BEGIN{printf "%.17f", 0.1+0.2}')
    local equal="no"
    awk -v s="$sum" 'BEGIN{if (s+0==0.3) exit 0; exit 1}' && equal="yes"
    echo "SUM_0.1_PLUS_0.2:${sum} EQUALS_0.3:${equal}"
}

array_address_calc() {
    # Direccion del elemento INDEX de un array que empieza en BASE con
    # elementos de tamano SIZE bytes: base + index*size, calculo directo.
    local base="$1" size="$2" index="$3"
    require_nonneg_int "$base" array_address_calc
    require_nonneg_int "$size" array_address_calc
    require_nonneg_int "$index" array_address_calc
    local address=$((base + index * size))
    echo "BASE:${base} ELEMENT_SIZE:${size} INDEX:${index} ADDRESS:${address}"
}

array_out_of_bounds() {
    # Crea un array de tamano N (indices validos 0..N-1) y lee el indice N
    # (uno fuera de rango) para mostrar que Bash devuelve cadena vacia en
    # vez de fallar.
    local n="$1"
    require_nonneg_int "$n" array_out_of_bounds
    local -a arr=()
    local i
    for ((i = 0; i < n; i++)); do arr[i]=$((i * 10)); done
    local value="${arr[$n]:-EMPTY}"
    echo "N:${n} VALID_INDICES:0..$((n - 1)) ACCESS_INDEX_${n}_RESULT:${value}"
}

linked_list_tail_insert() {
    # Construye una lista enlazada de N nodos (arrays paralelos next[])
    # y cuenta los pasos para insertar un nodo nuevo al final: sin puntero
    # de cola, recorriendo desde la cabeza hasta el ultimo nodo.
    local n="$1"
    require_nonneg_int "$n" linked_list_tail_insert
    local -a next=()
    local head=-1 i
    for ((i = 0; i < n; i++)); do
        next[i]=-1
        ((i > 0)) && next[i - 1]=$i
        ((i == 0)) && head=0
    done
    local steps=0 cur=$head
    if ((n > 0)); then
        while [[ "${next[cur]}" != "-1" ]]; do
            cur=${next[cur]}
            steps=$((steps + 1))
        done
        steps=$((steps + 1))
    fi
    echo "N:${n} STEPS_WITHOUT_TAIL_POINTER:${steps} STEPS_WITH_TAIL_POINTER:1"
}

linked_list_search_miss() {
    # Busca un valor ausente (target fuera de rango) en una lista enlazada
    # de N nodos con valores 0,10,20,...: recorre los N nodos completos y
    # termina en null.
    local n="$1"
    require_nonneg_int "$n" linked_list_search_miss
    local -a value=() next=()
    local head=-1 i
    for ((i = 0; i < n; i++)); do
        value[i]=$((i * 10))
        next[i]=-1
        ((i > 0)) && next[i - 1]=$i
        ((i == 0)) && head=0
    done
    local target=$((n * 10 + 999))
    local steps=0 cur=$head found="null"
    while [[ "$cur" != "-1" ]]; do
        steps=$((steps + 1))
        if ((value[cur] == target)); then found="${value[cur]}"; break; fi
        cur=${next[cur]}
    done
    echo "N:${n} TARGET:${target} STEPS:${steps} RESULT:${found}"
}

circular_queue_wrap() {
    # Cola circular de tamano M: encola M elementos (rear da la vuelta),
    # desencola 2, y encola un elemento mas para mostrar en que indice cae
    # gracias a la aritmetica modular.
    local m="$1"
    require_nonneg_int "$m" circular_queue_wrap
    local rear=0 front=0
    local -a data=()
    local i
    for ((i = 0; i < m; i++)); do
        data[rear]=$i
        rear=$(((rear + 1) % m))
    done
    front=$(((front + 2) % m))
    local placed_at=$rear
    data[rear]=99
    echo "M:${m} FRONT_AFTER_2_DEQUEUES:${front} SIXTH_ELEMENT_PLACED_AT_INDEX:${placed_at}"
}

case "${1:-}" in
    dynamic_array_growth) dynamic_array_growth "$2" ;;
    array_vs_list_access) array_vs_list_access "$2" ;;
    linked_list_pointer_bug) linked_list_pointer_bug ;;
    stack_validate) stack_validate "$2" ;;
    array_insert_shifts) array_insert_shifts "$2" "$3" ;;
    queue_fifo_order) queue_fifo_order "$2" ;;
    stack_pop_empty) stack_pop_empty ;;
    queue_dequeue_empty) queue_dequeue_empty ;;
    priority_scan_cost) priority_scan_cost "$2" ;;
    twos_complement) twos_complement "$2" "$3" ;;
    float_imprecision) float_imprecision ;;
    array_address_calc) array_address_calc "$2" "$3" "$4" ;;
    array_out_of_bounds) array_out_of_bounds "$2" ;;
    linked_list_tail_insert) linked_list_tail_insert "$2" ;;
    linked_list_search_miss) linked_list_search_miss "$2" ;;
    circular_queue_wrap) circular_queue_wrap "$2" ;;
    *)
        echo "usage: $0 {dynamic_array_growth|array_vs_list_access|linked_list_pointer_bug|stack_validate|priority_scan_cost|array_insert_shifts|queue_fifo_order|stack_pop_empty|queue_dequeue_empty|twos_complement|float_imprecision|array_address_calc|array_out_of_bounds|linked_list_tail_insert|linked_list_search_miss|circular_queue_wrap} ARGS" >&2
        exit 2
        ;;
esac
