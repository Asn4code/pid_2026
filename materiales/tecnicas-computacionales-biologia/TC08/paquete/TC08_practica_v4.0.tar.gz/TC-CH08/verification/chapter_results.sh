#!/usr/bin/env bash
# Reproducible checks for TC-CH08 (Bayes, cadenas de Markov y modelos
# ocultos). Bash no hace aritmetica de coma flotante, asi que estas
# funciones usan awk (herramienta Bash estandar, ya con precedente en
# TC-CH04/TC-CH07) para los productos y sumas de probabilidades. Cada
# subcomando imprime una sola linea determinista, comparable contra
# claims.csv/claim_artifacts.csv expected_output.
set -euo pipefail

require_nonneg_int() {
    local n="$1" label="$2"
    if ! [[ "$n" =~ ^[0-9]+$ ]]; then
        echo "ERROR: ${label} espera un entero no negativo, recibido '${n}'" >&2
        exit 3
    fi
}

mul() { awk -v a="$1" -v b="$2" 'BEGIN{printf "%.10g", a*b}'; }
ge() { awk -v a="$1" -v b="$2" 'BEGIN{exit !(a>=b)}'; }
gt() { awk -v a="$1" -v b="$2" 'BEGIN{exit !(a>b)}'; }

naive_bayes_classify() {
    # Clasifica SEQ con el modelo entrenado de TC08-SEC-BAYES (Cod/NCod),
    # multiplicando la priori por la verosimilitud de cada base. Una
    # secuencia vacia deja el producto vacio: solo compara las prioris.
    local seq="${1:-}"
    local -A pCod=([A]=0.4 [C]=0.2 [G]=0.3 [T]=0.1)
    local -A pNCod=([A]=0.3 [C]=0.3 [G]=0.2 [T]=0.2)
    local pc=0.45 pn=0.55
    local i ch
    for ((i = 0; i < ${#seq}; i++)); do
        ch="${seq:i:1}"
        pc=$(mul "$pc" "${pCod[$ch]}")
        pn=$(mul "$pn" "${pNCod[$ch]}")
    done
    local winner="NCod"
    ge "$pc" "$pn" && winner="Cod"
    echo "SEQ:${seq:-EMPTY} P_COD:${pc} P_NCOD:${pn} WINNER:${winner}"
}

laplace_smoothing_demo() {
    # Clase Cod entrenada con conteos A=40 C=0 G=30 T=10 (total 80): C
    # nunca aparecio. Compara P(C|Cod) sin suavizar (0) frente a con
    # suavizado de Laplace (sumar 1 a cada uno de los 4 conteos).
    local total=80
    local raw smoothed
    raw=$(awk -v c=0 -v t="$total" 'BEGIN{printf "%.6f", c/t}')
    smoothed=$(awk -v c=0 -v t="$total" 'BEGIN{printf "%.6f", (c+1)/(t+4)}')
    echo "COUNTS:A40_C0_G30_T10 RAW_P_C_GIVEN_COD:${raw} LAPLACE_P_C_GIVEN_COD:${smoothed}"
}

log_space_classify() {
    # Repite la clasificacion de naive_bayes_classify sumando logaritmos
    # en vez de multiplicar probabilidades, para confirmar que da la
    # misma clase ganadora.
    local seq="$1"
    local -A pCod=([A]=0.4 [C]=0.2 [G]=0.3 [T]=0.1)
    local -A pNCod=([A]=0.3 [C]=0.3 [G]=0.2 [T]=0.2)
    local logpc logpn
    logpc=$(awk 'BEGIN{printf "%.10g", log(0.45)}')
    logpn=$(awk 'BEGIN{printf "%.10g", log(0.55)}')
    local i ch
    for ((i = 0; i < ${#seq}; i++)); do
        ch="${seq:i:1}"
        logpc=$(awk -v a="$logpc" -v b="${pCod[$ch]}" 'BEGIN{printf "%.10g", a+log(b)}')
        logpn=$(awk -v a="$logpn" -v b="${pNCod[$ch]}" 'BEGIN{printf "%.10g", a+log(b)}')
    done
    local winner="NCod"
    ge "$logpc" "$logpn" && winner="Cod"
    echo "SEQ:${seq} LOG_P_COD:${logpc} LOG_P_NCOD:${logpn} WINNER:${winner}"
}

markov_sequence_prob() {
    # Probabilidad de SEQ bajo la cadena de Markov de orden 1 de
    # TC08-SEC-MARKOV: inicial del primer simbolo por cada transicion
    # sucesiva.
    local seq="$1"
    local -A init=([A]=0.3 [C]=0.2 [G]=0.3 [T]=0.2)
    local -A trans_A=([A]=0.1 [C]=0.4 [G]=0.4 [T]=0.1)
    local -A trans_C=([A]=0.2 [C]=0.3 [G]=0.1 [T]=0.4)
    local -A trans_G=([A]=0.3 [C]=0.2 [G]=0.3 [T]=0.2)
    local -A trans_T=([A]=0.2 [C]=0.2 [G]=0.3 [T]=0.3)
    local first="${seq:0:1}"
    local p="${init[$first]}"
    local i prev cur step
    for ((i = 1; i < ${#seq}; i++)); do
        prev="${seq:i-1:1}"
        cur="${seq:i:1}"
        case "$prev" in
            A) step="${trans_A[$cur]}" ;;
            C) step="${trans_C[$cur]}" ;;
            G) step="${trans_G[$cur]}" ;;
            T) step="${trans_T[$cur]}" ;;
        esac
        p=$(mul "$p" "$step")
    done
    echo "SEQ:${seq} PROBABILITY:${p}"
}

validate_transition_row() {
    # Fila propuesta desde A: [0.1, 0.5, 0.4, 0.2]. Comprueba si suma 1.
    local -a row=(0.1 0.5 0.4 0.2)
    local sum
    sum=$(awk -v a="${row[0]}" -v b="${row[1]}" -v c="${row[2]}" -v d="${row[3]}" 'BEGIN{printf "%.6f", a+b+c+d}')
    local valid="no"
    awk -v s="$sum" 'BEGIN{d=s-1; if(d<0)d=-d; exit !(d<0.0001)}' && valid="yes"
    echo "ROW:0.1,0.5,0.4,0.2 SUM:${sum} VALID:${valid}"
}

markov_order_params() {
    # Numero de contextos y parametros de un modelo de Markov de orden K
    # sobre un alfabeto de 4 simbolos: 4^K contextos, 4^(K+1) parametros.
    local k="$1"
    require_nonneg_int "$k" markov_order_params
    local contexts=$((4 ** k))
    local params=$((4 ** (k + 1)))
    echo "ORDER:${k} CONTEXTS:${contexts} PARAMETERS:${params}"
}

cpg_vs_bulk_transitions() {
    # Dos secuencias sinteticas de 8 bases con identica composicion
    # (2 A, 2 C, 2 G, 2 T) pero distinto numero de transiciones C->G
    # adyacentes, ilustrando por que un modelo de orden 0 (frecuencias
    # sueltas) es ciego a la diferencia entre ADN general y una isla CpG.
    local bulk="ACTGACTG"
    local cpg="CGCGATAT"

    composition() {
        local seq="$1" i ch
        local -A c=([A]=0 [C]=0 [G]=0 [T]=0)
        for ((i = 0; i < ${#seq}; i++)); do
            ch="${seq:i:1}"
            c[$ch]=$((c[$ch] + 1))
        done
        echo "A${c[A]}C${c[C]}G${c[G]}T${c[T]}"
    }
    count_cg() {
        local seq="$1" i count=0
        for ((i = 0; i < ${#seq} - 1; i++)); do
            if [[ "${seq:i:1}" == "C" && "${seq:i+1:1}" == "G" ]]; then
                count=$((count + 1))
            fi
        done
        echo "$count"
    }

    echo "BULK:${bulk} COMPOSITION:$(composition "$bulk") CG_TRANSITIONS:$(count_cg "$bulk") CPG_ISLAND:${cpg} COMPOSITION:$(composition "$cpg") CG_TRANSITIONS:$(count_cg "$cpg")"
}

viterbi_trace() {
    # Viterbi sobre el HMM de promotores de TC08-SEC-HMM (estados P/NP,
    # alfabeto ACGT), reconstruyendo la ruta completa con punteros. Una
    # secuencia de un solo simbolo no tiene transiciones: la ruta es el
    # estado con mayor delta_0.
    local seq="${1:-}"
    if [[ -z "$seq" ]]; then
        echo "SEQ:EMPTY PATH:"
        return 0
    fi

    local -A pi=([P]=0.5 [NP]=0.5)
    local -A trans_P=([P]=0.7 [NP]=0.3)
    local -A trans_NP=([NP]=0.8 [P]=0.2)
    local -A emis_P=([A]=0.4 [T]=0.3 [C]=0.1 [G]=0.2)
    local -A emis_NP=([A]=0.25 [T]=0.25 [C]=0.25 [G]=0.25)

    local n=${#seq}
    local -a delta_P=() delta_NP=() psi_P=() psi_NP=()
    local c0="${seq:0:1}"
    delta_P[0]=$(mul "${pi[P]}" "${emis_P[$c0]}")
    delta_NP[0]=$(mul "${pi[NP]}" "${emis_NP[$c0]}")
    psi_P[0]="NONE"
    psi_NP[0]="NONE"

    local t ch
    for ((t = 1; t < n; t++)); do
        ch="${seq:t:1}"
        local fromP_toP fromNP_toP fromP_toNP fromNP_toNP
        fromP_toP=$(mul "${delta_P[t - 1]}" "${trans_P[P]}")
        fromNP_toP=$(mul "${delta_NP[t - 1]}" "${trans_NP[P]}")
        fromP_toNP=$(mul "${delta_P[t - 1]}" "${trans_P[NP]}")
        fromNP_toNP=$(mul "${delta_NP[t - 1]}" "${trans_NP[NP]}")

        local best_toP best_prev_toP best_toNP best_prev_toNP
        if ge "$fromP_toP" "$fromNP_toP"; then
            best_toP="$fromP_toP"; best_prev_toP="P"
        else
            best_toP="$fromNP_toP"; best_prev_toP="NP"
        fi
        if ge "$fromP_toNP" "$fromNP_toNP"; then
            best_toNP="$fromP_toNP"; best_prev_toNP="P"
        else
            best_toNP="$fromNP_toNP"; best_prev_toNP="NP"
        fi

        delta_P[t]=$(mul "$best_toP" "${emis_P[$ch]}")
        delta_NP[t]=$(mul "$best_toNP" "${emis_NP[$ch]}")
        psi_P[t]="$best_prev_toP"
        psi_NP[t]="$best_prev_toNP"
    done

    local last=$((n - 1))
    local final_state="NP"
    ge "${delta_P[last]}" "${delta_NP[last]}" && final_state="P"

    local -a path=("$final_state")
    local cur="$final_state" tt
    for ((tt = last; tt > 0; tt--)); do
        if [[ "$cur" == "P" ]]; then
            cur="${psi_P[tt]}"
        else
            cur="${psi_NP[tt]}"
        fi
        path=("$cur" "${path[@]}")
    done

    local path_str
    path_str=$(IFS=,; echo "${path[*]}")
    echo "SEQ:${seq} PATH:${path_str}"
}

naive_position_classify() {
    # Clasifica cada posicion de SEQ por separado, comparando solo la
    # emision (sin transiciones), para contrastar con viterbi_trace.
    local seq="$1"
    local -A emis_P=([A]=0.4 [T]=0.3 [C]=0.1 [G]=0.2)
    local -A emis_NP=([A]=0.25 [T]=0.25 [C]=0.25 [G]=0.25)
    local -a path=()
    local i ch
    for ((i = 0; i < ${#seq}; i++)); do
        ch="${seq:i:1}"
        if gt "${emis_P[$ch]}" "${emis_NP[$ch]}"; then
            path+=("P")
        else
            path+=("NP")
        fi
    done
    local path_str
    path_str=$(IFS=,; echo "${path[*]}")
    echo "SEQ:${seq} NAIVE_PATH:${path_str}"
}

case "${1:-}" in
    naive_bayes_classify) naive_bayes_classify "${2:-}" ;;
    laplace_smoothing_demo) laplace_smoothing_demo ;;
    log_space_classify) log_space_classify "$2" ;;
    markov_sequence_prob) markov_sequence_prob "$2" ;;
    validate_transition_row) validate_transition_row ;;
    markov_order_params) markov_order_params "$2" ;;
    cpg_vs_bulk_transitions) cpg_vs_bulk_transitions ;;
    viterbi_trace) viterbi_trace "${2:-}" ;;
    naive_position_classify) naive_position_classify "$2" ;;
    *)
        echo "usage: $0 {naive_bayes_classify|laplace_smoothing_demo|log_space_classify|markov_sequence_prob|validate_transition_row|markov_order_params|cpg_vs_bulk_transitions|viterbi_trace|naive_position_classify} ARGS" >&2
        exit 2
        ;;
esac
