#!/usr/bin/env bash
# Reproducible checks for TC-CH09 (Alineamiento, similitud y busqueda en
# bases de datos). Needleman-Wunsch y Smith-Waterman usan enteros puros
# (match/mismatch/hueco son enteros), asi que van en aritmetica Bash
# nativa $(( )). El E-value de BLAST necesita exponencial de coma
# flotante, asi que usa awk (herramienta Bash estandar, ya con precedente
# en TC-CH04/TC-CH07/TC-CH08). Cada subcomando imprime una sola linea
# determinista, comparable contra claims.csv/claim_artifacts.csv
# expected_output.
set -euo pipefail

# needleman_wunsch X Y [MATCH] [MISMATCH] [GAP]
# Alineamiento global por programacion dinamica (recurrencia de
# TC09-SEC-NW). MISMATCH y GAP se pasan ya con signo negativo. Imprime
# el score optimo y el alineamiento reconstruido por retroceso de
# punteros (diagonal antes que arriba antes que izquierda en caso de
# empate, para que la salida sea reproducible).
needleman_wunsch() {
    local x="$1" y="$2" match="${3:-1}" mismatch="${4:--1}" gap="${5:--2}"
    local n=${#x} m=${#y}
    declare -A F P
    F[0,0]=0
    local i j
    for ((i = 1; i <= n; i++)); do F[$i,0]=$((i * gap)); P[$i,0]=U; done
    for ((j = 1; j <= m; j++)); do F[0,$j]=$((j * gap)); P[0,$j]=L; done
    for ((i = 1; i <= n; i++)); do
        for ((j = 1; j <= m; j++)); do
            local xi=${x:i-1:1} yj=${y:j-1:1} sub
            if [[ "$xi" == "$yj" ]]; then sub=$match; else sub=$mismatch; fi
            local diag=$((F[$((i - 1)),$((j - 1))] + sub))
            local up=$((F[$((i - 1)),$j] + gap))
            local left=$((F[$i,$((j - 1))] + gap))
            local best=$diag ptr=D
            if ((up > best)); then best=$up; ptr=U; fi
            if ((left > best)); then best=$left; ptr=L; fi
            F[$i,$j]=$best
            P[$i,$j]=$ptr
        done
    done
    local score=${F[$n,$m]}
    local ax="" ay=""
    i=$n; j=$m
    while ((i > 0 || j > 0)); do
        local ptr=${P[$i,$j]}
        if [[ "$ptr" == "D" ]]; then
            ax="${x:i-1:1}${ax}"; ay="${y:j-1:1}${ay}"; i=$((i - 1)); j=$((j - 1))
        elif [[ "$ptr" == "U" ]]; then
            ax="${x:i-1:1}${ax}"; ay="-${ay}"; i=$((i - 1))
        else
            ax="-${ax}"; ay="${y:j-1:1}${ay}"; j=$((j - 1))
        fi
    done
    echo "X:${x} Y:${y} MATCH:${match} MISMATCH:${mismatch} GAP:${gap} SCORE:${score} ALIGN_X:${ax} ALIGN_Y:${ay}"
}

# smith_waterman X Y [MATCH] [MISMATCH] [GAP]
# Alineamiento local (recurrencia de TC09-SEC-SW): suelo en 0, retroceso
# desde la celda de score maximo hasta llegar a una celda con score 0.
smith_waterman() {
    local x="$1" y="$2" match="${3:-1}" mismatch="${4:--1}" gap="${5:--2}"
    local n=${#x} m=${#y}
    declare -A H P
    local i j bi=0 bj=0 bscore=0
    for ((i = 0; i <= n; i++)); do H[$i,0]=0; done
    for ((j = 0; j <= m; j++)); do H[0,$j]=0; done
    for ((i = 1; i <= n; i++)); do
        for ((j = 1; j <= m; j++)); do
            local xi=${x:i-1:1} yj=${y:j-1:1} sub
            if [[ "$xi" == "$yj" ]]; then sub=$match; else sub=$mismatch; fi
            local diag=$((H[$((i - 1)),$((j - 1))] + sub))
            local up=$((H[$((i - 1)),$j] + gap))
            local left=$((H[$i,$((j - 1))] + gap))
            local best=0 ptr=Z
            if ((diag > best)); then best=$diag; ptr=D; fi
            if ((up > best)); then best=$up; ptr=U; fi
            if ((left > best)); then best=$left; ptr=L; fi
            H[$i,$j]=$best
            P[$i,$j]=$ptr
            if ((best > bscore)); then bscore=$best; bi=$i; bj=$j; fi
        done
    done
    local ax="" ay=""
    i=$bi; j=$bj
    while ((i > 0 && j > 0)) && [[ "${P[$i,$j]:-Z}" != "Z" ]]; do
        local ptr=${P[$i,$j]}
        if [[ "$ptr" == "D" ]]; then
            ax="${x:i-1:1}${ax}"; ay="${y:j-1:1}${ay}"; i=$((i - 1)); j=$((j - 1))
        elif [[ "$ptr" == "U" ]]; then
            ax="${x:i-1:1}${ax}"; ay="-${ay}"; i=$((i - 1))
        else
            ax="-${ax}"; ay="${y:j-1:1}${ay}"; j=$((j - 1))
        fi
    done
    echo "X:${x} Y:${y} MATCH:${match} MISMATCH:${mismatch} GAP:${gap} SCORE:${bscore} ALIGN_X:${ax} ALIGN_Y:${ay} START:${i},${j} END:${bi},${bj}"
}

# recompute_alignment_score ALIGN_X ALIGN_Y [MATCH] [MISMATCH] [GAP]
# Comprobacion independiente: recalcula el score sumando caracter a
# caracter sobre el alineamiento ya reconstruido, sin volver a llenar la
# matriz de programacion dinamica. Sirve para confirmar needleman_wunsch
# o smith_waterman con una propiedad distinta del procedimiento que las
# genero (ver TC09-SEC-NW).
recompute_alignment_score() {
    local ax="$1" ay="$2" match="${3:-1}" mismatch="${4:--1}" gap="${5:--2}"
    local n=${#ax} score=0 i cx cy
    for ((i = 0; i < n; i++)); do
        cx="${ax:i:1}"; cy="${ay:i:1}"
        if [[ "$cx" == "-" || "$cy" == "-" ]]; then
            score=$((score + gap))
        elif [[ "$cx" == "$cy" ]]; then
            score=$((score + match))
        else
            score=$((score + mismatch))
        fi
    done
    echo "ALIGN_X:${ax} ALIGN_Y:${ay} RECOMPUTED_SCORE:${score}"
}

# affine_gap_cost LENGTH OPEN EXTEND
# Coste de un hueco afin de LENGTH posiciones: una apertura mas
# (LENGTH-1) extensiones (TC09-SEC-GAPS).
affine_gap_cost() {
    local k="$1" go="$2" ge="$3"
    local cost=$((go + (k - 1) * ge))
    echo "LENGTH:${k} OPEN:${go} EXTEND:${ge} COST:${cost}"
}

# validate_affine_gap_params OPEN EXTEND
# Un modelo de huecos afin exige apertura y extension negativas y que la
# apertura penalice mas que la extension (|OPEN|>|EXTEND|); si no, abrir
# muchos huecos cortos nunca sale mas caro que uno largo y el modelo
# pierde su proposito.
validate_affine_gap_params() {
    local go="$1" ge="$2"
    local ago=${go#-} age=${ge#-}
    local valid="no"
    if ((go < 0 && ge < 0 && ago > age)); then valid="yes"; fi
    echo "OPEN:${go} EXTEND:${ge} VALID:${valid}"
}

# blast_evalue K LAMBDA M N S
# E-value aproximado de BLAST, E approx K*m*n*e^(-lambda*S)
# (TC09-SEC-BLAST). K y lambda son parametros estadisticos del esquema de
# puntuacion, M la longitud de la consulta, N el tamano de la base y S el
# score bruto del hit.
blast_evalue() {
    local K="$1" lambda="$2" m="$3" n="$4" S="$5"
    awk -v K="$K" -v lam="$lambda" -v m="$m" -v n="$n" -v S="$S" \
        'BEGIN{printf "K:%s LAMBDA:%s M:%s N:%s S:%s EVALUE:%.6f\n", K, lam, m, n, S, K*m*n*exp(-lam*S)}'
}

# validate_fasta_header "HEADER"
# Comprueba que una linea de cabecera FASTA tiene el formato minimo
# reproducible (TC09-SEC-DATABASES): empieza por '>' y el primer token
# tras el '>' -el identificador o numero de accesion- no esta vacio.
validate_fasta_header() {
    local header="${1:-}"
    if [[ "${header:0:1}" != ">" ]]; then
        echo "STATUS:INVALID REASON:missing_leading_gt"
        return 0
    fi
    local rest="${header:1}"
    local accession="${rest%% *}"
    local description="${rest#* }"
    if [[ -z "$accession" ]]; then
        echo "STATUS:INVALID REASON:empty_accession"
        return 0
    fi
    if [[ "$description" == "$rest" ]]; then
        description=""
    fi
    echo "STATUS:VALID ACCESSION:${accession} DESCRIPTION:${description}"
}

case "${1:-}" in
    needleman_wunsch) needleman_wunsch "${2:-}" "${3:-}" "${4:-1}" "${5:--1}" "${6:--2}" ;;
    smith_waterman) smith_waterman "${2:-}" "${3:-}" "${4:-1}" "${5:--1}" "${6:--2}" ;;
    recompute_alignment_score) recompute_alignment_score "${2:-}" "${3:-}" "${4:-1}" "${5:--1}" "${6:--2}" ;;
    affine_gap_cost) affine_gap_cost "$2" "$3" "$4" ;;
    validate_affine_gap_params) validate_affine_gap_params "$2" "$3" ;;
    blast_evalue) blast_evalue "$2" "$3" "$4" "$5" "$6" ;;
    validate_fasta_header) validate_fasta_header "${2:-}" ;;
    *)
        echo "usage: $0 {needleman_wunsch|smith_waterman|recompute_alignment_score|affine_gap_cost|validate_affine_gap_params|blast_evalue|validate_fasta_header} ARGS" >&2
        exit 2
        ;;
esac
