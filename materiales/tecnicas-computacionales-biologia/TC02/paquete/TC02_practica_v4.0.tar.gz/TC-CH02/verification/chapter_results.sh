#!/usr/bin/env bash
# Oráculo reproducible de TC-CH02. Cada subcomando imprime un único valor
# determinista que claim_artifacts.csv compara con expected_output.
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
regex_case="$chapter/data/tc02_caso_regex.fasta"

case "${1:-}" in
  truncate_on_redirect)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    printf 'primero\n' > "$tmp/f.txt"
    printf 'segundo\n' > "$tmp/f.txt"
    cat "$tmp/f.txt"
    ;;

  separate_stderr)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    { echo salida; echo error 1>&2; } > "$tmp/out.txt" 2> "$tmp/err.txt"
    printf 'OUT:%s ERR:%s\n' "$(cat "$tmp/out.txt")" "$(cat "$tmp/err.txt")"
    ;;

  pipeline_exit_status)
    set +e
    ( set -o pipefail; false | cat >/dev/null ); with_pipefail=$?
    ( set +o pipefail; false | cat >/dev/null ); without_pipefail=$?
    set -e
    printf 'WITHOUT:%d WITH:%d\n' "$without_pipefail" "$with_pipefail"
    ;;

  fasta_header_count)
    grep -c '^>' "$regex_case"
    ;;

  grep_count_vs_occurrences)
    tmp=$(mktemp)
    trap 'rm -f "$tmp"' EXIT
    printf 'ATATCC\n' > "$tmp"
    c=$(grep -c 'AT' "$tmp")
    o=$(grep -o 'AT' "$tmp" | wc -l | tr -d ' ')
    printf 'LINES:%s OCCURRENCES:%s\n' "$c" "$o"
    ;;

  regex_positive_negative)
    caso_uno=$(sed -n '2p' "$regex_case" | grep -E -c 'N{2,}' || true)
    caso_dos=$(sed -n '5p' "$regex_case" | grep -E -c 'N{2,}' || true)
    printf 'CASO_UNO:%s CASO_DOS:%s\n' "$caso_uno" "$caso_dos"
    ;;

  awk_gff_exones)
    gff="$chapter/data/tc02_anotacion.gff"
    awk -F'\t' '$3 == "exon" { n++; suma += $5 - $4 + 1 }
                 END { printf "EXONES:%d LONGITUD_TOTAL:%d MEDIA:%.1f\n", n, suma, suma/n }' "$gff"
    awk -F'\t' '$3 == "gene" { split($9, campos, ";"); split(campos[2], nombre, "=")
                                printf "%s\t%d\n", nombre[2], $5 - $4 + 1 }' "$gff"
    ;;

  cut_field)
    linea=$(printf 'a\tb\tc\n')
    defecto=$(printf '%s\n' "$linea" | cut -f2)
    erroneo=$(printf '%s\n' "$linea" | cut -d',' -f2)
    printf 'DEFECTO:%s DELIMITADOR_ERRONEO:%s\n' "$defecto" "$erroneo"
    ;;

  uniq_needs_sort)
    tmp=$(mktemp)
    trap 'rm -f "$tmp"' EXIT
    printf 'x\ny\nx\n' > "$tmp"
    plain=$(uniq "$tmp" | wc -l | tr -d ' ')
    sorted=$(sort "$tmp" | uniq | wc -l | tr -d ' ')
    printf 'PLAIN:%s SORTED:%s\n' "$plain" "$sorted"
    ;;

  tr_case)
    printf 'acgt\n' | tr 'a-z' 'A-Z'
    ;;

  syntax_check)
    tmp=$(mktemp)
    trap 'rm -f "$tmp"' EXIT
    printf '#!/usr/bin/env bash\nif [ 1 -eq 1 ]; then echo ok\n' > "$tmp"
    if bash -n "$tmp" 2>/dev/null; then echo SYNTAX_UNEXPECTED_OK; else echo SYNTAX_ERROR_DETECTED; fi
    ;;

  set_u_catches_typo)
    tmp=$(mktemp)
    trap 'rm -f "$tmp"' EXIT
    printf '#!/usr/bin/env bash\nset -u\nmi_variable=1\necho "$mi_variabel"\n' > "$tmp"
    if bash "$tmp" >/dev/null 2>&1; then echo TYPO_NOT_CAUGHT; else echo TYPO_CAUGHT; fi
    ;;

  quoting_matters)
    file="$chapter/data/corpus/notas campo.txt"
    count_unquoted() { printf '%d\n' "$#"; }
    # shellcheck disable=SC2086
    unquoted=$(count_unquoted $file)
    quoted=$(count_unquoted "$file")
    printf 'UNQUOTED_ARGS:%s QUOTED_ARGS:%s\n' "$unquoted" "$quoted"
    ;;

  positional_args)
    demo() { printf 'FIRST:%s COUNT:%s\n' "$1" "$#"; }
    demo alpha beta gamma
    ;;

  test_file_exists)
    if [[ -f "$regex_case" ]]; then echo EXISTS; else echo MISSING; fi
    ;;

  numeric_vs_lexicographic)
    a=9 b=10
    num_result=false; [[ "$a" -gt "$b" ]] && num_result=true || true
    lex_result=false; [[ "$a" > "$b" ]] && lex_result=true || true
    printf 'NUMERIC_9_GT_10:%s LEXICOGRAPHIC_9_GT_10:%s\n' "$num_result" "$lex_result"
    ;;

  nullglob_empty_dir)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    (
      cd "$tmp"
      shopt -s nullglob
      with_nullglob=(*.fasta)
      shopt -u nullglob
      without_nullglob=(*.fasta)
      printf 'NULLGLOB_LEN:%d PLAIN_LEN:%d\n' "${#with_nullglob[@]}" "${#without_nullglob[@]}"
    )
    ;;

  awk_nr_nf)
    printf 'a b c\nd e\n' | awk 'END { printf "NR:%d NF_LAST:%d\n", NR, NF }'
    ;;

  awk_assoc_array)
    printf 'AACG\n' | awk '{ for (i=1;i<=length($0);i++) count[substr($0,i,1)]++ } END { for (i=1;i<=4;i++) { s=substr("ACGT",i,1); printf "%s%d",s,count[s]+0 } printf "\n" }'
    ;;

  bridge_counts)
    sequence=AACG
    printf '%s\n' "$sequence" | LC_ALL=C awk '
      { for (i=1; i<=length($0); i++) count[substr($0,i,1)]++ }
      END {
        for (i=1; i<=4; i++) { s=substr("ACGT",i,1); printf "%s:%d ", s, count[s]+0 }
        printf "\n"
      }'
    ;;

  combined_short_options)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'one two\nthree four\n' > "$tmp"
    separate=$(wc -l -w < "$tmp" | tr -s ' ' | sed 's/^ //')
    combined=$(wc -lw < "$tmp" | tr -s ' ' | sed 's/^ //')
    if [ "$separate" = "$combined" ]; then echo SAME; else echo DIFFERENT; fi
    ;;

  variable_assignment_spacing)
    unset DEMO_VAR 2>/dev/null || true
    DEMO_VAR=hola
    ok_result="$DEMO_VAR"
    set +e
    ( DEMO_VAR = hola ) 2>/tmp/tc02_spacing_err.$$
    bad_ec=$?
    set -e
    rm -f /tmp/tc02_spacing_err.$$
    if [ "$ok_result" = "hola" ] && [ "$bad_ec" -ne 0 ]; then
      echo "NOSPACE_OK SPACE_FAILS"
    else
      echo "UNEXPECTED"
    fi
    ;;

  brace_disambiguation)
    NOMBRE=demo
    with_braces="${NOMBRE}_sufijo"
    without_braces="${NOMBRE_sufijo:-VACIO}"
    printf 'WITH:%s WITHOUT:%s\n' "$with_braces" "$without_braces"
    ;;

  command_substitution)
    result=$(printf 'hola')
    printf 'CAPTURED:%s\n' "$result"
    ;;

  arithmetic_expansion)
    printf '%d\n' "$(( 7 / 2 ))"
    ;;

  single_quote_literal)
    HOME_BACKUP=Xyz
    # shellcheck disable=SC2016
    echo '$HOME_BACKUP'
    ;;

  double_quote_expands_blocks_split)
    value="dos palabras"
    count_args() { printf '%d\n' "$#"; }
    unquoted=$(count_args $value)
    quoted=$(count_args "$value")
    printf 'UNQUOTED:%s QUOTED:%s\n' "$unquoted" "$quoted"
    ;;

  backslash_escape)
    HOME_BACKUP=Xyz
    echo \$HOME_BACKUP
    ;;

  grep_context)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'match\nb\nc\n' > "$tmp"
    grep -A1 'match' "$tmp" | wc -l | tr -d ' '
    ;;

  grep_word_boundary)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'ATG\nAT here\n' > "$tmp"
    lines_plain=$(grep -c 'AT' "$tmp")
    lines_word=$(grep -wc 'AT' "$tmp")
    printf 'PLAIN:%s WORD:%s\n' "$lines_plain" "$lines_word"
    ;;

  grep_exact_line)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'AT\nATG\n' > "$tmp"
    grep -xc 'AT' "$tmp"
    ;;

  grep_multiple_patterns)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'has A\nhas T\nhas neither\n' > "$tmp"
    via_e=$(grep -e 'A' -e 'T' "$tmp" | wc -l | tr -d ' ')
    via_ere=$(grep -E 'A|T' "$tmp" | wc -l | tr -d ' ')
    if [ "$via_e" = "$via_ere" ]; then echo SAME; else echo DIFFERENT; fi
    ;;

  grep_fixed_string)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'A.C\nAGC\n' > "$tmp"
    as_regex=$(grep -c 'A.C' "$tmp")
    as_fixed=$(grep -Fc 'A.C' "$tmp")
    printf 'REGEX:%s FIXED:%s\n' "$as_regex" "$as_fixed"
    ;;

  regex_dot_escape)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'AGC\nA.C\n' > "$tmp"
    dot_matches=$(grep -Ec 'A.C' "$tmp")
    escaped_matches=$(grep -Ec 'A\.C' "$tmp")
    printf 'DOT:%s ESCAPED:%s\n' "$dot_matches" "$escaped_matches"
    ;;

  regex_posix_class_and_negation)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'abc123\n' > "$tmp"
    alpha=$(grep -Eo '[[:alpha:]]+' "$tmp")
    digit=$(grep -Eo '[[:digit:]]+' "$tmp")
    negated=$(grep -Eo '[^0-9]+' "$tmp")
    printf 'ALPHA:%s DIGIT:%s NEGATED:%s\n' "$alpha" "$digit" "$negated"
    ;;

  sed_first_match_only)
    printf 'AA' | sed 's/A/X/'
    printf '\n'
    ;;

  sed_global_flag)
    printf 'AA' | sed 's/A/X/g'
    printf '\n'
    ;;

  sed_custom_delimiter)
    printf '/usr/old\n' | sed 's#/usr/old#/usr/new#'
    ;;

  sed_addressing)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'a\nb\nc\nd\n' > "$tmp"
    line2=$(sed -n '2s/b/X/p' "$tmp")
    range=$(sed -n '2,3s/./Y/p' "$tmp" | tr -d '\n')
    printf 'LINE2:%s RANGE:%s\n' "$line2" "$range"
    ;;

  sed_delete_blank_lines)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'a\n\nb\n\nc\n' > "$tmp"
    sed '/^$/d' "$tmp" | wc -l | tr -d ' '
    ;;

  empty_var_passes_set_u)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    cat > "$tmp" <<'SCRIPT'
#!/usr/bin/env bash
set -u
VARIABLE=""
: "${VARIABLE}/*"
echo NO_SETU_ERROR
SCRIPT
    bash "$tmp"
    ;;

  destructive_dry_run)
    show_target() {
      local var="$1"
      printf '%s\n' "${var}/*"
    }
    defined=$(show_target "resultados")
    empty=$(show_target "")
    printf 'DEFINED:%s EMPTY:%s\n' "$defined" "$empty"
    ;;

  sed_inplace_backup)
    tmp=$(mktemp); trap 'rm -f "$tmp" "$tmp.bak"' EXIT
    printf 'original\n' > "$tmp"
    sed -i.bak 's/original/modificado/' "$tmp"
    backup_content=$(cat "$tmp.bak")
    current_content=$(cat "$tmp")
    printf 'BACKUP:%s CURRENT:%s\n' "$backup_content" "$current_content"
    ;;

  line_separators)
    ( true && echo AND_RAN ) 2>/dev/null || echo AND_SKIPPED
    ( false && echo AND_RAN2 ) 2>/dev/null || echo AND_SKIPPED2
    ( true || echo OR_SKIPPED )
    ( false || echo OR_RAN )
    ;;

  append_does_not_truncate)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'primero\n' > "$tmp"
    printf 'segundo\n' >> "$tmp"
    cat "$tmp" | tr '\n' '|'
    echo
    ;;

  test_operators_string_file_numeric)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    file_result=MISSING
    [[ -f "$tmp" ]] && file_result=EXISTS
    empty_result=NOTEMPTY
    var=""
    [[ -z "$var" ]] && empty_result=EMPTY
    num_result=FALSE
    (( 5 > 3 )) && num_result=TRUE
    printf 'FILE:%s STRING:%s NUMERIC:%s\n' "$file_result" "$empty_result" "$num_result"
    ;;

  for_loop_both_styles)
    out1=""
    for i in 1 2 3; do out1="${out1}${i}"; done
    out2=""
    for ((i=1; i<=3; i+=1)); do out2="${out2}${i}"; done
    if [ "$out1" = "$out2" ]; then echo SAME; else echo "DIFFERENT $out1 $out2"; fi
    ;;

  while_read_counts_lines)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'a\nb\nc\n' > "$tmp"
    count=0
    while IFS= read -r _line; do
      count=$((count + 1))
    done < "$tmp"
    echo "$count"
    ;;

  break_and_continue)
    out_break=""
    for i in 1 2 3 4 5; do
      if [ "$i" -eq 3 ]; then break; fi
      out_break="${out_break}${i}"
    done
    out_continue=""
    for i in 1 2 3 4 5; do
      if [ $((i % 2)) -eq 0 ]; then continue; fi
      out_continue="${out_continue}${i}"
    done
    printf 'BREAK:%s CONTINUE:%s\n' "$out_break" "$out_continue"
    ;;

  function_define_and_call)
    saludar() { printf 'Hola %s' "$1"; }
    saludar "Ana"
    echo
    ;;

  function_return_vs_output)
    dar_estado() { return 7; }
    dar_texto() { printf 'texto'; }
    set +e
    dar_estado
    estado=$?
    set -e
    texto=$(dar_texto)
    printf 'ESTADO:%s TEXTO:%s\n' "$estado" "$texto"
    ;;

  brace_expansion_range_and_list)
    range="$(echo {1..5})"
    list="$(echo {A,B}.txt)"
    printf 'RANGE:%s LIST:%s\n' "$range" "$list"
    ;;

  string_slice_and_substitute)
    var="secuencia"
    slice="${var:0:3}"
    first_sub="${var/e/E}"
    all_sub="${var//e/E}"
    printf 'SLICE:%s FIRST:%s ALL:%s\n' "$slice" "$first_sub" "$all_sub"
    ;;

  string_prefix_suffix_removal)
    var="file_sample.fasta"
    no_prefix="${var#file_}"
    no_suffix="${var%.fasta}"
    printf 'NOPREFIX:%s NOSUFFIX:%s\n' "$no_prefix" "$no_suffix"
    ;;

  sed_delete_insert_append_change)
    tmp=$(mktemp); trap 'rm -f "$tmp"' EXIT
    printf 'a\n\nb\nc\nd\n' > "$tmp"
    deleted=$(sed '/^$/d' "$tmp" | wc -l | tr -d ' ')
    inserted=$(printf 'x\ny\n' | sed '1i\NUEVO')
    appended=$(printf 'x\ny\n' | sed '1a\NUEVO')
    changed=$(printf 'x\ny\n' | sed '1c\NUEVO')
    printf 'DELETED_LINES:%s INSERT_FIRST:%s APPEND_SECOND:%s CHANGE_FIRST:%s\n' \
      "$deleted" "$(echo "$inserted" | head -1)" "$(echo "$appended" | sed -n '2p')" "$(echo "$changed" | head -1)"
    ;;

  awk_custom_field_separator)
    printf 'a,b,c\n' | awk -F',' '{ print $2 }'
    ;;

  awk_arithmetic_accumulate)
    printf '1\n2\n3\n' | awk '{ suma += $1 } END { print suma }'
    ;;

  awk_match_operator)
    printf 'ATG\nCCC\n' | awk '$1 ~ /^A/ { print "MATCH:" $1 } $1 !~ /^A/ { print "NOMATCH:" $1 }' | tr '\n' '|'
    echo
    ;;

  awk_length_substr)
    printf 'ATGCGT\n' | awk '{ print length($0), substr($0, 2, 3) }'
    ;;

  awk_sub_gsub)
    first=$(printf 'AA\n' | awk '{ n = sub(/A/, "X", $0); print $0, n }')
    all=$(printf 'AA\n' | awk '{ n = gsub(/A/, "X", $0); print $0, n }')
    printf 'FIRST:%s ALL:%s\n' "$first" "$all"
    ;;

  awk_dash_v)
    awk -v etiqueta="prueba" 'BEGIN { print etiqueta }'
    ;;

  *)
    echo "usage: chapter_results.sh {subcommand}" >&2
    exit 2
    ;;
esac
