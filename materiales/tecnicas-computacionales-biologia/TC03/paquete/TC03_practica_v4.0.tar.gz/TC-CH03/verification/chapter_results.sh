#!/usr/bin/env bash
# Reproducible checks for TC-CH03 (Algoritmos, complejidad y estrategias de
# resolución). Each subcommand prints a single deterministic line so it can
# be diffed against claims.csv/claim_artifacts.csv expected_output.
set -euo pipefail

require_nonneg_int() {
    # Control de entrada: rechaza n negativo o no numerico con un mensaje
    # claro en vez de dejar que falle de forma opaca en la aritmetica Bash.
    local n="$1" label="$2"
    if ! [[ "$n" =~ ^[0-9]+$ ]]; then
        echo "ERROR: ${label} espera un entero no negativo, recibido '${n}'" >&2
        exit 3
    fi
}

classify_single() {
    # Algoritmo A: un bucle simple 1..N. Cuenta operaciones elementales:
    # establecer i (1) + N * (comparar, multiplicar, echo, sumar, reasignar i).
    local n="$1" i ops=1
    for ((i = 1; i <= n; i++)); do
        ops=$((ops + 5))
    done
    echo "OPS:${ops}"
}

classify_nested() {
    # Algoritmo B: bucle exterior 1..N, interior 1..i (triangular).
    # Cuenta las vueltas totales del bucle interior: N(N+1)/2.
    local n="$1" i j ops=0
    for ((i = 1; i <= n; i++)); do
        for ((j = 1; j <= i; j++)); do
            ops=$((ops + 1))
        done
    done
    echo "OPS:${ops}"
}

classify_halving() {
    # Bucle que reduce n a la mitad (division entera) hasta llegar a 1.
    local n="$1" steps=0
    while ((n > 1)); do
        n=$((n / 2))
        steps=$((steps + 1))
    done
    echo "STEPS:${steps}"
}

dominant_term_share() {
    # 3n^2 + 500n + 200 frente al termino dominante COMPLETO 3n^2 (con su
    # constante), para mostrar que ese termino se acerca al 100% del valor
    # total cuando n crece. Comparar contra n^2 sin la constante seria un
    # error: esa razon converge a 1/3, no a casi el 100% (hallazgo de la
    # revision adversarial de C6, ver audit/C6_OLA_REVIEW.md).
    local n="$1" total leading
    total=$((3 * n * n + 500 * n + 200))
    leading=$((3 * n * n))
    local pct=$((100 * leading / total))
    echo "TOTAL:${total} LEADING_TERM_SHARE_PCT:${pct}"
}

fib_naive() {
    # Fibonacci recursivo sin memoizar. Cada llamada usa $(...) para combinar
    # las dos ramas, lo que crea una subshell por llamada; una variable normal
    # no sobreviviria a esa subshell, asi que cada llamada anota el valor de
    # n que recibio en un fichero temporal en vez de en una variable de shell.
    local n="$1"
    echo "$n" >>"$FIB_CALLS_FILE"
    if ((n <= 1)); then
        echo "$n"
        return
    fi
    local a b
    a=$(fib_naive $((n - 1)))
    b=$(fib_naive $((n - 2)))
    echo $((a + b))
}

fib_naive_calls() {
    local n="$1" value calls calls_for_2
    require_nonneg_int "$n" fib_naive_calls
    FIB_CALLS_FILE=$(mktemp)
    value=$(fib_naive "$n")
    calls=$(wc -l <"$FIB_CALLS_FILE")
    calls_for_2=$(grep -cx 2 "$FIB_CALLS_FILE")
    rm -f "$FIB_CALLS_FILE"
    echo "FIB(${n}):${value} CALLS:${calls} CALLS_FOR_FIB2:${calls_for_2}"
}

fib_memo_calls() {
    # Fibonacci memoizado. La cache (array asociativo) tampoco sobrevive a
    # las subshells de $(...) entre llamadas recursivas, asi que en vez de
    # memoizar dentro de la recursion se calcula iterativamente de abajo
    # arriba: es la misma idea de programacion dinamica (guardar cada
    # subproblema una sola vez) sin depender de estado compartido entre
    # subshells. "computations" cuenta cuantos valores nuevos se calculan,
    # que es exactamente n+1 (fib(0)..fib(n)), cada uno una sola vez.
    local n="$1"
    require_nonneg_int "$n" fib_memo_calls
    local -a table
    table[0]=0
    local computations=1
    if ((n >= 1)); then
        table[1]=1
        computations=$((computations + 1))
    fi
    local k
    for ((k = 2; k <= n; k++)); do
        table[k]=$((table[k - 1] + table[k - 2]))
        computations=$((computations + 1))
    done
    echo "FIB(${n}):${table[n]} COMPUTATIONS:${computations}"
}

greedy_change_1_3_4() {
    # Cambio de moneda voraz (mayor moneda que quepa primero) con
    # denominaciones {4,3,1} para el objetivo dado. Cuenta monedas usadas.
    local target="$1" remaining="$1" coins=0 used=()
    for denom in 4 3 1; do
        while ((remaining >= denom)); do
            remaining=$((remaining - denom))
            coins=$((coins + 1))
            used+=("$denom")
        done
    done
    echo "TARGET:${target} COINS:${coins} USED:${used[*]}"
}

time_compare_verdict() {
    # Compara el tiempo real de fib_naive (recursion sin memoizar, con
    # coste exponencial en el numero de subshells que abre) frente a la
    # tabla ascendente fib_memo_calls (coste lineal) para el mismo n.
    # El veredicto (mas lento o no) es estable entre maquinas aunque los
    # milisegundos exactos no lo sean; por eso el artefacto fija el
    # veredicto, no los tiempos absolutos.
    local n="$1" t0 t1 t2 t3 naive_ms memo_ms
    FIB_CALLS_FILE=$(mktemp)
    t0=$(date +%s%N)
    fib_naive "$n" >/dev/null
    t1=$(date +%s%N)
    rm -f "$FIB_CALLS_FILE"
    t2=$(date +%s%N)
    fib_memo_calls "$n" >/dev/null
    t3=$(date +%s%N)
    naive_ms=$((((t1 - t0)) / 1000000))
    memo_ms=$((((t3 - t2)) / 1000000))
    local verdict="no"
    ((naive_ms > memo_ms)) && verdict="yes"
    echo "NAIVE_SLOWER_THAN_MEMO:${verdict}"
}

control_reject_invalid() {
    # Comprueba que require_nonneg_int rechaza una entrada dada sin abortar
    # este script completo: la llamada que falla va dentro de un ( ... )
    # usado como condicion de un if, el unico contexto en el que `set -e`
    # no propaga el fallo del subshell hacia el script que lo invoca.
    local bad="$1"
    if (require_nonneg_int "$bad" control_test) 2>/dev/null; then
        echo "REJECTED:no"
    else
        echo "REJECTED:yes"
    fi
}

optimal_change_1_3_4() {
    # Solucion optima conocida para el objetivo 6 con {1,3,4}: 3+3, 2 monedas.
    local target="$1"
    if ((target == 6)); then
        echo "TARGET:${target} OPTIMAL_COINS:2 USED:3 3"
    else
        echo "ERROR: no optimal table for target ${target}" >&2
        exit 1
    fi
}

coin_change_dp() {
    # Programacion dinamica ascendente: tabla dp[0..objetivo] con el numero
    # minimo de monedas de {1,3,4} para cada importe, calculada por
    # completo (no solo el valor final) para poder trazarla.
    local objetivo="$1"
    require_nonneg_int "$objetivo" coin_change_dp
    local -a coins=(1 3 4)
    local -a dp=()
    dp[0]=0
    local c
    for ((c = 1; c <= objetivo; c++)); do
        local best=999999 m
        for m in "${coins[@]}"; do
            if ((m <= c)); then
                local candidate=$((dp[c - m] + 1))
                ((candidate < best)) && best=$candidate
            fi
        done
        dp[c]=$best
    done
    local table_str
    table_str=$(IFS=,; echo "${dp[*]}")
    echo "OBJETIVO:${objetivo} DP_TABLE:${table_str} MIN_COINS:${dp[objetivo]}"
}

backtracking_count() {
    # Genera todas las cadenas de longitud L sobre {A,T} sin dos "A"
    # consecutivas. Cuenta los nodos que backtracking realmente visita
    # (podando en cuanto aparece "AA") frente a los 2^L nodos que fuerza
    # bruta visitaria generando todo el espacio y filtrando despues.
    local length="$1"
    require_nonneg_int "$length" backtracking_count
    local visited=0 valid=0
    local -a solutions=()
    backtrack() {
        local prefix="$1"
        visited=$((visited + 1))
        if [[ ${#prefix} -eq $length ]]; then
            valid=$((valid + 1))
            solutions+=("$prefix")
            return
        fi
        local c
        for c in A T; do
            if [[ "$c" == "A" && "${prefix: -1}" == "A" ]]; then
                continue
            fi
            backtrack "${prefix}${c}"
        done
    }
    backtrack ""
    # Arbol completo sin podar: un nodo por cada prefijo de longitud
    # 0..length, es decir 2^0+2^1+...+2^length = 2^(length+1)-1. Es la
    # comparacion justa frente a "visited" (que cuenta el mismo tipo de
    # nodo: prefijos, no solo cadenas completas).
    local full_tree_nodes=$(((2 ** (length + 1)) - 1))
    echo "L:${length} BACKTRACK_NODES_VISITED:${visited} VALID_STRINGS:${valid} FULL_TREE_WITHOUT_PRUNING:${full_tree_nodes} SOLUTIONS:${solutions[*]}"
}

restriction_sites() {
    # Mapa de restriccion por fuerza bruta pura: compara la subcadena SITE
    # contra las n-k+1 posiciones posibles de SEQ sin ningun atajo (ni
    # siquiera abandonar la comparacion en el primer caracter distinto), asi
    # el numero de comparaciones de caracteres coincide exactamente con la
    # cota (n-k+1)*k que da la teoria, en vez de con una version optimizada.
    local seq="$1" site="$2"
    local n=${#seq} k=${#site}
    local -a positions=()
    local comparisons=0 i j match
    for ((i = 0; i + k <= n; i++)); do
        match=1
        for ((j = 0; j < k; j++)); do
            comparisons=$((comparisons + 1))
            [[ "${seq:i+j:1}" != "${site:j:1}" ]] && match=0
        done
        ((match == 1)) && positions+=("$i")
    done
    local expected=$(((n - k + 1) * k))
    echo "SEQ:${seq} SITE:${site} POSITIONS:${positions[*]:-NONE} COMPARISONS:${comparisons} EXPECTED_NK:${expected}"
}

case "${1:-}" in
    classify_single) classify_single "$2" ;;
    classify_nested) classify_nested "$2" ;;
    classify_halving) classify_halving "$2" ;;
    dominant_term_share) dominant_term_share "$2" ;;
    fib_naive_calls) fib_naive_calls "$2" ;;
    fib_memo_calls) fib_memo_calls "$2" ;;
    greedy_change_1_3_4) greedy_change_1_3_4 "$2" ;;
    optimal_change_1_3_4) optimal_change_1_3_4 "$2" ;;
    time_compare_verdict) time_compare_verdict "$2" ;;
    control_reject_invalid) control_reject_invalid "$2" ;;
    backtracking_count) backtracking_count "$2" ;;
    restriction_sites) restriction_sites "$2" "$3" ;;
    coin_change_dp) coin_change_dp "$2" ;;
    *)
        echo "usage: $0 {classify_single|classify_nested|classify_halving|dominant_term_share|fib_naive_calls|fib_memo_calls|greedy_change_1_3_4|optimal_change_1_3_4|time_compare_verdict|control_reject_invalid|backtracking_count|restriction_sites|coin_change_dp} ARGS" >&2
        exit 2
        ;;
esac
