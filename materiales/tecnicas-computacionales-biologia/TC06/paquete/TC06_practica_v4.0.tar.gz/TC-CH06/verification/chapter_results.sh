#!/usr/bin/env bash
# Reproducible checks for TC-CH06 (Busqueda, ordenacion y evaluacion
# experimental). Each subcommand prints a single deterministic line so it
# can be diffed against claims.csv/claim_artifacts.csv expected_output.
set -euo pipefail

require_nonneg_int() {
    local n="$1" label="$2"
    if ! [[ "$n" =~ ^[0-9]+$ ]]; then
        echo "ERROR: ${label} espera un entero no negativo, recibido '${n}'" >&2
        exit 3
    fi
}

binary_search_unsorted() {
    # Aplica busqueda binaria sobre un array NO ordenado fijo y comprueba
    # si encuentra un objetivo que si esta presente, para mostrar que el
    # algoritmo puede fallar sin el requisito de orden previo.
    local -a arr=(7 2 9 1 5)
    local target=1
    local lo=0 hi=$((${#arr[@]} - 1)) found="no"
    while ((lo <= hi)); do
        local mid=$(((lo + hi) / 2))
        if ((arr[mid] == target)); then found="yes"; break
        elif ((arr[mid] < target)); then lo=$((mid + 1))
        else hi=$((mid - 1))
        fi
    done
    echo "ARRAY:${arr[*]} TARGET:${target} PRESENT:yes BINARY_SEARCH_FOUND:${found}"
}

selection_sort_comparisons() {
    # Selection sort sobre una lista descendente de tamano N (peor caso
    # tipico para ilustrar, aunque selection sort es O(n^2) siempre).
    # Cuenta las comparaciones hechas para encontrar el minimo en cada
    # pasada.
    local n="$1"
    require_nonneg_int "$n" selection_sort_comparisons
    local -a arr=()
    local i
    for ((i = 0; i < n; i++)); do arr[i]=$((n - i)); done
    local comparisons=0
    for ((i = 0; i < n; i++)); do
        local min_idx=$i
        local j
        for ((j = i + 1; j < n; j++)); do
            comparisons=$((comparisons + 1))
            ((arr[j] < arr[min_idx])) && min_idx=$j
        done
        local tmp=${arr[i]}; arr[i]=${arr[min_idx]}; arr[min_idx]=$tmp
    done
    local expected=$((n * (n - 1) / 2))
    echo "N:${n} COMPARISONS:${comparisons} EXPECTED_N_TIMES_N_MINUS_1_OVER_2:${expected}"
}

quicksort_fixed_pivot_sorted() {
    # Quicksort con pivote = primer elemento sobre una lista YA ordenada
    # ascendente de tamano N: degenera, cada particion deja un lado vacio.
    # Cuenta las comparaciones totales.
    local n="$1"
    require_nonneg_int "$n" quicksort_fixed_pivot_sorted
    local -a arr=()
    local i
    for ((i = 0; i < n; i++)); do arr[i]=$i; done
    comparisons=0
    qsort() {
        local lo=$1 hi=$2
        ((lo >= hi)) && return
        local pivot=${arr[lo]} i=$((lo + 1)) store=$((lo + 1))
        while ((i <= hi)); do
            comparisons=$((comparisons + 1))
            if ((arr[i] < pivot)); then
                local tmp=${arr[i]}; arr[i]=${arr[store]}; arr[store]=$tmp
                store=$((store + 1))
            fi
            i=$((i + 1))
        done
        local tmp=${arr[lo]}; arr[lo]=${arr[store - 1]}; arr[store - 1]=$tmp
        qsort "$lo" $((store - 2))
        qsort "$store" "$hi"
    }
    if ((n > 0)); then qsort 0 $((n - 1)); fi
    local expected=$((n * (n - 1) / 2))
    echo "N:${n} COMPARISONS:${comparisons} EXPECTED_N_TIMES_N_MINUS_1_OVER_2:${expected}"
}

sort_once_vs_many_searches() {
    # Compara el coste estimado de ordenar una vez (N log2 N) mas B
    # busquedas binarias (B log2 N) frente a B busquedas lineales directas
    # (B*N), usando log2 entero por defecto (floor) para mantener
    # aritmetica de enteros en Bash.
    local n="$1" b="$2"
    require_nonneg_int "$n" sort_once_vs_many_searches
    require_nonneg_int "$b" sort_once_vs_many_searches
    local log2n=0 tmp=$n
    while ((tmp > 1)); do tmp=$((tmp / 2)); log2n=$((log2n + 1)); done
    local cost_sort_then_binary=$((n * log2n + b * log2n))
    local cost_linear_each_time=$((b * n))
    local verdict="linear_cheaper"
    ((cost_sort_then_binary < cost_linear_each_time)) && verdict="sort_then_binary_cheaper"
    echo "N:${n} B:${b} SORT_THEN_BINARY_COST:${cost_sort_then_binary} LINEAR_COST:${cost_linear_each_time} VERDICT:${verdict}"
}

time_compare_sorts() {
    # Compara el tiempo real de selection sort (O(n^2)) frente a merge
    # sort (O(n log n)) sobre la misma entrada (lista descendente de
    # tamano N), devolviendo un veredicto estable entre maquinas en vez de
    # milisegundos absolutos.
    local n="$1"
    require_nonneg_int "$n" time_compare_sorts

    selection_sort_run() {
        local -a a=()
        local i
        for ((i = 0; i < n; i++)); do a[i]=$((n - i)); done
        for ((i = 0; i < n; i++)); do
            local min_idx=$i j
            for ((j = i + 1; j < n; j++)); do ((a[j] < a[min_idx])) && min_idx=$j; done
            local tmp=${a[i]}; a[i]=${a[min_idx]}; a[min_idx]=$tmp
        done
    }

    merge_sort_run() {
        local -a a=()
        local i
        for ((i = 0; i < n; i++)); do a[i]=$((n - i)); done
        msort() {
            local -n arr_ref=$1
            local lo=$2 hi=$3
            ((lo >= hi)) && return
            local mid=$(((lo + hi) / 2))
            msort "$1" "$lo" "$mid"
            msort "$1" $((mid + 1)) "$hi"
            local -a merged=()
            local l=$lo r=$((mid + 1))
            while ((l <= mid && r <= hi)); do
                if ((arr_ref[l] <= arr_ref[r])); then merged+=("${arr_ref[l]}"); l=$((l + 1))
                else merged+=("${arr_ref[r]}"); r=$((r + 1))
                fi
            done
            while ((l <= mid)); do merged+=("${arr_ref[l]}"); l=$((l + 1)); done
            while ((r <= hi)); do merged+=("${arr_ref[r]}"); r=$((r + 1)); done
            local k
            for ((k = 0; k < ${#merged[@]}; k++)); do arr_ref[lo + k]=${merged[k]}; done
        }
        if ((n > 0)); then msort a 0 $((n - 1)); fi
    }

    local t0 t1 t2 t3 selection_ms merge_ms
    t0=$(date +%s%N); selection_sort_run; t1=$(date +%s%N)
    t2=$(date +%s%N); merge_sort_run; t3=$(date +%s%N)
    selection_ms=$((((t1 - t0)) / 1000000))
    merge_ms=$((((t3 - t2)) / 1000000))
    local verdict="no"
    ((selection_ms > merge_ms)) && verdict="yes"
    echo "N:${n} SELECTION_SLOWER_THAN_MERGE:${verdict}"
}

selection_sort_manual() {
    # Selection sort sobre [5,2,8,1,3] (ejercicio 2 del legacy), contando
    # comparaciones para contrastar con el conteo manual del estudiante.
    local -a arr=(5 2 8 1 3)
    local n=${#arr[@]} comparisons=0 i
    for ((i = 0; i < n; i++)); do
        local min_idx=$i j
        for ((j = i + 1; j < n; j++)); do
            comparisons=$((comparisons + 1))
            ((arr[j] < arr[min_idx])) && min_idx=$j
        done
        local tmp=${arr[i]}; arr[i]=${arr[min_idx]}; arr[min_idx]=$tmp
    done
    echo "INPUT:5,2,8,1,3 SORTED:${arr[*]} COMPARISONS:${comparisons}"
}

empty_and_single_sort() {
    # Comprueba que selection_sort_comparisons y quicksort_fixed_pivot_sorted
    # no fallan sobre listas vacia y de un solo elemento (casos limite).
    local out_empty_sel out_single_sel out_empty_qs out_single_qs
    out_empty_sel=$(selection_sort_comparisons 0)
    out_single_sel=$(selection_sort_comparisons 1)
    out_empty_qs=$(quicksort_fixed_pivot_sorted 0)
    out_single_qs=$(quicksort_fixed_pivot_sorted 1)
    echo "EMPTY_SELECTION:${out_empty_sel} SINGLE_SELECTION:${out_single_sel} EMPTY_QUICKSORT:${out_empty_qs} SINGLE_QUICKSORT:${out_single_qs}"
}

binary_search_empty() {
    # Busqueda binaria sobre un array vacio: debe informar "no encontrado"
    # sin fallar, no lanzar un error de indice fuera de rango.
    local -a arr=()
    local lo=0 hi=-1 found="no"
    while ((lo <= hi)); do
        found="yes"
        break
    done
    echo "ARRAY_SIZE:0 BINARY_SEARCH_RESULT:${found}"
}

linear_search_average() {
    # Simula la busqueda lineal del elemento situado en cada una de las n
    # posiciones de una coleccion de tamano n, sumando las comparaciones
    # reales necesarias (posicion i necesita i+1 comparaciones) y
    # calculando el promedio: debe coincidir con (n+1)/2.
    local n="$1"
    require_nonneg_int "$n" linear_search_average
    local -a arr=()
    local i
    for ((i = 0; i < n; i++)); do arr[i]=$i; done
    local total=0
    for ((i = 0; i < n; i++)); do
        local target=${arr[i]} comparisons=0 j
        for ((j = 0; j < n; j++)); do
            comparisons=$((comparisons + 1))
            ((arr[j] == target)) && break
        done
        total=$((total + comparisons))
    done
    local avg_x2=0
    ((n > 0)) && avg_x2=$((2 * total / n))
    echo "N:${n} TOTAL_COMPARISONS:${total} AVERAGE_X2:${avg_x2} EXPECTED_AVERAGE_X2:$((n + 1))"
}

binary_search_trace() {
    # Reproduce el ejemplo de la fuente: array ordenado 2,3,5,7,11,13,17,19,
    # objetivo 11. Cuenta los pasos y devuelve el indice hallado.
    local -a arr=(2 3 5 7 11 13 17 19)
    local target=11
    local lo=0 hi=$((${#arr[@]} - 1)) steps=0 found_idx=-1
    while ((lo <= hi)); do
        steps=$((steps + 1))
        local mid=$(((lo + hi) / 2))
        if ((arr[mid] == target)); then found_idx=$mid; break
        elif ((arr[mid] < target)); then lo=$((mid + 1))
        else hi=$((mid - 1))
        fi
    done
    echo "ARRAY:${arr[*]} TARGET:${target} STEPS:${steps} FOUND_INDEX:${found_idx}"
}

bubble_sort_early_exit() {
    # Compara pasadas y comparaciones de bubble sort (con deteccion de
    # pasada-sin-intercambios) sobre una lista ya ordenada de tamano n
    # (mejor caso, deberia terminar en 1 pasada) frente a una lista en
    # orden inverso del mismo tamano (peor caso).
    local n="$1"
    require_nonneg_int "$n" bubble_sort_early_exit

    run_bubble() {
        local -n a=$1
        local len=${#a[@]} comparisons=0 passes=0 swapped=true
        while $swapped; do
            swapped=false
            passes=$((passes + 1))
            local i
            for ((i = 0; i < len - 1; i++)); do
                comparisons=$((comparisons + 1))
                if ((a[i] > a[i + 1])); then
                    local tmp=${a[i]}; a[i]=${a[i + 1]}; a[i + 1]=$tmp
                    swapped=true
                fi
            done
            len=$((len - 1))
        done
        echo "PASSES:${passes} COMPARISONS:${comparisons}"
    }

    local -a sorted=() reversed=()
    local i
    for ((i = 0; i < n; i++)); do sorted[i]=$i; reversed[i]=$((n - 1 - i)); done
    local sorted_result reversed_result
    sorted_result=$(run_bubble sorted)
    reversed_result=$(run_bubble reversed)
    echo "N:${n} SORTED_${sorted_result} REVERSED_${reversed_result}"
}

insertion_sort_adaptive() {
    # Cuenta desplazamientos de insertion sort sobre una lista ya ordenada
    # de tamano n (mejor caso, deberia dar 0) frente a una lista en orden
    # inverso del mismo tamano (peor caso).
    local n="$1"
    require_nonneg_int "$n" insertion_sort_adaptive

    run_insertion() {
        local -n a=$1
        local len=${#a[@]} shifts=0 i
        for ((i = 1; i < len; i++)); do
            local key=${a[i]} j=$((i - 1))
            while ((j >= 0)) && ((a[j] > key)); do
                a[j + 1]=${a[j]}
                shifts=$((shifts + 1))
                j=$((j - 1))
            done
            a[j + 1]=$key
        done
        echo "$shifts"
    }

    local -a sorted=() reversed=()
    local i
    for ((i = 0; i < n; i++)); do sorted[i]=$i; reversed[i]=$((n - 1 - i)); done
    local sorted_shifts reversed_shifts
    sorted_shifts=$(run_insertion sorted)
    reversed_shifts=$(run_insertion reversed)
    echo "N:${n} SORTED_SHIFTS:${sorted_shifts} REVERSED_SHIFTS:${reversed_shifts}"
}

selection_sort_swap_count() {
    # Cuenta comparaciones e intercambios reales de selection sort sobre
    # una lista en orden inverso de tamano n: las comparaciones son
    # O(n^2), los intercambios nunca superan n-1.
    local n="$1"
    require_nonneg_int "$n" selection_sort_swap_count
    local -a arr=()
    local i
    for ((i = 0; i < n; i++)); do arr[i]=$((n - i)); done
    local comparisons=0 swaps=0
    for ((i = 0; i < n; i++)); do
        local min_idx=$i j
        for ((j = i + 1; j < n; j++)); do
            comparisons=$((comparisons + 1))
            ((arr[j] < arr[min_idx])) && min_idx=$j
        done
        if ((min_idx != i)); then
            local tmp=${arr[i]}; arr[i]=${arr[min_idx]}; arr[min_idx]=$tmp
            swaps=$((swaps + 1))
        fi
    done
    local max_possible_swaps=0
    ((n > 0)) && max_possible_swaps=$((n - 1))
    echo "N:${n} COMPARISONS:${comparisons} SWAPS:${swaps} MAX_POSSIBLE_SWAPS:${max_possible_swaps}"
}

merge_two_sorted_halves() {
    # Fusiona dos sublistas fijas ya ordenadas ([1,3,5] y [2,4,6]) con el
    # mecanismo de merge sort (comparar cabezas, copiar la menor, avanzar)
    # y cuenta las comparaciones reales.
    local -a left=(1 3 5) right=(2 4 6)
    local -a merged=()
    local l=0 r=0 comparisons=0
    while ((l < ${#left[@]} && r < ${#right[@]})); do
        comparisons=$((comparisons + 1))
        if ((left[l] <= right[r])); then merged+=("${left[l]}"); l=$((l + 1))
        else merged+=("${right[r]}"); r=$((r + 1))
        fi
    done
    while ((l < ${#left[@]})); do merged+=("${left[l]}"); l=$((l + 1)); done
    while ((r < ${#right[@]})); do merged+=("${right[r]}"); r=$((r + 1)); done
    local IFS=,
    echo "LEFT:1,3,5 RIGHT:2,4,6 MERGED:${merged[*]} COMPARISONS:${comparisons}"
}

bubble_sort_trace() {
    # Traza bubble sort sobre [5,2,8,1,3], imprimiendo el estado del array
    # tras cada pasada completa (incluida la ultima, de confirmacion).
    local -a a=(5 2 8 1 3)
    local len=${#a[@]} swapped=true pass=0
    local -a states=()
    while $swapped; do
        swapped=false
        pass=$((pass + 1))
        local i
        for ((i = 0; i < len - 1; i++)); do
            if ((a[i] > a[i + 1])); then
                local tmp=${a[i]}; a[i]=${a[i + 1]}; a[i + 1]=$tmp
                swapped=true
            fi
        done
        len=$((len - 1))
        local state_str
        state_str=$(IFS=,; echo "${a[*]}")
        states+=("PASS${pass}:${state_str}")
    done
    echo "INPUT:5,2,8,1,3 ${states[*]}"
}

selection_sort_trace() {
    # Traza selection sort sobre [5,2,8,1,3], imprimiendo el estado del
    # array tras cada una de las n-1 pasadas (incluida la ultima, trivial).
    local -a a=(5 2 8 1 3)
    local n=${#a[@]} i
    local -a states=()
    for ((i = 0; i < n - 1; i++)); do
        local min_idx=$i j
        for ((j = i + 1; j < n; j++)); do
            ((a[j] < a[min_idx])) && min_idx=$j
        done
        if ((min_idx != i)); then
            local tmp=${a[i]}; a[i]=${a[min_idx]}; a[min_idx]=$tmp
        fi
        local state_str
        state_str=$(IFS=,; echo "${a[*]}")
        states+=("PASS$((i + 1)):${state_str}")
    done
    echo "INPUT:5,2,8,1,3 ${states[*]}"
}

stability_demo() {
    # Ordena por puntuacion descendente (L1,90) (L2,85) (L3,90) -empate
    # entre L1 y L3- con un metodo estable (insertion sort, solo desplaza
    # si es estrictamente mayor) y uno inestable (seleccion que prefiere el
    # ultimo maximo encontrado en caso de empate).
    local -a labels=(L1 L2 L3) scores=(90 85 90)
    local n=${#labels[@]}

    print_state() {
        local -n lab_ref=$1
        local -n sc_ref=$2
        local out="" k
        for ((k = 0; k < n; k++)); do out+="(${lab_ref[k]},${sc_ref[k]}) "; done
        echo "${out% }"
    }

    local -a lab_s=("${labels[@]}") sc_s=("${scores[@]}")
    local i
    for ((i = 1; i < n; i++)); do
        local klab=${lab_s[i]} ksc=${sc_s[i]} j=$((i - 1))
        while ((j >= 0)) && ((sc_s[j] < ksc)); do
            lab_s[j + 1]=${lab_s[j]}; sc_s[j + 1]=${sc_s[j]}
            j=$((j - 1))
        done
        lab_s[j + 1]=$klab; sc_s[j + 1]=$ksc
    done

    local -a lab_u=("${labels[@]}") sc_u=("${scores[@]}")
    for ((i = 0; i < n - 1; i++)); do
        local max_idx=$i
        for ((j = i + 1; j < n; j++)); do
            ((sc_u[j] >= sc_u[max_idx])) && max_idx=$j
        done
        if ((max_idx != i)); then
            local tl=${lab_u[i]} ts=${sc_u[i]}
            lab_u[i]=${lab_u[max_idx]}; sc_u[i]=${sc_u[max_idx]}
            lab_u[max_idx]=$tl; sc_u[max_idx]=$ts
        fi
    done

    echo "STABLE:$(print_state lab_s sc_s) UNSTABLE:$(print_state lab_u sc_u)"
}

radix_sort_dna() {
    # Radix sort LSD sobre 4 secuencias de ADN de longitud 3, mostrando el
    # resultado tras cada pasada (de la ultima posicion a la primera).
    local -a keys=(GAT ACT GAC ACA)
    local k=3 pos pass=0
    local -a states=()
    for ((pos = k - 1; pos >= 0; pos--)); do
        pass=$((pass + 1))
        local -a order_A=() order_C=() order_G=() order_T=()
        local key ch
        for key in "${keys[@]}"; do
            ch="${key:pos:1}"
            case "$ch" in
                A) order_A+=("$key") ;;
                C) order_C+=("$key") ;;
                G) order_G+=("$key") ;;
                T) order_T+=("$key") ;;
            esac
        done
        keys=("${order_A[@]}" "${order_C[@]}" "${order_G[@]}" "${order_T[@]}")
        local keys_str
        keys_str=$(IFS=,; echo "${keys[*]}")
        states+=("PASS${pass}:${keys_str}")
    done
    echo "INPUT:GAT,ACT,GAC,ACA ${states[*]}"
}

case "${1:-}" in
    binary_search_unsorted) binary_search_unsorted ;;
    selection_sort_comparisons) selection_sort_comparisons "$2" ;;
    quicksort_fixed_pivot_sorted) quicksort_fixed_pivot_sorted "$2" ;;
    sort_once_vs_many_searches) sort_once_vs_many_searches "$2" "$3" ;;
    time_compare_sorts) time_compare_sorts "$2" ;;
    selection_sort_manual) selection_sort_manual ;;
    empty_and_single_sort) empty_and_single_sort ;;
    binary_search_empty) binary_search_empty ;;
    linear_search_average) linear_search_average "$2" ;;
    binary_search_trace) binary_search_trace ;;
    bubble_sort_early_exit) bubble_sort_early_exit "$2" ;;
    insertion_sort_adaptive) insertion_sort_adaptive "$2" ;;
    selection_sort_swap_count) selection_sort_swap_count "$2" ;;
    merge_two_sorted_halves) merge_two_sorted_halves ;;
    bubble_sort_trace) bubble_sort_trace ;;
    selection_sort_trace) selection_sort_trace ;;
    stability_demo) stability_demo ;;
    radix_sort_dna) radix_sort_dna ;;
    *)
        echo "usage: $0 {binary_search_unsorted|selection_sort_comparisons|quicksort_fixed_pivot_sorted|sort_once_vs_many_searches|time_compare_sorts|selection_sort_manual|empty_and_single_sort|binary_search_empty|linear_search_average|binary_search_trace|bubble_sort_early_exit|insertion_sort_adaptive|selection_sort_swap_count|merge_two_sorted_halves|bubble_sort_trace|selection_sort_trace|stability_demo|radix_sort_dna} ARGS" >&2
        exit 2
        ;;
esac
