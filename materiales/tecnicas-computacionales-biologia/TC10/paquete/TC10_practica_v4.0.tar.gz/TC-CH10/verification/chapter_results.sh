#!/usr/bin/env bash
# Reproducible verification checks for TC-CH10 (Redes neuronales para bioinformatica).
# Uses bash and awk for deterministic mathematical computation of forward/backward
# passes, binary cross entropy loss, and gradient descent updates.
set -euo pipefail

# Sigmoid function via awk
# forward_enhancer_pass X1 X2
forward_enhancer_pass() {
    local x1="${1:-1.0}"
    local x2="${2:-0.5}"
    awk -v x1="$x1" -v x2="$x2" '
    function sigmoid(z) { return 1.0 / (1.0 + exp(-z)); }
    BEGIN {
        # Weights and biases for hidden layer
        w11_h1 = 0.5; w12_h1 = -0.3; b_h1 = 0.1;
        w21_h2 = -0.2; w22_h2 = 0.8; b_h2 = -0.2;
        
        # Hidden pre-activations
        z_h1 = (w11_h1 * x1) + (w12_h1 * x2) + b_h1;
        a_h1 = sigmoid(z_h1);
        
        z_h2 = (w21_h2 * x1) + (w22_h2 * x2) + b_h2;
        a_h2 = sigmoid(z_h2);
        
        # Output layer
        w1_out = 0.7; w2_out = -0.4; b_out = 0.2;
        z_out = (w1_out * a_h1) + (w2_out * a_h2) + b_out;
        y_hat = sigmoid(z_out);
        
        printf "X1:%.4f X2:%.4f Z_H1:%.4f A_H1:%.6f Z_H2:%.4f A_H2:%.6f Z_OUT:%.6f Y_HAT:%.6f\n",
               x1, x2, z_h1, a_h1, z_h2, a_h2, z_out, y_hat;
    }'
}

# bce_loss Y_TRUE Y_HAT
bce_loss() {
    local y_true="${1:-1.0}"
    local y_hat="${2:-0.605267}"
    awk -v y="$y_true" -v yh="$y_hat" '
    BEGIN {
        loss = -(y * log(yh) + (1.0 - y) * log(1.0 - yh));
        printf "Y_TRUE:%.1f Y_HAT:%.6f LOSS:%.6f\n", y, yh, loss;
    }'
}

# backward_enhancer_pass X1 X2 Y_TRUE ETA
backward_hidden() {
    # Continua el backward hasta la capa oculta: delta_h, gradientes de W1
    # y los pesos actualizados de la primera capa.
    local x1="${1:-1.0}" x2="${2:-0.5}" y_true="${3:-1.0}" eta="${4:-0.1}"
    awk -v x1="$x1" -v x2="$x2" -v y="$y_true" -v eta="$eta" '
    function sigmoid(z) { return 1.0 / (1.0 + exp(-z)); }
    BEGIN {
        w11 = 0.5; w12 = -0.3; b1 = 0.1;
        w21 = -0.2; w22 = 0.8; b2 = -0.2;
        w1o = 0.7; w2o = -0.4; bo = 0.2;
        zh1 = w11 * x1 + w12 * x2 + b1; ah1 = sigmoid(zh1);
        zh2 = w21 * x1 + w22 * x2 + b2; ah2 = sigmoid(zh2);
        zo = w1o * ah1 + w2o * ah2 + bo; yhat = sigmoid(zo);
        dout = yhat - y;
        dh1 = w1o * dout * ah1 * (1 - ah1);
        dh2 = w2o * dout * ah2 * (1 - ah2);
        printf "DELTA_H1:%.6f DELTA_H2:%.6f\n", dh1, dh2;
        printf "GRAD_W11:%.6f GRAD_W12:%.6f GRAD_W21:%.6f GRAD_W22:%.6f\n", dh1*x1, dh1*x2, dh2*x1, dh2*x2;
        printf "NEW_W11:%.6f NEW_W12:%.6f NEW_W21:%.6f NEW_W22:%.6f\n", w11-eta*dh1*x1, w12-eta*dh1*x2, w21-eta*dh2*x1, w22-eta*dh2*x2;
        printf "NEW_B1:%.6f NEW_B2:%.6f\n", b1-eta*dh1, b2-eta*dh2;
    }'
}

backward_enhancer_pass() {
    local x1="${1:-1.0}"
    local x2="${2:-0.5}"
    local y_true="${3:-1.0}"
    local eta="${4:-0.1}"
    awk -v x1="$x1" -v x2="$x2" -v y="$y_true" -v eta="$eta" '
    function sigmoid(z) { return 1.0 / (1.0 + exp(-z)); }
    BEGIN {
        # Weights and biases
        w11_h1 = 0.5; w12_h1 = -0.3; b_h1 = 0.1;
        w21_h2 = -0.2; w22_h2 = 0.8; b_h2 = -0.2;
        w1_out = 0.7; w2_out = -0.4; b_out = 0.2;
        
        # Forward pass
        z_h1 = (w11_h1 * x1) + (w12_h1 * x2) + b_h1;
        a_h1 = sigmoid(z_h1);
        z_h2 = (w21_h2 * x1) + (w22_h2 * x2) + b_h2;
        a_h2 = sigmoid(z_h2);
        z_out = (w1_out * a_h1) + (w2_out * a_h2) + b_out;
        y_hat = sigmoid(z_out);
        
        # Backward pass
        delta_out = y_hat - y;
        grad_w1_out = delta_out * a_h1;
        grad_w2_out = delta_out * a_h2;
        grad_b_out = delta_out;
        
        # Updated output weights
        new_w1_out = w1_out - (eta * grad_w1_out);
        new_w2_out = w2_out - (eta * grad_w2_out);
        
        printf "DELTA_OUT:%.6f GRAD_W1_OUT:%.6f GRAD_W2_OUT:%.6f NEW_W1_OUT:%.6f NEW_W2_OUT:%.6f\n",
               delta_out, grad_w1_out, grad_w2_out, new_w1_out, new_w2_out;
    }'
}

# learning_rate_perturbation ETA
learning_rate_perturbation() {
    local eta="${1:-0.1}"
    backward_enhancer_pass 1.0 0.5 1.0 "$eta"
}

# zero_input_control
zero_input_control() {
    forward_enhancer_pass 0.0 0.0
}

# saturation_control Z
saturation_control() {
    local z="${1:-10.0}"
    awk -v z="$z" '
    function sigmoid(v) { return 1.0 / (1.0 + exp(-v)); }
    BEGIN {
        sig = sigmoid(z);
        grad = sig * (1.0 - sig);
        printf "Z:%.1f SIGMOID:%.6f GRADIENT:%.8f\n", z, sig, grad;
    }'
}

# Subcommand dispatcher
subcmd="${1:-help}"
shift || true
case "$subcmd" in
    forward_enhancer_pass) forward_enhancer_pass "$@" ;;
    bce_loss) bce_loss "$@" ;;
    backward_enhancer_pass) backward_enhancer_pass "$@" ;;
    backward_hidden) backward_hidden "$@" ;;
    learning_rate_perturbation) learning_rate_perturbation "$@" ;;
    zero_input_control) zero_input_control "$@" ;;
    saturation_control) saturation_control "$@" ;;
    *)
        echo "Usage: $0 {forward_enhancer_pass|bce_loss|backward_enhancer_pass|learning_rate_perturbation|zero_input_control|saturation_control}" >&2
        exit 1
        ;;
esac
