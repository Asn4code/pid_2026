#!/usr/bin/env bash
set -euo pipefail

if (( $# != 1 )); then
  printf 'usage: %s CANDIDATE_SCRIPT\n' "$0" >&2
  exit 64
fi

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
candidate=$1
[[ -f "$candidate" ]] || { printf 'FAIL: candidate_not_found\n' >&2; exit 1; }
if grep -Eq 'TODO-TC07|PENDING' "$candidate"; then
  printf 'FAIL: unfinished_marker\n' >&2
  exit 1
fi
bash -n "$candidate"

temporary=$(mktemp -d)
trap 'rm -rf -- "$temporary"' EXIT
workspace="$temporary/workspace"
bash "$chapter/practice_assets/create_workspace.sh" "$workspace" >/dev/null
cp -- "$candidate" "$workspace/analysis_tc07.sh"
bash "$workspace/check_submission.sh" "$workspace/analysis_tc07.sh" >/dev/null

check_classification() {
  local expected=$1 first=$2 second=$3 tolerance=$4
  local observed
  observed=$(bash "$workspace/analysis_tc07.sh" classify "$first" "$second" "$tolerance")
  [[ "$observed" == "$expected" ]] || {
    printf 'FAIL: classify %s %s %s expected=%s observed=%s\n' \
      "$first" "$second" "$tolerance" "$expected" "$observed" >&2
    exit 1
  }
}

check_classification SAME_H0 1.000000 1.000000 0.000001
check_classification SAME_H0 1.000001 1.000000 0.000001
check_classification SAME_H0 0.999999 1.000000 0.000001
check_classification SAME_H0 1.0000005 1.000000 0.000001
check_classification DIFFERENT_H0 1.000002 1.000000 0.000001
check_classification DIFFERENT_H0 0.999998 1.000000 0.000001
check_classification DIFFERENT_H0 1.000000 1.000002 0.000001
if bash "$workspace/analysis_tc07.sh" classify text 1.0 0.1 >/dev/null 2>&1; then
  printf 'FAIL: nonnumeric_accepted\n' >&2; exit 1
fi
if bash "$workspace/analysis_tc07.sh" classify 1.0 1.0 -0.1 >/dev/null 2>&1; then
  printf 'FAIL: negative_tolerance_accepted\n' >&2; exit 1
fi

output="$temporary/delivery"
bash "$workspace/analysis_tc07.sh" analyze "$workspace/data/tc07_sequences.fasta" "$output" >/dev/null
diff -u "$chapter/instructor_key/expected_summary.tsv" "$output/summary.tsv"
diff -u "$chapter/instructor_key/expected_blocks_w4.tsv" "$output/blocks_w4.tsv"
diff -u "$chapter/instructor_key/expected_blocks_w8.tsv" "$output/blocks_w8.tsv"
diff -u "$chapter/instructor_key/expected_classification.tsv" "$output/classification.tsv"
grep -q '^ENVIRONMENT_OK' "$output/controls.log"
grep -q '^INPUT_SHA256' "$output/controls.log"
[[ $(grep -c $'^CONTROL_.*\tPASS$' "$output/controls.log") -eq 15 ]] || {
  printf 'FAIL: controls_log_incomplete\n' >&2; exit 1
}

# Segundo corpus válido, generado por la prueba docente y distinto del público.
teacher_input="$temporary/teacher_altered.fasta"
printf '%s\n' \
  '>constant teacher-altered' \
  'GGGGGGGGGGGGGGGG' \
  '>uniform teacher-altered' \
  'AAAACCCCGGGGTTTT' \
  '>blocks teacher-altered' \
  'TTTTTTTTGGGGCCCCAAAA' \
  '>interleaved teacher-altered' \
  'ACGTACGTACGTACGTACGT' \
  '>mixed teacher-altered' \
  'CCCCAAAATTTTGGGGCCCC' > "$teacher_input"
teacher_output="$temporary/teacher-delivery"
bash "$workspace/analysis_tc07.sh" analyze "$teacher_input" "$teacher_output" >/dev/null
oracle="$workspace/lib/tc07_public_oracle.sh"
bash "$oracle" summary "$teacher_input" > "$temporary/teacher-summary.tsv"
bash "$oracle" windows "$teacher_input" blocks 4 > "$temporary/teacher-w4.tsv"
bash "$oracle" windows "$teacher_input" blocks 8 > "$temporary/teacher-w8.tsv"
cmp -s "$temporary/teacher-summary.tsv" "$teacher_output/summary.tsv" || { printf 'FAIL: teacher_summary_not_derived_from_input\n' >&2; exit 1; }
cmp -s "$temporary/teacher-w4.tsv" "$teacher_output/blocks_w4.tsv" || { printf 'FAIL: teacher_w4_not_derived_from_input\n' >&2; exit 1; }
cmp -s "$temporary/teacher-w8.tsv" "$teacher_output/blocks_w8.tsv" || { printf 'FAIL: teacher_w8_not_derived_from_input\n' >&2; exit 1; }
teacher_tolerance=$(LC_ALL=C gawk -F '\t' 'NR==2{print $3}' "$teacher_output/classification.tsv")
teacher_blocks=$(LC_ALL=C gawk -F '\t' '$1=="blocks"{print $8}' "$temporary/teacher-summary.tsv")
teacher_interleaved=$(LC_ALL=C gawk -F '\t' '$1=="interleaved"{print $8}' "$temporary/teacher-summary.tsv")
teacher_expected_label=$(bash "$workspace/analysis_tc07.sh" classify "$teacher_blocks" "$teacher_interleaved" "$teacher_tolerance")
teacher_delivered_label=$(LC_ALL=C gawk -F '\t' 'NR==2{print $2}' "$teacher_output/classification.tsv")
[[ "$teacher_expected_label" == "$teacher_delivered_label" ]] || { printf 'FAIL: teacher_classification_not_derived_from_input\n' >&2; exit 1; }
teacher_hash=$(sha256sum "$teacher_input" | LC_ALL=C gawk '{print $1}')
grep -qx $'INPUT_SHA256\t'"$teacher_hash" "$teacher_output/controls.log" || { printf 'FAIL: teacher_input_hash\n' >&2; exit 1; }
cmp -s "$output/summary.tsv" "$teacher_output/summary.tsv" && { printf 'FAIL: teacher_altered_summary_unchanged\n' >&2; exit 1; }
cmp -s "$output/blocks_w4.tsv" "$teacher_output/blocks_w4.tsv" && { printf 'FAIL: teacher_altered_w4_unchanged\n' >&2; exit 1; }
cmp -s "$output/classification.tsv" "$teacher_output/classification.tsv" && { printf 'FAIL: teacher_altered_classification_unchanged\n' >&2; exit 1; }

# Dos desafios docentes elegidos despues de recibir el candidato. La semilla
# impresa permite replay exacto mediante el generador congelado.
teacher_runtime_seed=${TC07_TEACHER_SEED:-$(( ((RANDOM << 15) ^ RANDOM ^ BASHPID) & 2147483647 ))}
(( teacher_runtime_seed > 0 )) || teacher_runtime_seed=1
teacher_runtime_cases="$temporary/runtime-teacher"
runtime_generator="$workspace/lib/tc07_runtime_cases.sh"
bash "$runtime_generator" "$teacher_runtime_seed" "$teacher_runtime_cases" >/dev/null
printf 'RUNTIME_CHALLENGE\tscope=teacher\tseed=%s\tgenerator_sha256=%s\n' \
  "$teacher_runtime_seed" "$(sha256sum "$runtime_generator" | LC_ALL=C gawk '{print $1}')" >&2

validate_teacher_runtime() {
  local input=$1 label=$2 delivery expected tolerance blocks_h interleaved_h
  local expected_label delivered_label input_hash
  delivery="$temporary/teacher-${label}-delivery"
  expected="$temporary/teacher-${label}-expected"
  mkdir "$expected"
  printf 'RUNTIME_INPUT\tscope=teacher\tseed=%s\tcase=%s\tsha256=%s\n' \
    "$teacher_runtime_seed" "$label" "$(sha256sum "$input" | LC_ALL=C gawk '{print $1}')" >&2
  bash "$workspace/analysis_tc07.sh" analyze "$input" "$delivery" >/dev/null
  bash "$oracle" summary "$input" > "$expected/summary.tsv"
  bash "$oracle" windows "$input" blocks 4 > "$expected/blocks_w4.tsv"
  bash "$oracle" windows "$input" blocks 8 > "$expected/blocks_w8.tsv"
  cmp -s "$expected/summary.tsv" "$delivery/summary.tsv" || { printf 'FAIL: %s_summary_not_derived\n' "$label" >&2; exit 1; }
  cmp -s "$expected/blocks_w4.tsv" "$delivery/blocks_w4.tsv" || { printf 'FAIL: %s_w4_not_derived\n' "$label" >&2; exit 1; }
  cmp -s "$expected/blocks_w8.tsv" "$delivery/blocks_w8.tsv" || { printf 'FAIL: %s_w8_not_derived\n' "$label" >&2; exit 1; }
  tolerance=$(LC_ALL=C gawk -F '\t' 'NR==2{print $3}' "$delivery/classification.tsv")
  blocks_h=$(LC_ALL=C gawk -F '\t' '$1=="blocks"{print $8}' "$expected/summary.tsv")
  interleaved_h=$(LC_ALL=C gawk -F '\t' '$1=="interleaved"{print $8}' "$expected/summary.tsv")
  expected_label=$(bash "$workspace/analysis_tc07.sh" classify "$blocks_h" "$interleaved_h" "$tolerance")
  delivered_label=$(LC_ALL=C gawk -F '\t' 'NR==2{print $2}' "$delivery/classification.tsv")
  [[ "$expected_label" == "$delivered_label" ]] || { printf 'FAIL: %s_classification_not_derived\n' "$label" >&2; exit 1; }
  input_hash=$(sha256sum "$input" | LC_ALL=C gawk '{print $1}')
  grep -qx $'INPUT_SHA256\t'"$input_hash" "$delivery/controls.log" || { printf 'FAIL: %s_input_hash\n' "$label" >&2; exit 1; }
}

validate_teacher_runtime "$teacher_runtime_cases/runtime_same.fasta" runtime_same
validate_teacher_runtime "$teacher_runtime_cases/runtime_different.fasta" runtime_different
teacher_runtime_same_label=$(LC_ALL=C gawk -F '\t' 'NR==2{print $2}' "$temporary/teacher-runtime_same-delivery/classification.tsv")
teacher_runtime_different_label=$(LC_ALL=C gawk -F '\t' 'NR==2{print $2}' "$temporary/teacher-runtime_different-delivery/classification.tsv")
[[ "$teacher_runtime_same_label" == SAME_H0 ]] || { printf 'FAIL: teacher_runtime_same_relation\n' >&2; exit 1; }
[[ "$teacher_runtime_different_label" == DIFFERENT_H0 ]] || { printf 'FAIL: teacher_runtime_different_relation\n' >&2; exit 1; }
cmp -s "$temporary/teacher-runtime_same-delivery/summary.tsv" "$temporary/teacher-runtime_different-delivery/summary.tsv" && { printf 'FAIL: teacher_runtime_trivial_summary\n' >&2; exit 1; }

before=$(find "$output" -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | gawk '{print $1}')
if bash "$workspace/analysis_tc07.sh" analyze "$workspace/data/tc07_sequences.fasta" "$output" >/dev/null 2>&1; then
  printf 'FAIL: overwrite_accepted\n' >&2; exit 1
fi
after=$(find "$output" -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | gawk '{print $1}')
[[ "$before" == "$after" ]] || { printf 'FAIL: overwrite_changed_delivery\n' >&2; exit 1; }

printf 'CANDIDATE_SUBMISSION_OK oracle=pass altered_input=pass runtime_cases=4 profiles=pass classification=pass replay=seeded\n'
