#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
analyzer="$chapter/practice_assets/tc07_analyze.sh"
data="$chapter/data/tc07_sequences.fasta"
fail() { printf 'FAIL: %s\n' "$1" >&2; exit 1; }

summary=$(bash "$analyzer" summaries "$data")
expected_summary=$'id\tlength\tA\tC\tG\tT\tprobability_sum\tH0_bits\nconstant\t16\t16\t0\t0\t0\t1.000000\t0.000000\nuniform\t16\t4\t4\t4\t4\t1.000000\t2.000000\nblocks\t16\t4\t4\t4\t4\t1.000000\t2.000000\ninterleaved\t16\t4\t4\t4\t4\t1.000000\t2.000000\nmixed\t24\t12\t4\t4\t4\t1.000000\t1.792481'
[[ "$summary" == "$expected_summary" ]] || fail summary
ids=$(gawk -F '\t' 'NR>1{print $1}' <<< "$summary" | paste -sd, -)
[[ "$ids" == constant,uniform,blocks,interleaved,mixed ]] || fail row_order
gawk -F '\t' 'NR>1 && ($7 < 0.999999 || $7 > 1.000001){exit 1}' <<< "$summary" || fail probability_sum
gawk -F '\t' 'NR>1 && ($8 < -0.000001 || $8 > 2.000001){exit 1}' <<< "$summary" || fail entropy_bounds

pair=$(bash "$analyzer" pair "$data" blocks interleaved)
[[ "$pair" == $'id\tlength\tA\tC\tG\tT\tH0_bits\nblocks\t16\t4\t4\t4\t4\t2.000000\ninterleaved\t16\t4\t4\t4\t4\t2.000000' ]] || fail same_composition_pair
windows4=$(bash "$analyzer" windows "$data" blocks 4)
windows8=$(bash "$analyzer" windows "$data" blocks 8)
[[ $(gawk 'END{print NR-1}' <<< "$windows4") -eq 13 ]] || fail window_count_w4
[[ $(gawk -F '\t' 'NR==2{print $4}' <<< "$windows4") == 0.000000 ]] || fail first_block_window
[[ $(gawk 'END{print NR-1}' <<< "$windows8") -eq 9 ]] || fail window_count_w8
[[ $(gawk -F '\t' 'NR==2{print $4}' <<< "$windows8") == 1.000000 ]] || fail first_w8_entropy

if bash "$analyzer" summaries "$chapter/data/tc07_invalid.fasta" >/dev/null 2>&1; then fail invalid_alphabet; fi
if bash "$analyzer" summaries "$chapter/data/tc07_empty_record.fasta" >/dev/null 2>&1; then fail empty_record; fi
if bash "$analyzer" windows "$data" blocks 0 >/dev/null 2>&1; then fail zero_width; fi
if bash "$analyzer" windows "$data" blocks 17 >/dev/null 2>&1; then fail excessive_width; fi
if bash "$analyzer" pair "$data" blocks missing >/dev/null 2>&1; then fail missing_id; fi

compare="$here/compare_tolerance.sh"
for case in \
  'SAME_H0 1.000000 1.000000 0.000001' \
  'SAME_H0 1.000001 1.000000 0.000001' \
  'SAME_H0 0.999999 1.000000 0.000001' \
  'SAME_H0 1.0000005 1.000000 0.000001' \
  'DIFFERENT_H0 1.000002 1.000000 0.000001' \
  'DIFFERENT_H0 0.999998 1.000000 0.000001' \
  'DIFFERENT_H0 1.000000 1.000002 0.000001'; do
  read -r expected first second tolerance <<< "$case"
  [[ $(bash "$compare" "$first" "$second" "$tolerance") == "$expected" ]] || fail tolerance_case
done
if bash "$compare" text 2.0 0.1 >/dev/null 2>&1; then fail tolerance_nonnumeric; fi
if bash "$compare" 1.0 1.0 -0.1 >/dev/null 2>&1; then fail tolerance_negative; fi

temporary=$(mktemp -d)
trap 'rm -rf -- "$temporary"' EXIT
summary_output="$temporary/summary.tsv"
bash "$analyzer" write-summaries "$data" "$summary_output" >/dev/null
before=$(sha256sum "$summary_output" | gawk '{print $1}')
if bash "$analyzer" write-summaries "$data" "$summary_output" >/dev/null 2>&1; then fail summary_overwrite_status; fi
after=$(sha256sum "$summary_output" | gawk '{print $1}')
[[ "$before" == "$after" ]] || fail summary_overwrite_changed

window_output="$temporary/windows.tsv"
bash "$analyzer" write-windows "$data" blocks 4 "$window_output" >/dev/null
before=$(sha256sum "$window_output" | gawk '{print $1}')
if bash "$analyzer" write-windows "$data" blocks 4 "$window_output" >/dev/null 2>&1; then fail window_overwrite_status; fi
after=$(sha256sum "$window_output" | gawk '{print $1}')
[[ "$before" == "$after" ]] || fail window_overwrite_changed

workspace="$temporary/literal_workspace"
bash "$chapter/practice_assets/create_workspace.sh" "$workspace" >/dev/null
(cd "$workspace" && bash check_environment.sh >/dev/null && sha256sum --check --strict manifest.sha256 >/dev/null && bash bash_recovery.sh >/dev/null)
if bash "$here/test_candidate_submission.sh" "$chapter/practice_assets/analysis_template.sh" >/dev/null 2>&1; then
  fail unfinished_template_accepted
fi
runtime_log="$temporary/runtime-challenges.log"
env -u TC07_PUBLIC_SEED -u TC07_TEACHER_SEED \
  bash "$here/test_candidate_submission.sh" "$chapter/instructor_key/analysis_solution.sh" \
  >/dev/null 2> >(tee "$runtime_log" >&2)
public_runtime_seed=$(LC_ALL=C gawk -F '\t' '$1=="RUNTIME_CHALLENGE" && $2=="scope=public"{sub(/^seed=/,"",$3); print $3}' "$runtime_log")
teacher_runtime_seed=$(LC_ALL=C gawk -F '\t' '$1=="RUNTIME_CHALLENGE" && $2=="scope=teacher"{sub(/^seed=/,"",$3); print $3}' "$runtime_log")
[[ "$public_runtime_seed" =~ ^[1-9][0-9]*$ ]] || fail public_runtime_seed_missing
[[ "$teacher_runtime_seed" =~ ^[1-9][0-9]*$ ]] || fail teacher_runtime_seed_missing
[[ "$public_runtime_seed" != "$teacher_runtime_seed" ]] || fail runtime_seeds_not_independent
[[ $(grep -c $'^RUNTIME_INPUT\tscope=public\t' "$runtime_log") -eq 2 ]] || fail public_runtime_cases_not_logged
[[ $(grep -c $'^RUNTIME_INPUT\tscope=teacher\t' "$runtime_log") -eq 2 ]] || fail teacher_runtime_cases_not_logged
bash "$here/check_workload.sh" >/dev/null

fake_bin="$temporary/fake_bin"
mkdir "$fake_bin"
printf '#!/usr/bin/env bash\nexit 99\n' > "$fake_bin/awk"
chmod +x "$fake_bin/awk"
PATH="$fake_bin:$PATH" bash "$chapter/practice_assets/check_environment.sh" >/dev/null
PATH="$fake_bin:$PATH" bash "$analyzer" summaries "$data" >/dev/null

printf '#!/usr/bin/env bash\nexit 99\n' > "$fake_bin/cmp"
chmod +x "$fake_bin/cmp"
if PATH="$fake_bin:$PATH" bash "$chapter/practice_assets/check_environment.sh" >/dev/null 2>&1; then
  fail hostile_cmp_accepted
fi

bash "$here/test_public_checker_mutants.sh" >/dev/null

runtime_generator="$chapter/practice_assets/tc07_runtime_cases.sh"
bash "$runtime_generator" 424242 "$temporary/replay-a" >/dev/null
bash "$runtime_generator" 424242 "$temporary/replay-b" >/dev/null
diff -ru "$temporary/replay-a" "$temporary/replay-b" >/dev/null || fail runtime_replay_mismatch
bash "$runtime_generator" 424243 "$temporary/replay-c" >/dev/null
replay_a_hash=$(find "$temporary/replay-a" -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | gawk '{print $1}')
replay_c_hash=$(find "$temporary/replay-c" -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | gawk '{print $1}')
[[ "$replay_a_hash" != "$replay_c_hash" ]] || fail runtime_seed_diversity

printf 'PRACTICE_C5_R5_OK distribution=pass candidate=pass oracle=pass runtime_cases=pass replay=pass mutants=pass controls=pass overwrite=pass tolerance=pass environment=pass\n'
