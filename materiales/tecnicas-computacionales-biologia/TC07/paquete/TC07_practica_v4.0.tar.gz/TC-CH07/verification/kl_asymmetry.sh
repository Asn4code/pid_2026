#!/usr/bin/env bash
set -euo pipefail
awk '
function log2(x) { return log(x)/log(2) }
BEGIN {
  p1=0.5; p2=0.5; q1=0.75; q2=0.25
  dpq=p1*log2(p1/q1)+p2*log2(p2/q2)
  dqp=q1*log2(q1/p1)+q2*log2(q2/p2)
  printf "%.6f %.6f\n", dpq, dqp
}'
