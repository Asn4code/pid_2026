#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)

case "${1:-}" in
  windows)
    LC_ALL=C awk 'BEGIN {
      printf "width\tfrequency_step\toverlap\tvariance_at_p_half\n"
      printf "4\t%.6f\t%d\t%.6f\n", 1/4, 3, 0.5*(1-0.5)/4
      printf "8\t%.6f\t%d\t%.6f\n", 1/8, 7, 0.5*(1-0.5)/8
    }'
    ;;
  pseudocount)
    LC_ALL=C awk '
      function log2(x) { return log(x)/log(2) }
      function row(alpha, total, pa, pc, pg, pt, h) {
        total=4+4*alpha
        pa=(3+alpha)/total; pc=(1+alpha)/total
        pg=alpha/total; pt=alpha/total
        h=-(pa*log2(pa)+pc*log2(pc)+pg*log2(pg)+pt*log2(pt))
        printf "%.1f\t%.6f\t%.6f\n", alpha, pa, h
      }
      BEGIN {
        print "alpha\tp_A\tH_bits"
        row(0.5); row(1); row(2)
      }'
    ;;
  mi_null)
    mi=$(bash "$here/mutual_info_2x2.sh" 0.5 0 0 0.5 | LC_ALL=C awk -F '\t' '$1=="MI" {print $2}')
    probability=$(LC_ALL=C awk 'BEGIN {
      outcomes_per_pair=4
      ordered_draws=outcomes_per_pair^2
      diagonal_tables=2
      printf "%.6f", diagonal_tables/ordered_draws
    }')
    printf 'null_event_probability\t%s\nempirical_MI_bits\t%s\n' "$probability" "$mi"
    ;;
  pitfalls)
    fasta=$'>idA\nAAAA\n'
    sequence_symbols=$(LC_ALL=C awk '!/^>/ {gsub(/[^A-Za-z]/,""); n+=length($0)} END {print n+0}' <<< "$fasta")
    naive_letters=$(LC_ALL=C awk '{gsub(/[^A-Za-z]/,""); n+=length($0)} END {print n+0}' <<< "$fasta")
    LC_ALL=C awk -v sequence_symbols="$sequence_symbols" -v naive_letters="$naive_letters" '
      function log2(x) { return log(x)/log(2) }
      BEGIN {
        p1=0.9; p2=0.1
        aligned=p1*log2(p1/0.8)+p2*log2(p2/0.2)
        swapped=p1*log2(p1/0.2)+p2*log2(p2/0.8)
        n_short=10; n_long=1000; h_short=0; h_long=2
        unweighted=(h_short+h_long)/2
        weighted=(n_short*h_short+n_long*h_long)/(n_short+n_long)
        rounded=sprintf("%.2f",1/3)+0
        printf "fasta_sequence_symbols\t%s\n", sequence_symbols
        printf "fasta_naive_letters_with_header\t%s\n", naive_letters
        printf "entropy_unweighted\t%.6f\n", unweighted
        printf "entropy_length_weighted\t%.6f\n", weighted
        printf "kl_aligned\t%.6f\n", aligned
        printf "kl_rows_swapped\t%.6f\n", swapped
        printf "rounded_probability_sum\t%.6f\n", 3*rounded
      }'
    ;;
  alternation)
    sequence='ACACACAC'
    h0=$(bash "$here/entropy0.sh" "$sequence" | LC_ALL=C awk -F '\t' '{print $2}')
    h1=$(LC_ALL=C awk -v sequence="$sequence" '
      function log2(x) { return log(x)/log(2) }
      BEGIN {
        transitions=length(sequence)-1
        for (i=1; i<length(sequence); i++) {
          from=substr(sequence,i,1); to=substr(sequence,i+1,1)
          context[from]++; pair[from SUBSEP to]++
        }
        conditional=0
        for (from in context) {
          local_h=0
          for (key in pair) {
            split(key,parts,SUBSEP)
            if (parts[1]==from) {
              p=pair[key]/context[from]
              local_h-=p*log2(p)
            }
          }
          conditional+=(context[from]/transitions)*local_h
        }
        printf "%.6f", conditional
      }')
    printf 'H0_bits_per_symbol\t%s\nH1_bits_per_symbol\t%s\n' "$h0" "$h1"
    ;;
  *)
    printf 'usage: %s {windows|pseudocount|mi_null|pitfalls|alternation}\n' "$0" >&2
    exit 2
    ;;
esac
