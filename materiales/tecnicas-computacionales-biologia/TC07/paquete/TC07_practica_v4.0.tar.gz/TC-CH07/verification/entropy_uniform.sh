#!/usr/bin/env bash
set -euo pipefail
awk 'BEGIN { p=0.25; h=-4*p*(log(p)/log(2)); printf "%.6f\n", h }'
