#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
figures="$here/../figures"
mkdir -p "$figures"

target=${1:-all}
if [[ "$target" != selfinfo && "$target" != windows && "$target" != all ]]; then
  printf 'usage: %s {selfinfo|windows|all}\n' "$0" >&2
  exit 64
fi

if [[ "$target" == selfinfo || "$target" == all ]]; then
    LC_ALL=C awk 'BEGIN { for (i=1;i<=100;i++) { p=i/100; printf "%.2f\t%.8f\n",p,-log(p)/log(2) } }' > "$figures/TC07-F01-selfinfo.tsv"
    gnuplot <<GNUPLOT
set terminal pdfcairo enhanced color size 12cm,7cm font 'Latin Modern Roman,10'
set output '$figures/TC07-F01-selfinfo.pdf'
set xlabel 'Probabilidad p(x)'; set ylabel 'Autoinformación I(x), bits'
set xrange [0:1]; set yrange [0:7]; set grid; set key off
plot '$figures/TC07-F01-selfinfo.tsv' using 1:2 with lines lw 2 lc rgb '#164e63'
GNUPLOT
  printf 'TC07-F01_OK\n'
fi
if [[ "$target" == windows || "$target" == all ]]; then
    bash "$here/chapter_results.sh" windows_tsv > "$figures/TC07-F03-windows.tsv"
    gnuplot <<GNUPLOT
set terminal pdfcairo enhanced color size 12cm,7cm font 'Latin Modern Roman,10'
set output '$figures/TC07-F03-windows.pdf'
set xlabel 'Inicio de la ventana (w=4)'; set ylabel 'H_0, bits/símbolo'
set xrange [1:9]; set yrange [0:2.1]; set xtics 1; set ytics 0.5; set grid; set key off
plot '$figures/TC07-F03-windows.tsv' using 1:3 with linespoints lw 2 pt 7 lc rgb '#9a3412'
GNUPLOT
  printf 'TC07-F03_OK\n'
fi
