#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
quiet=${1:-}
(cd "$chapter" && sha256sum --check --strict verification/c5_dependencies.sha256 >/dev/null)
if [[ "$quiet" != --quiet ]]; then
  printf 'C5_DEPENDENCIES_OK\n'
fi
