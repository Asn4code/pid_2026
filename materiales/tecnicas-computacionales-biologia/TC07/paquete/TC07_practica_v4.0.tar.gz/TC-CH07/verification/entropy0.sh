#!/usr/bin/env bash
set -euo pipefail

if (( $# == 0 )); then
  printf 'usage: %s SEQUENCE [SEQUENCE ...]\n' "$0" >&2
  exit 64
fi

for sequence in "$@"; do
  if [[ -z "$sequence" ]]; then
    printf 'ERROR: empty sequence\n' >&2
    exit 65
  fi
  if [[ ! "$sequence" =~ ^[ACGT]+$ ]]; then
    printf 'ERROR: expected uppercase A C G or T: %s\n' "$sequence" >&2
    exit 66
  fi
  LC_ALL=C awk -v sequence="$sequence" '
    function log2(x) { return log(x)/log(2) }
    BEGIN {
      for (i=1; i<=length(sequence); i++) count[substr(sequence,i,1)]++
      for (i=1; i<=4; i++) {
        symbol=substr("ACGT",i,1)
        if (count[symbol]>0) {
          p=count[symbol]/length(sequence)
          h-=p*log2(p)
        }
      }
      printf "%s\t%.6f\n", sequence, h
    }'
done
