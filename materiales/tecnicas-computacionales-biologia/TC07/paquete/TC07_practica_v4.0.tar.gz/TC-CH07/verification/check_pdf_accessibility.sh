#!/usr/bin/env bash
# Comprueba a nivel de fuente que el catálogo declara idioma y que toda
# imagen rasterizada usa el envoltorio accesible en vez de \includegraphics
# directo. No valida PDF/UA completo (sin árbol de estructura ni /Marked
# true; ver el comentario junto a \pdfcatalog en theory.tex). GNU/Bash puro,
# sin Python, conforme a la política de lenguaje de Técnicas.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
theory="$here/../theory.tex"

lang_declared=false
grep -qF 'pdfcatalog{/Lang (es-ES)}' "$theory" && lang_declared=true

total_includegraphics=$(grep -c '\\includegraphics' "$theory")
accessible_calls=$(grep -c '\\AccessibleGraphic\[' "$theory")

# El único \includegraphics permitido es el de la propia definición del
# envoltorio; cualquier otro es una imagen sin capa accesible.
bare_uses=$((total_includegraphics - 1))

echo "lang_declared=${lang_declared} accessible_graphic_calls=${accessible_calls} bare_includegraphics_uses=${bare_uses}"

if [[ "${lang_declared}" != true ]]; then
  echo "FAIL: falta /Lang en el catálogo del PDF" >&2
  exit 1
fi
if [[ "${bare_uses}" -ne 0 ]]; then
  echo "FAIL: hay ${bare_uses} uso(s) de \\includegraphics sin pasar por \\AccessibleGraphic" >&2
  exit 1
fi
if [[ "${accessible_calls}" -eq 0 ]]; then
  echo "FAIL: no se registró ninguna llamada a \\AccessibleGraphic" >&2
  exit 1
fi
