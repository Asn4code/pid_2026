#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
analyzer="$chapter/practice_assets/tc07_analyze.sh"
data="$chapter/data/tc07_sequences.fasta"
mode=${1:-}

case "$mode" in
  summary) bash "$analyzer" summaries "$data" ;;
  anchor)
    bash "$analyzer" summaries "$data" | LC_ALL=C gawk -F '\t' '
      $1=="uniform"{u=$8} $1=="constant"{c=$8} $1=="mixed"{m=$8}
      END{print "uniform_H0\t" u; print "constant_H0\t" c; print "mixed_H0\t" m}'
    ;;
  pair) bash "$analyzer" pair "$data" blocks interleaved ;;
  windows)
    w4=$(bash "$analyzer" windows "$data" blocks 4)
    w8=$(bash "$analyzer" windows "$data" blocks 8)
    printf 'w4_count\t%s\n' "$(gawk 'END{print NR-1}' <<< "$w4")"
    printf 'w8_count\t%s\n' "$(gawk 'END{print NR-1}' <<< "$w8")"
    printf 'w4_first_H0\t%s\n' "$(gawk -F '\t' 'NR==2{print $4}' <<< "$w4")"
    printf 'w8_first_H0\t%s\n' "$(gawk -F '\t' 'NR==2{print $4}' <<< "$w8")"
    ;;
  schema) bash "$analyzer" summaries "$data" | LC_ALL=C gawk 'NR==1{print; exit}' ;;
  data_hash) sha256sum "$data" | LC_ALL=C gawk '{print $1}' ;;
  template)
    bash -n "$chapter/practice_assets/analysis_template.sh"
    count=$(grep -c 'TODO-TC07' "$chapter/practice_assets/analysis_template.sh")
    printf 'template_syntax\tPASS\nTODO-TC07_count\t%s\n' "$count"
    ;;
  rubric) LC_ALL=C gawk 'BEGIN{print 30+25+25+10+10}' ;;
  workload) bash "$here/check_workload.sh" ;;
  candidate) bash "$here/test_candidate_submission.sh" "$chapter/instructor_key/analysis_solution.sh" ;;
  controls)
    temporary=$(mktemp -d)
    trap 'rm -rf -- "$temporary"' EXIT
    root="$temporary/TC07-student"
    bash "$chapter/practice_assets/create_workspace.sh" "$root" >/dev/null
    cp -- "$chapter/instructor_key/analysis_solution.sh" "$root/analysis_tc07.sh"
    bash "$root/analysis_tc07.sh" analyze "$root/data/tc07_sequences.fasta" "$temporary/delivery" >/dev/null
    bash "$root/check_submission.sh" "$root/analysis_tc07.sh" >/dev/null
    count=$(grep -c $'^CONTROL_.*\tPASS$' "$temporary/delivery/controls.log")
    [[ "$count" -eq 15 ]] || exit 1
    printf 'CONTROLS_LOG_OK\tcontrols=%s\tinput_hash=pass\n' "$count"
    ;;
  *)
    printf 'usage: %s {summary|anchor|pair|windows|schema|data_hash|template|rubric|workload|candidate|controls}\n' "$0" >&2
    exit 64
    ;;
esac
