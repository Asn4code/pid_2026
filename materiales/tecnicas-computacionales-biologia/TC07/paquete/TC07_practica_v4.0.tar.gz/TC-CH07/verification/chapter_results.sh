#!/usr/bin/env bash
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)

case "${1:-}" in
  selfinfo)
    LC_ALL=C awk 'BEGIN { printf "%.6f %.6f %.6f %.6f %.6f\n", -log(1)/log(2), -log(0.5)/log(2), -log(0.125)/log(2), -log(0.75)/log(2), -log(0.25)/log(2) }'
    ;;
  uniform)
    awk 'BEGIN { p=0.25; printf "%.6f\n", -4*p*log(p)/log(2) }'
    ;;
  uniform_total)
    LC_ALL=C awk 'BEGIN { n=12; p=0.25; h=-4*p*log(p)/log(2); printf "%.6f\n",n*h }'
    ;;
  aacg)
    bash "$here/entropy0.sh" AACG | LC_ALL=C awk -F '\t' '{ print $2 }'
    ;;
  sequences)
    bash "$here/entropy0.sh" AAAA ACGT AAAACCCC ACACACAC | tr '\t' ' '
    ;;
  coin)
    awk 'BEGIN {
      p=0.75
      h=-(p*log(p)/log(2)+(1-p)*log(1-p)/log(2))
      printf "%.6f\n", h
    }'
    ;;
  windows)
    sequence='AAAAACGTACGT'
    width=4
    awk -v sequence="$sequence" -v width="$width" '
      function log2(x) { return log(x)/log(2) }
      BEGIN {
        for (start=1; start<=length(sequence)-width+1; start++) {
          window=substr(sequence,start,width)
          delete count
          for (i=1; i<=width; i++) count[substr(window,i,1)]++
          h=0
          for (symbol in count) {
            p=count[symbol]/width
            h-=p*log2(p)
          }
          printf "%d:%s:%.6f%s", start, window, h, (start==length(sequence)-width+1 ? "\n" : " ")
        }
      }'
    ;;
  windows_tsv)
    sequence='AAAAACGTACGT'
    width=4
    LC_ALL=C awk -v sequence="$sequence" -v width="$width" '
      function log2(x) { return log(x)/log(2) }
      BEGIN {
        print "start\twindow\tH0_bits_per_symbol"
        for (start=1; start<=length(sequence)-width+1; start++) {
          window=substr(sequence,start,width); delete count; h=0
          for (i=1;i<=width;i++) count[substr(window,i,1)]++
          for (i=1;i<=4;i++) { symbol=substr("ACGT",i,1); if (count[symbol]>0) { p=count[symbol]/width; h-=p*log2(p) } }
          printf "%d\t%s\t%.6f\n",start,window,h
        }
      }'
    ;;
  crosskl)
    forward=$(bash "$here/compare_pq.sh" 0.5 0.5 0.75 0.25)
    reverse=$(bash "$here/compare_pq.sh" 0.75 0.25 0.5 0.5)
    LC_ALL=C awk -F '\t' '
      NR==1 { hp=$2 } NR==2 { hpq=$2 } NR==3 { dpq=$2 }
      END { printf "%.6f %.6f %.6f ",hp,hpq,dpq }' <<< "$forward"
    LC_ALL=C awk -F '\t' '$1=="KL_P_Q" { printf "%.6f\n",$2 }' <<< "$reverse"
    ;;
  pseudocount)
    awk '
      function log2(x) { return log(x)/log(2) }
      BEGIN {
        # Counts A=3, C=1, G=0, T=0; add alpha=1 to all four symbols.
        qa=4/8; qc=2/8; qg=1/8; qt=1/8
        h=-(qa*log2(qa)+qc*log2(qc)+qg*log2(qg)+qt*log2(qt))
        printf "%.6f %.6f %.6f %.6f %.6f\n", qa, qc, qg, qt, h
      }'
    ;;
  mutual)
    dep=$(bash "$here/mutual_info_2x2.sh" 0.5 0 0 0.5)
    ind=$(bash "$here/mutual_info_2x2.sh" 0.25 0.25 0.25 0.25)
    LC_ALL=C awk -F '\t' 'NR==1 { printf "%.6f ",$2 }' <<< "$dep"
    LC_ALL=C awk -F '\t' 'NR==1 { printf "%.6f\n",$2 }' <<< "$ind"
    ;;
  total)
    awk 'BEGIN { n=12; h=1.5; printf "%.6f\n", n*h }'
    ;;
  *)
    printf 'usage: %s {selfinfo|uniform|uniform_total|aacg|sequences|coin|windows|windows_tsv|crosskl|pseudocount|mutual|total}\n' "$0" >&2
    exit 2
    ;;
esac
