#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
map="$here/workload_map.tsv"
LC_ALL=C gawk -F '\t' '
  NR==1 {
    expected="section_id\troute\tminutes_min\tminutes_max\tproduct\trubric_criteria"
    if ($0!=expected) exit 2
    next
  }
  {
    if ($3 !~ /^[0-9]+$/ || $4 !~ /^[0-9]+$/ || $3>$4) exit 3
    minimum[$2]+=$3
    maximum[$2]+=$4
    if ($2=="essential") criterion[$6]=1
    product[$5]++
  }
  END {
    required[1]="computation"; required[2]="controls"; required[3]="interpretation"
    required[4]="traceability"; required[5]="defense"
    for (i=1;i<=5;i++) if (!criterion[required[i]]) exit 4
    if (minimum["essential"]!=195 || maximum["essential"]!=270) exit 5
    if (minimum["study"]!=45 || maximum["study"]!=75) exit 6
    if (minimum["reference"]!=30 || maximum["reference"]!=45) exit 7
    print "WORKLOAD_OK\tessential=195-270\tstudy=45-75\treference=30-45\tcriteria=5"
  }
' "$map"
