#!/usr/bin/env bash
set -euo pipefail

if (( $# != 3 )); then
  printf 'usage: %s VALUE_1 VALUE_2 TOLERANCE\n' "$0" >&2
  exit 64
fi

LC_ALL=C gawk -v first="$1" -v second="$2" -v tolerance="$3" '
  function numeric(value) {
    return value ~ /^[-+]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][-+]?[0-9]+)?$/
  }
  function abs(value) { return value < 0 ? -value : value }
  function max4(a,b,c,d) {
    maximum=a
    if (b>maximum) maximum=b
    if (c>maximum) maximum=c
    if (d>maximum) maximum=d
    return maximum
  }
  BEGIN {
    if (!numeric(first) || !numeric(second) || !numeric(tolerance) || tolerance<0) {
      print "ERROR: expected two numeric values and a nonnegative tolerance" > "/dev/stderr"
      exit 65
    }
    difference=abs(first-second)
    scale=max4(1,abs(first),abs(second),abs(tolerance))
    guard=1e-12*scale
    if (difference<=tolerance+guard) print "SAME_H0"
    else print "DIFFERENT_H0"
  }
'
