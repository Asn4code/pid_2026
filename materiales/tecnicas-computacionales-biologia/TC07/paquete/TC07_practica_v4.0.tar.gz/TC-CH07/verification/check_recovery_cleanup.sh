#!/usr/bin/env bash
# Comprueba TC07-A096: bash_recovery.sh no deja rastro en el espacio de
# entrega, trabaja en su propio directorio temporal y lo elimina al salir.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
sandbox=$(mktemp -d)
trap 'rm -rf -- "$sandbox"' EXIT

before=$(find "$sandbox" -mindepth 1 | wc -l | tr -d ' ')
TMPDIR="$sandbox" bash "$here/../practice_assets/bash_recovery.sh" >/dev/null
status=$?
after=$(find "$sandbox" -mindepth 1 | wc -l | tr -d ' ')

echo "exit_status=$status before=$before after=$after clean=$([[ "$after" -eq "$before" ]] && echo True || echo False)"
