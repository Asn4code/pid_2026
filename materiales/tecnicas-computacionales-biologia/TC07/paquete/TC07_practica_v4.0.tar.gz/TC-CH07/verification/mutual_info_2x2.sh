#!/usr/bin/env bash
set -euo pipefail

if (( $# != 4 )); then
  printf 'usage: %s P00 P01 P10 P11\n' "$0" >&2
  exit 64
fi

LC_ALL=C awk -v p00="$1" -v p01="$2" -v p10="$3" -v p11="$4" '
  function log2(x) { return log(x)/log(2) }
  function valid_number(x) { return x ~ /^([0-9]+([.][0-9]*)?|[.][0-9]+)$/ }
  BEGIN {
    if (!valid_number(p00)||!valid_number(p01)||!valid_number(p10)||!valid_number(p11)) exit 65
    p[0,0]=p00; p[0,1]=p01; p[1,0]=p10; p[1,1]=p11
    total=0
    for (x=0;x<2;x++) for (y=0;y<2;y++) { if (p[x,y]<0) exit 66; total+=p[x,y] }
    if ((total-1)^2>1e-12) exit 67
    for (x=0;x<2;x++) for (y=0;y<2;y++) { px[x]+=p[x,y]; py[y]+=p[x,y] }
    for (x=0;x<2;x++) for (y=0;y<2;y++) if (p[x,y]>0) {
      product=px[x]*py[y]
      contribution=p[x,y]*log2(p[x,y]/product)
      mi+=contribution; kl+=contribution
    }
    printf "MI\t%.6f\nKL_JOINT_PRODUCT\t%.6f\n",mi,kl
  }'
