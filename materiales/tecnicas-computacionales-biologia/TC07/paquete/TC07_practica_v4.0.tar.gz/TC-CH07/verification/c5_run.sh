#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
mode=${1:-}

if [[ "$mode" == dependencies ]]; then
  bash "$here/check_c5_dependencies.sh"
  exit 0
fi
bash "$here/check_c5_dependencies.sh" --quiet

case "$mode" in
  environment) bash "$chapter/practice_assets/check_environment.sh" ;;
  summary|anchor|pair|windows|schema|data_hash|rubric|workload|candidate|controls)
    bash "$here/practice_results.sh" "$mode"
    ;;
  full_test|gawk) bash "$here/test_practice_c5.sh" ;;
  workspace) bash "$here/test_pdf_commands.sh" ;;
  public_mutants) bash "$here/test_public_checker_mutants.sh" ;;
  recovery) bash "$chapter/practice_assets/bash_recovery.sh" ;;
  *)
    printf 'usage: %s {dependencies|environment|summary|anchor|pair|windows|schema|data_hash|rubric|workload|candidate|controls|full_test|workspace|public_mutants|gawk|recovery}\n' "$0" >&2
    exit 64
    ;;
esac
