#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
fail() { printf 'FAIL: %s\n' "$1" >&2; exit 1; }

[[ $(bash "$here/entropy0.sh" AAAA ACGT) == $'AAAA\t0.000000\nACGT\t2.000000' ]] || fail entropy0
set +e
no_args_output=$(bash "$here/entropy0.sh" 2>&1)
no_args_status=$?
set -e
[[ $no_args_status -eq 64 ]] || fail no_arguments_status
grep -q '^usage:' <<< "$no_args_output" || fail no_arguments_message
[[ $(bash "$here/entropy_trace.sh" AACG) == $'symbol\tcount\tprobability\tcontribution_bits\nA\t2\t0.500000\t0.500000\nC\t1\t0.250000\t0.500000\nG\t1\t0.250000\t0.500000\nTOTAL\t4\t1.000000\t1.500000' ]] || fail trace
if bash "$here/entropy0.sh" '' >/dev/null 2>&1; then fail empty; fi
if bash "$here/entropy0.sh" ACNT >/dev/null 2>&1; then fail alphabet; fi
[[ $(bash "$here/bridge_counts.sh" AACG) == $'symbol\tcount\nA\t2\nC\t1\nG\t1\nT\t0' ]] || fail bridge
[[ $(bash "$here/compare_pq.sh" 0.5 0.5 0.75 0.25) == $'H_P\t1.000000\nH_PQ\t1.207519\nKL_P_Q\t0.207519\nCHECK\t0.207519' ]] || fail pq
[[ $(bash "$here/mutual_info_2x2.sh" 0.5 0 0 0.5) == $'MI\t1.000000\nKL_JOINT_PRODUCT\t1.000000' ]] || fail mutual
[[ $(bash "$here/audit_edge_cases.sh" windows) == $'width\tfrequency_step\toverlap\tvariance_at_p_half\n4\t0.250000\t3\t0.062500\n8\t0.125000\t7\t0.031250' ]] || fail windows_tradeoff
[[ $(bash "$here/audit_edge_cases.sh" mi_null) == $'null_event_probability\t0.125000\nempirical_MI_bits\t1.000000' ]] || fail mi_null
[[ $(bash "$here/audit_edge_cases.sh" alternation) == $'H0_bits_per_symbol\t1.000000\nH1_bits_per_symbol\t0.000000' ]] || fail alternation
printf 'STUDENT_SCRIPTS_OK\n'
