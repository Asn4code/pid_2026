#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
figures="$here/../figures"
bash "$here/make_figures.sh" all >/dev/null

[[ -s "$figures/TC07-F01-selfinfo.pdf" ]] || exit 1
[[ -s "$figures/TC07-F03-windows.pdf" ]] || exit 1
[[ $(awk 'END {print NR}' "$figures/TC07-F01-selfinfo.tsv") == 100 ]] || exit 1
[[ $(awk 'NR==1 {first=$2} END {if (first>6.64 && first<6.65 && $2==0) print "ok"}' "$figures/TC07-F01-selfinfo.tsv") == ok ]] || exit 1
[[ $(awk 'NR>1 {printf "%s%s",$3,(NR==10?ORS:" ")}' "$figures/TC07-F03-windows.tsv") == '0.000000 0.000000 0.811278 1.500000 2.000000 2.000000 2.000000 2.000000 2.000000' ]] || exit 1
pdftotext "$figures/TC07-F01-selfinfo.pdf" - | grep -q 'Probabilidad'
pdftotext "$figures/TC07-F03-windows.pdf" - | grep -q 'Inicio de la ventana'
printf 'FIGURE_TESTS_OK\n'
