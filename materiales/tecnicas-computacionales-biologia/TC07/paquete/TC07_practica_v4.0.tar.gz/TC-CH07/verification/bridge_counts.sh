#!/usr/bin/env bash
set -euo pipefail
sequence=${1:-AACG}
printf '%s\n' "$sequence" |
LC_ALL=C awk '
{ for (i=1; i<=length($0); i++) count[substr($0,i,1)]++ }
END {
  print "symbol\tcount"
  for (i=1; i<=4; i++) { s=substr("ACGT",i,1); printf "%s\t%d\n",s,count[s]+0 }
}'
