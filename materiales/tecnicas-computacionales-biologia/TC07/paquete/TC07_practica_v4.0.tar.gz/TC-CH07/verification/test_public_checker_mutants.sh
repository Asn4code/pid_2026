#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
solution="$chapter/instructor_key/analysis_solution.sh"
temporary=$(mktemp -d)
trap 'rm -rf -- "$temporary"' EXIT
root="$temporary/TC07-student"
bash "$chapter/practice_assets/create_workspace.sh" "$root" >/dev/null
cp -- "$solution" "$root/.mutation_reference.sh"

signed="$temporary/signed_difference_candidate.sh"
LC_ALL=C sed 's/difference=abs(first-second)/difference=first-second/' "$solution" > "$signed"

inverted="$temporary/inverted_labels_candidate.sh"
LC_ALL=C sed \
  -e 's/print "SAME_H0"/print "__MUTANT_LABEL__"/' \
  -e 's/print "DIFFERENT_H0"/print "SAME_H0"/' \
  -e 's/print "__MUTANT_LABEL__"/print "DIFFERENT_H0"/' \
  "$solution" > "$inverted"

# Candidato autonomo para la regresion docente: valida la ruta recibida, pero
# calcula siempre contra el corpus canonico y falsifica el hash de procedencia.
ignored_private="$temporary/ignored_input_private_candidate.sh"
LC_ALL=C sed \
  -e 's/^  local input=\$1 output_dir=\$2$/  local input=$1 output_dir=$2 received_input=$1\n  "$analyzer" summaries "$received_input" >\/dev\/null || return $?\n  input="$script_dir\/data\/tc07_sequences.fasta"/' \
  -e 's/sha256sum "\$input"/sha256sum "$received_input"/' \
  "$solution" > "$ignored_private"

whitelist_private="$temporary/whitelist_private_candidate.sh"
LC_ALL=C sed \
  -e 's/^  local input=\$1 output_dir=\$2$/  local input=$1 output_dir=$2 received_input=$1 received_hash\n  "$analyzer" summaries "$received_input" >\/dev\/null || return $?\n  received_hash=$(sha256sum "$received_input" | LC_ALL=C gawk '\''{print $1}'\'')\n  case "$received_hash" in\n    35fac74d29076d48410f2db5ffcd66721d2bc60287ca4c777b9e89c017319953|9dde2b60fe1a6dc61520035bce2cb8a302580f7d271cdd6b8d9021ece441ac98|102384ca528aae86ee8be6320f49a0213feea89d0de1039b491134c51877b1e4) ;;\n    *) input="$script_dir\/data\/tc07_sequences.fasta" ;;\n  esac/' \
  -e 's/sha256sum "\$input"/sha256sum "$received_input"/' \
  "$solution" > "$whitelist_private"

expect_public_rejection() {
  local name=$1 candidate=$2 installed="$root/analysis_tc07.sh" log
  log="$temporary/${name}.log"
  cp -- "$candidate" "$installed"
  if bash "$root/check_submission.sh" "$installed" >"$log" 2>&1; then
    printf 'FAIL: public checker accepted %s mutant\n' "$name" >&2
    exit 1
  fi
  if grep -q 'PUBLIC_SUBMISSION_CHECK_OK' "$log"; then
    printf 'FAIL: public checker printed success for %s mutant\n' "$name" >&2
    exit 1
  fi
}

expect_public_rejection signed_difference "$signed"
expect_public_rejection inverted_labels "$inverted"
expect_public_rejection forged_tables "$here/mutants/forged_candidate.sh"
expect_public_rejection coherent_mixed "$here/mutants/coherent_summary_candidate.sh"
expect_public_rejection coherent_constant "$here/mutants/coherent_constant_candidate.sh"
expect_public_rejection ignored_input "$here/mutants/ignores_input_candidate.sh"
expect_public_rejection whitelist_runtime "$here/mutants/whitelist_known_hashes_candidate.sh"
if bash "$here/test_candidate_submission.sh" "$ignored_private" >"$temporary/ignored-private.log" 2>&1; then
  printf 'FAIL: teacher checker accepted ignored-input mutant\n' >&2
  exit 1
fi
grep -q 'CANDIDATE_SUBMISSION_OK' "$temporary/ignored-private.log" && {
  printf 'FAIL: teacher checker printed success for ignored-input mutant\n' >&2
  exit 1
}
if TC07_PUBLIC_SEED=314159 TC07_TEACHER_SEED=271828 \
  bash "$here/test_candidate_submission.sh" "$whitelist_private" >"$temporary/whitelist-private.log" 2>&1; then
  printf 'FAIL: teacher checker accepted whitelist mutant\n' >&2
  exit 1
fi
grep -q 'CANDIDATE_SUBMISSION_OK' "$temporary/whitelist-private.log" && {
  printf 'FAIL: teacher checker printed success for whitelist mutant\n' >&2
  exit 1
}

printf 'PUBLIC_MUTANTS_REJECTED signed_difference=pass inverted_labels=pass forged_tables=pass coherent_mixed=pass coherent_constant=pass ignored_input_public=pass ignored_input_teacher=pass whitelist_runtime=pass whitelist_teacher_suite=pass\n'
