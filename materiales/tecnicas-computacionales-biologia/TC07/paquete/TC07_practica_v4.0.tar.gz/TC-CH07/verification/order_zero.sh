#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' AAAACCCC ACACACAC |
awk '
function log2(x) { return log(x)/log(2) }
{
  delete count
  for (i=1; i<=length($0); i++) count[substr($0,i,1)]++
  h=0
  for (base in count) { p=count[base]/length($0); h-=p*log2(p) }
  value[NR]=h
}
END { printf "%.6f %.6f\n", value[1], value[2] }
'
