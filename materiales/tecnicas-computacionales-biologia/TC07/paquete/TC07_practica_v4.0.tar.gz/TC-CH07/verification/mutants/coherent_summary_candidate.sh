#!/usr/bin/env bash
# Mutante deliberado: altera una fila de summary con valores internamente
# coherentes, pero no derivados del FASTA.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
reference="$here/.mutation_reference.sh"
[[ -x "$reference" ]] || exit 70
[[ $# -ge 1 ]] || exit 64
mode=$1
shift
case "$mode" in
  classify) exec bash "$reference" classify "$@" ;;
  analyze)
    [[ $# -eq 2 ]] || exit 64
    bash "$reference" analyze "$1" "$2" >/dev/null
    temporary=$(mktemp "$2/.coherent-summary.XXXXXX")
    trap 'rm -f -- "$temporary"' EXIT
    LC_ALL=C gawk -F '\t' 'BEGIN{OFS="\t"} $1=="mixed"{$2=24;$3=6;$4=6;$5=6;$6=6;$7="1.000000";$8="2.000000"} {print}' \
      "$2/summary.tsv" > "$temporary"
    mv -- "$temporary" "$2/summary.tsv"
    trap - EXIT
    ;;
  *) exit 64 ;;
esac
