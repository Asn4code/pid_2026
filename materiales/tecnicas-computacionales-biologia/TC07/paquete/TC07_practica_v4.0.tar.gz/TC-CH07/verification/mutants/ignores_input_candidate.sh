#!/usr/bin/env bash
# Mutante deliberado: rechaza FASTA inválidos, pero para toda entrada válida
# calcula con el FASTA canónico y solo falsifica el hash registrado.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
reference="$here/.mutation_reference.sh"
oracle="$here/lib/tc07_public_oracle.sh"
[[ -x "$reference" && -x "$oracle" ]] || exit 70
[[ $# -ge 1 ]] || exit 64
mode=$1
shift
case "$mode" in
  classify) exec bash "$reference" classify "$@" ;;
  analyze)
    [[ $# -eq 2 ]] || exit 64
    input=$1
    output=$2
    if ! bash "$oracle" summary "$input" >/dev/null 2>&1; then
      exec bash "$reference" analyze "$input" "$output"
    fi
    bash "$reference" analyze "$here/data/tc07_sequences.fasta" "$output" >/dev/null
    temporary=$(mktemp "$output/.controls.XXXXXX")
    trap 'rm -f -- "$temporary"' EXIT
    input_hash=$(sha256sum "$input" | LC_ALL=C gawk '{print $1}')
    LC_ALL=C gawk -F '\t' -v hash="$input_hash" 'BEGIN{OFS="\t"} $1=="INPUT_SHA256"{$2=hash} {print}' \
      "$output/controls.log" > "$temporary"
    mv -- "$temporary" "$output/controls.log"
    trap - EXIT
    ;;
  *) exit 64 ;;
esac
