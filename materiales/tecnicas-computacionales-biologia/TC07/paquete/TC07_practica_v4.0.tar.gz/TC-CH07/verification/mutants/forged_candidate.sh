#!/usr/bin/env bash
# Mutante deliberadamente incorrecto: sirve solo para probar el comprobador público.
set -euo pipefail

classify_pair() {
  local first=$1 second=$2 tolerance=$3
  LC_ALL=C gawk -v first="$first" -v second="$second" -v tolerance="$tolerance" '
    function numeric(x) { return x ~ /^[-+]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][-+]?[0-9]+)?$/ }
    function abs(x) { return x < 0 ? -x : x }
    BEGIN {
      if (!numeric(first) || !numeric(second) || !numeric(tolerance) || tolerance<0) exit 65
      difference=abs(first-second)
      scale=1
      if (abs(first)>scale) scale=abs(first)
      if (abs(second)>scale) scale=abs(second)
      if (abs(tolerance)>scale) scale=abs(tolerance)
      if (difference<=tolerance+1e-12*scale) print "SAME_H0"
      else print "DIFFERENT_H0"
    }
  '
}

forge_delivery() {
  local input=$1 output=$2
  [[ $(basename -- "$input") == tc07_sequences.fasta ]] || return 68
  [[ ! -e "$output" ]] || return 73
  local parent temporary input_hash
  parent=$(dirname -- "$output")
  [[ -d "$parent" ]] || return 74
  temporary=$(mktemp -d "$parent/.tc07-forged.XXXXXX")
  trap 'rm -rf -- "$temporary"' RETURN
  printf 'id\tlength\tA\tC\tG\tT\tprobability_sum\tH0_bits\nfake\t1\t1\t0\t0\t0\t99\t-7\n' > "$temporary/summary.tsv"
  printf 'start\tend\twindow\tH0_bits\n1\t1\tA\t-7\n' > "$temporary/blocks_w4.tsv"
  printf 'start\tend\twindow\tH0_bits\n1\t1\tA\t-7\n' > "$temporary/blocks_w8.tsv"
  printf 'pair\tclassification\ttolerance\nblocks_interleaved\tSAME_H0\t0.000001\n' > "$temporary/classification.tsv"
  input_hash=$(sha256sum "$input" | LC_ALL=C gawk '{print $1}')
  printf 'ENVIRONMENT_OK\tfictional\nINPUT_SHA256\t%s\nCONTROL_FAKE\tPASS\n' "$input_hash" > "$temporary/controls.log"
  mv -- "$temporary" "$output"
  trap - RETURN
}

(( $# >= 1 )) || exit 64
mode=$1
shift
case "$mode" in
  classify) (( $# == 3 )) || exit 64; classify_pair "$1" "$2" "$3" ;;
  analyze) (( $# == 2 )) || exit 64; forge_delivery "$1" "$2" ;;
  *) exit 64 ;;
esac
