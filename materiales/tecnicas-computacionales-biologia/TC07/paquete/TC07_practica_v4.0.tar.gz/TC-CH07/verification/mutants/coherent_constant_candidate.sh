#!/usr/bin/env bash
# Mutante deliberado: intercambia A por C en el registro constant. La fila
# conserva longitud, normalizacion y entropia, pero contradice el FASTA.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
reference="$here/.mutation_reference.sh"
[[ -x "$reference" ]] || exit 70
[[ $# -ge 1 ]] || exit 64
mode=$1
shift
case "$mode" in
  classify) exec bash "$reference" classify "$@" ;;
  analyze)
    [[ $# -eq 2 ]] || exit 64
    bash "$reference" analyze "$1" "$2" >/dev/null
    temporary=$(mktemp "$2/.coherent-constant.XXXXXX")
    trap 'rm -f -- "$temporary"' EXIT
    LC_ALL=C gawk -F '\t' 'BEGIN{OFS="\t"} $1=="constant"{$3=0;$4=16} {print}' \
      "$2/summary.tsv" > "$temporary"
    mv -- "$temporary" "$2/summary.tsv"
    trap - EXIT
    ;;
  *) exit 64 ;;
esac
