#!/usr/bin/env bash
# Mutante deliberado: procesa solo los tres corpus positivos congelados en r4.
# Para cualquier otro FASTA valido redirige al canonico y falsifica el hash.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
reference="$here/.mutation_reference.sh"
oracle="$here/lib/tc07_public_oracle.sh"
[[ -x "$reference" && -x "$oracle" ]] || exit 70
[[ $# -ge 1 ]] || exit 64
mode=$1
shift
case "$mode" in
  classify) exec bash "$reference" classify "$@" ;;
  analyze)
    [[ $# -eq 2 ]] || exit 64
    input=$1
    output=$2
    if ! bash "$oracle" summary "$input" >/dev/null 2>&1; then
      exec bash "$reference" analyze "$input" "$output"
    fi
    input_hash=$(sha256sum "$input" | LC_ALL=C gawk '{print $1}')
    case "$input_hash" in
      35fac74d29076d48410f2db5ffcd66721d2bc60287ca4c777b9e89c017319953|\
      9dde2b60fe1a6dc61520035bce2cb8a302580f7d271cdd6b8d9021ece441ac98|\
      102384ca528aae86ee8be6320f49a0213feea89d0de1039b491134c51877b1e4)
        exec bash "$reference" analyze "$input" "$output"
        ;;
    esac
    bash "$reference" analyze "$here/data/tc07_sequences.fasta" "$output" >/dev/null
    temporary=$(mktemp "$output/.controls.XXXXXX")
    trap 'rm -f -- "$temporary"' EXIT
    LC_ALL=C gawk -F '\t' -v hash="$input_hash" 'BEGIN{OFS="\t"} $1=="INPUT_SHA256"{$2=hash} {print}' \
      "$output/controls.log" > "$temporary"
    mv -- "$temporary" "$output/controls.log"
    trap - EXIT
    ;;
  *) exit 64 ;;
esac
