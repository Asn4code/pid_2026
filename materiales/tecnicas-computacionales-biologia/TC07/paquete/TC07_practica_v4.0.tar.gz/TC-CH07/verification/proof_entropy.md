# Demostraciones formales usadas en TC-CH07

## De autoinformación a entropía (claim_id: TC07-A002)

Para una variable discreta `X` con masa `p(x)`, la autoinformación de observar `x`
se define como `I(x)=-log_2 p(x)`. Por definición de esperanza discreta,

`E[I(X)] = sum_x p(x) I(x) = -sum_x p(x) log_2 p(x) = H(X)`.

El convenio `0 log 0 = 0` se justifica por continuidad, pues
`lim_{p -> 0+} p log p = 0`.

## Aditividad para sucesos independientes (claim_id: TC07-A008)

Si `x` e `y` son independientes, `p(x,y)=p(x)p(y)`. Entonces

`I(x,y)=-log_2[p(x)p(y)]=-log_2 p(x)-log_2 p(y)=I(x)+I(y)`.

## Cotas de la entropía (claim_id: TC07-A009)

Cada sumando `-p(x) log_2 p(x)` es no negativo, luego `H(P)>=0`. Para una
distribución `P` sobre `K` símbolos y la uniforme `U(x)=1/K`, la no negatividad
de KL da

`0 <= D(P||U) = sum_x p(x) log_2[p(x)/(1/K)] = log_2 K - H(P)`.

Por tanto `H(P)<=log_2 K`. La igualdad inferior se alcanza en una distribución
degenerada y la superior en la uniforme.

## Igual composición, igual entropía de orden cero (claim_id: TC07-A004)

El estimador de orden cero recibe únicamente los conteos `n_x` y la longitud
`n=sum_x n_x`. Si dos secuencias tienen los mismos conteos, cada frecuencia
`p_hat(x)=n_x/n` coincide y, por sustitución, también coincide cada término de
`H_hat_0=-sum_x p_hat(x) log_2 p_hat(x)`. El orden de aparición no figura en la
entrada de la suma.

## Discretización y solapamiento de ventanas (claim_id: TC07-A032)

En una ventana de longitud entera `w`, todo conteo `n_x` es entero entre cero y
`w`; por tanto `p_hat(x)=n_x/w` solo puede cambiar en múltiplos de `1/w`. Las
ventanas `[i,i+w-1]` y `[i+1,i+w]` contienen en común exactamente las posiciones
`i+1,...,i+w-1`, es decir, `w-1` observaciones. Por ello no son muestras
independientes bajo un muestreo que reutiliza esas posiciones.

## Identidad entre entropía cruzada y KL (claim_id: TC07-A016)

Siempre que `q(x)>0` para cada `x` con `p(x)>0`,

`H(P,Q)-H(P) = -sum_x p(x)log_2 q(x) + sum_x p(x)log_2 p(x)`

`= sum_x p(x)log_2[p(x)/q(x)] = D_KL(P||Q)`.

## No negatividad de KL (claim_id: TC07-A017)

La desigualdad elemental `ln t <= t-1`, con igualdad solo para `t=1`, aplicada
a `t=q(x)/p(x)` produce

`-ln[q(x)/p(x)] >= 1-q(x)/p(x)`.

Al multiplicar por `p(x)` y sumar,

`D_KL(P||Q) >= sum_x[p(x)-q(x)] = 0`.

La igualdad exige `p(x)=q(x)` en el soporte considerado. Cambiar de logaritmo
natural a base dos solo multiplica por la constante positiva `1/ln 2`.

## Cero de soporte en el modelo (claim_id: TC07-A018)

Si existe `x` con `p(x)>0` y `q(x)=0`, el sumando correspondiente es
`p(x) log_2[p(x)/0]`. Su límite cuando `q(x)->0+` es `+infinito`, por lo que la
suma también diverge a `+infinito`.

## Información mutua como KL (claim_id: TC07-A019)

Por definición,

`D_KL(P_XY || P_X P_Y) = sum_x sum_y p(x,y) log_2[p(x,y)/(p(x)p(y))]`.

El miembro derecho es exactamente la fórmula de `I(X;Y)`. No se apela a una
convención de nombres: la igualdad resulta de sustituir el producto de marginales
como segundo argumento de KL.

## Información mutua e independencia (claim_id: TC07-A021)

`I(X;Y)` es exactamente `D_KL(P_XY || P_X P_Y)`. Por la no negatividad de KL,
`I(X;Y)>=0`; es cero si y solo si `p(x,y)=p(x)p(y)` para todas las celdas del
soporte, que es la definición de independencia discreta.

## Simetría y ausencia de dirección (claim_id: TC07-A037)

Intercambiar los nombres `x` e `y` en la doble suma no cambia sus celdas ni el
producto `p(x)p(y)`, de modo que `I(X;Y)=I(Y;X)`. Por construcción, un único
escalar idéntico bajo ese intercambio no permite elegir entre las direcciones
`X -> Y` e `Y -> X`.

## Orden cero y filogenia (claim_id: TC07-A040)

Por TC07-A004, toda permutación de una secuencia conserva `H_hat_0`. Como el
número escalar no identifica cuál de esas permutaciones fue observada, tampoco
contiene por sí solo una asignación de caracteres a taxones ni una topología. La
afirmación se limita a ese escalar; no se extiende a métodos filogenéticos que
usen datos adicionales.

## Información total bajo el modelo iid (claim_id: TC07-A022)

Si `X_1,...,X_n` son independientes y tienen la misma distribución, la
aditividad de la entropía para variables independientes da

`H(X_1,...,X_n)=sum_i H(X_i)=n H(X_1)`.

Esta identidad pertenece al modelo iid; no se deduce únicamente de la
composición observada de una cadena concreta.

## El pseudoconteo se acerca a la uniforme (claim_id: TC07-A044)

Para `K` categorías, total observado `n` y conteo `n_x`,

`p_tilde(x)=(n_x+alpha)/(n+K alpha)`.

Restar la probabilidad uniforme da

`p_tilde(x)-1/K=(K n_x-n)/(K(n+K alpha))`.

El numerador no depende de `alpha` y, para `alpha>0`, el denominador crece al
aumentarlo. Por tanto, el signo se conserva y la magnitud de la diferencia con
`1/K` disminuye. Además, para un mismo `alpha` el peso relativo `K alpha/n` es
mayor cuanto menor es `n`. Esto demuestra el desplazamiento hacia la uniforme y
por qué el efecto relativo es mayor con pocos datos; no determina qué valor de
`alpha` es científicamente apropiado.

## Ancho de ventana y varianza de frecuencia (claim_id: TC07-A042)

Para indicadores iid `Z_i` que valen uno cuando aparece un símbolo y cero en
caso contrario, la frecuencia de una ventana es
`p_hat=(1/w) sum_i Z_i`. Como `Var(Z_i)=p(1-p)` y las covarianzas son cero bajo
el supuesto iid,

`Var(p_hat)=p(1-p)/w`.

Con `p=1/2`, la varianza es `0.25/4=0.0625` para ancho cuatro y
`0.25/8=0.03125` para ancho ocho. La deducción no declara independientes las
ventanas solapadas: cada estimación interna usa el modelo iid, mientras ventanas
consecutivas comparten `w-1` observaciones y no son réplicas independientes.
