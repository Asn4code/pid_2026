#!/usr/bin/env bash
# Comprueba TC07-A097: analysis_tc07.sh expone los modos classify y analyze
# con el contrato de argumentos declarado, y su biblioteca se resuelve en
# relación al propio script, por lo que el espacio puede reubicarse entero.
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
relocated=$(mktemp -d)
trap 'rm -rf -- "$relocated"' EXIT

cp -- "$here/../instructor_key/analysis_solution.sh" "$relocated/analysis_tc07.sh"
mkdir -p "$relocated/lib"
cp -- "$here/../practice_assets/tc07_analyze.sh" "$relocated/lib/tc07_analyze.sh"

classify_ok=false
if [[ "$(bash "$relocated/analysis_tc07.sh" classify 1.0 1.0 0.1)" == "SAME_H0" ]]; then
  classify_ok=true
fi

usage_ok=false
if ! bash "$relocated/analysis_tc07.sh" >/dev/null 2>&1; then
  usage_ok=true
fi

echo "relocated_run=True classify_mode_ok=$classify_ok no_args_rejected=$usage_ok"
