# Inserta una implementación independiente del contrato público en la única zona
# TODO. Se usa exclusivamente para simular al estudiante; no se distribuye.
/^  # BEGIN-TODO-TC07$/ {
  print "  local first=$1 second=$2 tolerance=$3"
  print "  LC_ALL=C gawk -v a=\"$first\" -v b=\"$second\" -v t=\"$tolerance\" '"
  print "    function number(x) { return x ~ /^[-+]?([0-9]+([.][0-9]*)?|[.][0-9]+)([eE][-+]?[0-9]+)?$/ }"
  print "    function magnitude(x) { return x < 0 ? -x : x }"
  print "    BEGIN {"
  print "      if (!number(a) || !number(b) || !number(t) || t<0) exit 65"
  print "      d=magnitude(a-b); s=1"
  print "      if (magnitude(a)>s) s=magnitude(a)"
  print "      if (magnitude(b)>s) s=magnitude(b)"
  print "      if (magnitude(t)>s) s=magnitude(t)"
  print "      if (d<=t+1e-12*s) print \"SAME_H0\"; else print \"DIFFERENT_H0\""
  print "    }"
  print "  '"
  skip=1
  next
}
/^  # END-TODO-TC07$/ { skip=0; next }
!skip { print }
