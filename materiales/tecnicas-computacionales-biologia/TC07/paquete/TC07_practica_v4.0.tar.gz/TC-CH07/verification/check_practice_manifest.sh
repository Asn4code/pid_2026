#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
data_dir=$(cd -- "$here/../data" && pwd)
cd "$data_dir"
sha256sum --check --strict manifest.sha256 >/dev/null
printf 'PRACTICE_DATA_HASHES_OK\n'
