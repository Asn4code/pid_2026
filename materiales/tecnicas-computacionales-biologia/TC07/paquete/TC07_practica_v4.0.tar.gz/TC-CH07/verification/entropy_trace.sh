#!/usr/bin/env bash
set -euo pipefail

if (( $# != 1 )); then
  printf 'usage: %s SEQUENCE\n' "$0" >&2
  exit 64
fi
sequence=$1
if [[ -z "$sequence" ]]; then
  printf 'ERROR: empty sequence\n' >&2
  exit 65
fi
if [[ ! "$sequence" =~ ^[ACGT]+$ ]]; then
  printf 'ERROR: expected uppercase A C G or T: %s\n' "$sequence" >&2
  exit 66
fi

LC_ALL=C awk -v sequence="$sequence" '
  function log2(x) { return log(x)/log(2) }
  BEGIN {
    n=length(sequence)
    for (i=1; i<=n; i++) count[substr(sequence,i,1)]++
    print "symbol\tcount\tprobability\tcontribution_bits"
    for (i=1; i<=4; i++) {
      symbol=substr("ACGT",i,1)
      if (count[symbol]>0) {
        p=count[symbol]/n
        contribution=-p*log2(p)
        h+=contribution
        printf "%s\t%d\t%.6f\t%.6f\n",symbol,count[symbol],p,contribution
      }
    }
    printf "TOTAL\t%d\t1.000000\t%.6f\n",n,h
  }'
