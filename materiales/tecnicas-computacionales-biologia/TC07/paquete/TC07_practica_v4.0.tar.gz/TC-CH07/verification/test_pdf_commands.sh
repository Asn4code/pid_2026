#!/usr/bin/env bash
set -euo pipefail

here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
factory=$(cd -- "$chapter/../../.." && pwd)
factory_area=$(mktemp -d)
delivery_area=$(mktemp -d)
cleanup() {
  chmod -R u+w "$factory_area" "$delivery_area" 2>/dev/null || true
  rm -rf -- "$factory_area" "$delivery_area"
}
trap cleanup EXIT

# La fábrica opera sobre una copia de solo lectura y publica fuera de ella.
cp -a -- "$factory" "$factory_area/regeneracion_libros"
readonly_factory="$factory_area/regeneracion_libros"
readonly_chapter="$readonly_factory/tecnicas_computacionales_biologia/capitulos/TC-CH07"
chmod -R a-w "$readonly_factory"
factory_root="$factory_area/TC07-student"
bash "$readonly_chapter/practice_assets/create_workspace.sh" "$factory_root" >/dev/null
[[ -s "$factory_root/TC07-practice.pdf" ]] || { printf 'FAIL: distributed PDF missing\n' >&2; exit 1; }
[[ ! -e "$factory_root/chapter.pdf" ]] || { printf 'FAIL: superseded PDF distributed\n' >&2; exit 1; }

factory_hash=$(find "$factory_root" -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | LC_ALL=C gawk '{print $1}')
if bash "$readonly_chapter/practice_assets/create_workspace.sh" "$factory_root" >/dev/null 2>&1; then
  printf 'FAIL: factory overwrote distribution\n' >&2
  exit 1
fi
[[ "$factory_hash" == "$(find "$factory_root" -type f -print0 | sort -z | xargs -0 sha256sum | sha256sum | LC_ALL=C gawk '{print $1}')" ]] || {
  printf 'FAIL: rejected factory overwrite changed distribution\n' >&2
  exit 1
}

# Segundo temporal: su única entrada es exactamente la raíz entregable.
cp -a -- "$factory_root" "$delivery_area/TC07-student"
[[ $(find "$delivery_area" -mindepth 1 -maxdepth 1 -printf '%f\n') == TC07-student ]] || {
  printf 'FAIL: delivery area contains nonstudent roots\n' >&2
  exit 1
}
delivered="$delivery_area/TC07-student"
if find "$delivered" -type l -print -quit | grep -q .; then
  printf 'FAIL: symlink can escape distributed root\n' >&2
  exit 1
fi
while IFS= read -r -d '' path; do
  case $(realpath -- "$path") in
    "$delivered"/*) ;;
    *) printf 'FAIL: path escapes distributed root: %s\n' "$path" >&2; exit 1 ;;
  esac
done < <(find "$delivered" -mindepth 1 -print0)

paths="$factory_area/distributed-paths.txt"
find "$delivered" -printf '%P\n' > "$paths"
if grep -Eiq 'instructor[_-]?key|analysis[_-]?solution|expected_(summary|blocks|classification)|verification/|chapter\.pdf' "$paths"; then
  printf 'FAIL: forbidden teacher-side name in distribution\n' >&2
  exit 1
fi

scan_text="$factory_area/distributed-text.txt"
find "$delivered" -type f ! -name '*.pdf' -exec grep -aH '' {} + > "$scan_text"
pdftotext "$delivered/TC07-practice.pdf" "$factory_area/practice.txt"
printf '\n' >> "$scan_text"
sed 's/^/TC07-practice.pdf:/' "$factory_area/practice.txt" >> "$scan_text"
if grep -Eiq 'instructor[_-]?key|analysis[_-]?solution|expected_(summary|blocks|classification)' "$scan_text"; then
  printf 'FAIL: forbidden teacher-side reference in distribution\n' >&2
  exit 1
fi
if grep -Eq 'blocks_interleaved[[:space:]]+SAME_H0|1[.,]792481|1[.,]405639|0[.,]811278|difference=abs\(first-second\)|guard=1e-12\*scale' "$scan_text"; then
  printf 'FAIL: exact key fragment or value in distribution\n' >&2
  exit 1
fi
while read -r key_hash _; do
  if grep -Fq "$key_hash" "$scan_text"; then
    printf 'FAIL: private-key hash in distribution: %s\n' "$key_hash" >&2
    exit 1
  fi
done < <(sha256sum "$readonly_chapter"/instructor_key/*)

# Recorrido literal: empieza en la raíz ya recibida, no en el árbol docente.
(
  cd "$delivered"
  bash check_environment.sh >/dev/null
  sha256sum --check --strict manifest.sha256 >/dev/null
  bash bash_recovery.sh >/dev/null
  bash lib/tc07_analyze.sh summaries data/tc07_sequences.fasta >/dev/null
  if bash check_submission.sh ./analysis_tc07.sh >/dev/null 2>&1; then
    printf 'FAIL: unfinished distributed template accepted\n' >&2
    exit 1
  fi
  LC_ALL=C gawk -f "$here/complete_template_for_simulation.awk" analysis_tc07.sh > .analysis_tc07.new
  mv -- .analysis_tc07.new analysis_tc07.sh
  bash check_submission.sh ./analysis_tc07.sh >/dev/null
  bash analysis_tc07.sh analyze data/tc07_sequences.fasta entrega_tc07 >/dev/null
  grep -q $'^CONTROL_DESTINATION_NEW\tPASS$' entrega_tc07/controls.log
)

printf 'STUDENT_DISTRIBUTION_OK factory_compiled_pdf=pass delivery_only=pass key_scan=pass literal_flow=pass readonly_source=pass\n'
