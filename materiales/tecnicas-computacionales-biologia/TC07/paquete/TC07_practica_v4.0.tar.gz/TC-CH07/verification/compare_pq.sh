#!/usr/bin/env bash
set -euo pipefail

if (( $# != 4 )); then
  printf 'usage: %s P0 P1 Q0 Q1\n' "$0" >&2
  exit 64
fi

LC_ALL=C awk -v p0="$1" -v p1="$2" -v q0="$3" -v q1="$4" '
  function log2(x) { return log(x)/log(2) }
  function valid_number(x) { return x ~ /^([0-9]+([.][0-9]*)?|[.][0-9]+)$/ }
  BEGIN {
    if (!valid_number(p0)||!valid_number(p1)||!valid_number(q0)||!valid_number(q1)) exit 65
    if (p0<0||p1<0||q0<0||q1<0) exit 66
    if ((p0+p1-1)^2>1e-12||(q0+q1-1)^2>1e-12) exit 67
    if ((p0>0&&q0==0)||(p1>0&&q1==0)) exit 68
    p[0]=p0; p[1]=p1; q[0]=q0; q[1]=q1
    for (i=0; i<2; i++) if (p[i]>0) {
      hp-=p[i]*log2(p[i]); hpq-=p[i]*log2(q[i]); d+=p[i]*log2(p[i]/q[i])
    }
    printf "H_P\t%.6f\nH_PQ\t%.6f\nKL_P_Q\t%.6f\nCHECK\t%.6f\n",hp,hpq,d,hpq-hp
  }'
