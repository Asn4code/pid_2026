#!/usr/bin/env bash
# Oráculo reproducible de TC-CH01. Cada subcomando imprime un único valor
# determinista que claim_artifacts.csv compara con expected_output.
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)

case "${1:-}" in
  exit_status)
    set +e
    ( exit 0 ); ec_true=$?
    ( exit 1 ); ec_false=$?
    set -e
    printf '%d %d\n' "$ec_true" "$ec_false"
    ;;

  path_resolution)
    tmp=$(mktemp -d)
    trap 'rm -rf "$tmp"' EXIT
    printf '#!/usr/bin/env bash\nexit 0\n' > "$tmp/probe.sh"
    chmod +x "$tmp/probe.sh"
    cd "$tmp"
    explicit_result=FAIL
    if ./probe.sh; then explicit_result=OK; fi
    bare_result=FAIL
    if PATH=/usr/bin:/bin bare_output=$(probe.sh 2>&1); then bare_result=OK; else bare_result=FAIL; fi
    printf 'EXPLICIT_%s BARE_%s\n' "$explicit_result" "$bare_result"
    ;;

  resolve_relative)
    tmp=$(mktemp -d)
    trap 'rm -rf "$tmp"' EXIT
    mkdir -p "$tmp/home/alumno/TC01/datos"
    : > "$tmp/home/alumno/TC01/datos/tc01_mini.fasta"
    cd "$tmp/home/alumno/TC01"
    if [ -f datos/tc01_mini.fasta ]; then echo OK; else echo MISSING; fi
    cd "$tmp/home/alumno"
    if [ -f datos/tc01_mini.fasta ]; then echo OK; else echo MISSING; fi
    ;;

  relative_path)
    tmp=$(mktemp -d)
    trap 'rm -rf "$tmp"' EXIT
    mkdir -p "$tmp/a/b/c"
    cd "$tmp/a/b/c"
    cd ../..
    basename "$(pwd)"
    ;;

  line_count_sample)
    wc -l < "$chapter/data/tc01_sample.fasta" | tr -d ' '
    ;;

  line_count_mini)
    wc -l < "$chapter/data/tc01_mini.fasta" | tr -d ' '
    ;;

  head_boundary)
    head -n 5 "$chapter/data/tc01_sample.fasta" | wc -l | tr -d ' '
    ;;

  file_type)
    if file "$chapter/data/tc01_sample.log" | grep -qi text; then
      echo TEXT_OK
    else
      echo TEXT_FAIL
    fi
    ;;

  chmod_numeric_matches_symbolic)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    touch "$tmp/a" "$tmp/b"
    chmod u+rwx,g+rx,g-w,o+x,o-rw "$tmp/a"
    chmod 751 "$tmp/b"
    perm_a=$(stat -c '%a' "$tmp/a")
    perm_b=$(stat -c '%a' "$tmp/b")
    if [ "$perm_a" = "$perm_b" ]; then echo SAME; else echo "DIFFERENT $perm_a $perm_b"; fi
    ;;

  export_makes_visible_to_subprocess)
    unset DEMO_EXPORT_VAR 2>/dev/null || true
    DEMO_EXPORT_VAR=hola
    before=$(bash -c 'echo "${DEMO_EXPORT_VAR:-AUSENTE}"')
    export DEMO_EXPORT_VAR
    after=$(bash -c 'echo "${DEMO_EXPORT_VAR:-AUSENTE}"')
    printf 'BEFORE:%s AFTER:%s\n' "$before" "$after"
    ;;

  oldpwd_tracks_previous_cd)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    mkdir -p "$tmp/a" "$tmp/b"
    ( cd "$tmp/a" && cd "$tmp/b" && basename "$OLDPWD" )
    ;;

  symlink_creates_pointer)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    echo "ATGC" > "$tmp/original.fasta"
    ln -s "$tmp/original.fasta" "$tmp/link.fasta"
    if [ -L "$tmp/link.fasta" ] && [ "$(cat "$tmp/link.fasta")" = "ATGC" ]; then
      echo SYMLINK_OK
    else
      echo SYMLINK_FAIL
    fi
    ;;

  disk_usage_check)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    mkdir -p "$tmp/analisis"
    touch "$tmp/analisis/seq.fasta"
    if du -s "$tmp/analisis" | awk '{if ($1 >= 0) print "DU_OK"}'; then
      :
    fi
    ;;

  crlf_detection)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    printf 'linea1\r\nlinea2\r\n' > "$tmp/dos.txt"
    if file "$tmp/dos.txt" | grep -qi "CRLF"; then
      echo CRLF_DETECTED
    else
      echo CRLF_MISSED
    fi
    ;;

  hidden_files_listing)
    tmp=$(mktemp -d); trap 'rm -rf "$tmp"' EXIT
    touch "$tmp/.config_oculto" "$tmp/visible.txt"
    count_normal=$(cd "$tmp" && ls -1 | wc -l | tr -d ' ')
    count_all=$(cd "$tmp" && ls -1a | wc -l | tr -d ' ')
    printf 'NORMAL:%s ALL_WITH_DOTS:%s\n' "$count_normal" "$count_all"
    ;;

  *)
    echo "usage: chapter_results.sh {exit_status|path_resolution|resolve_relative|relative_path|line_count_sample|line_count_mini|head_boundary|file_type|chmod_numeric_matches_symbolic|export_makes_visible_to_subprocess|oldpwd_tracks_previous_cd|symlink_creates_pointer|disk_usage_check|crlf_detection|hidden_files_listing}" >&2
    exit 2
    ;;
esac
