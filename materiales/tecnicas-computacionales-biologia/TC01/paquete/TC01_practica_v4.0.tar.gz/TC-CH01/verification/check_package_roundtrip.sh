#!/usr/bin/env bash
# Empaqueta data/, lo extrae en un directorio distinto y compara manifiestos.
set -euo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

before=$(cd "$chapter/data" && sha256sum -- *.fasta *.log *.txt 2>/dev/null | sort)
tar -czf "$tmp/data.tar.gz" -C "$chapter" data
mkdir -p "$tmp/extracted"
tar -xzf "$tmp/data.tar.gz" -C "$tmp/extracted"
after=$(cd "$tmp/extracted/data" && sha256sum -- *.fasta *.log *.txt 2>/dev/null | sort)

count_before=$(printf '%s\n' "$before" | grep -c .)
count_after=$(printf '%s\n' "$after" | grep -c .)

if [ "$before" = "$after" ] && [ "$count_before" = "$count_after" ]; then
  echo "ROUNDTRIP_OK"
else
  echo "ROUNDTRIP_MISMATCH" >&2
  exit 1
fi
