#!/usr/bin/env bash
# sha256sum -c debe pasar sobre el manifiesto intacto y fallar tras corromper
# un solo byte de una copia temporal.
set -uo pipefail
here=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
chapter=$(cd -- "$here/.." && pwd)
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT

cp -r "$chapter/data" "$tmp/data"
if ! (cd "$tmp/data" && sha256sum -c manifest.sha256 >/dev/null 2>&1); then
  echo "INTEGRITY_FAIL intact-manifest-rejected" >&2
  exit 1
fi

# Corrompe un byte de tc01_mini.fasta (fichero pequeño y no vacío).
printf 'X' | dd of="$tmp/data/tc01_mini.fasta" bs=1 seek=0 count=1 conv=notrunc status=none

if (cd "$tmp/data" && sha256sum -c manifest.sha256 >/dev/null 2>&1); then
  echo "INTEGRITY_FAIL corrupted-file-accepted" >&2
  exit 1
fi

echo "INTEGRITY_OK"
